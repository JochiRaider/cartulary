# imports Module Refactoring Tracker and Handoff

## 1. Scope and Source Posture

### 1.1 Target and change boundary

- **Target path:** `internal/modules/imports`
- **Target label:** `imports`
- **Output path:** `docs/handoffs/imports-module-refactor-tracker.md`
- **Status:** Remediation complete; retained as the final control and handoff artifact.
- **Current control point:** `RS-11` substantive results `575f1999` and `32c5e38b` are complete;
  this tracker-only checkpoint closes the sequence.
- **Allowed change after this control point:** None under this remediation authorization. Any
  follow-on product, specification, migration, or harness change requires a new scoped workstream.
- **Non-goals:** No unsequenced production refactor, generated-root hand edit, dependency-lock edit,
  whole-session rollback, generic callback bus, import-specific WebSocket surface, or legacy target
  fallback.
- **Implementation authorization:** The 2026-07-28 implementation request authorizes the complete
  remediation sequence in §7. Each slice remains blocked by its listed owner, characterization,
  generation, migration, and verification gates.
- **Behavior posture:** A structural slice MUST preserve current observable behavior. A
  conformance correction MUST be isolated, authorized, migrated when necessary, and verified
  against its adopted owner.

### 1.2 Authority and normative language

This tracker uses NLSpec-style normative language to make the future refactor handoff
decision-complete. It is not an adopted behavior owner and MUST NOT supersede an adopted Core or
subsystem NLSpec.

- **MUST** and **MUST NOT** state requirements for an authorized future refactor slice after its
  owner and execution gates pass.
- **SHOULD** states a preferred choice that may be replaced only when the implementation handoff
  records an equivalent owner-conformant result and its verification.
- **MAY** grants intentional implementation freedom whose alternatives do not change caller-visible
  behavior or interoperability.
- **RESOLVED_IN_TRACKER** means the planning decision is complete. It does not mean the relevant
  owner amendment is adopted, code is implemented, or conformance evidence passes.
- A proposed requirement that conflicts with current adopted owner text MUST remain
  non-implementable until the coordinated owner-repair gate passes.

The source hierarchy is:

1. Adopted subsystem NLSpecs for their named scopes.
2. Core 00 through Core 04 for implementation-conformance behavior.
3. Core 05 only for claim-bearing timed or fixture-sensitive publication.
4. Domain vocabulary and implementation-support guides.
5. Current repository code and tests.
6. Prior plans, handoffs, analysis notes, and the planning framework as evidence only.

Core 05 is not applicable because this tracker publishes no timed or fixture-sensitive claim.
`temp/analysis-notes.md` supplies recommendations and rationale only; local adopted owners supply
every normative behavior reference. External-source freshness prose and `sandbox:` links from the
notes are not imported into this tracker.

### 1.3 Documents and repository evidence inspected

Owner and support documents:

- `docs/handoffs/cartulary_modular_refactor_planning_framework.md`
- `docs/domain.md`
- `docs/research/nlspec-spec.md`
- Core 00 through Core 04 under `docs/spec/`
- `docs/network-flow-activity-nlspec.md`
- `docs/extension-subsystem-nlspec.md`
- `docs/testing-harness-nlspec.md`
- `contracts/verification/owners/module.imports.json`
- `tools/test_families/module.imports.json`
- `tools/backend_module_boundaries.json`

Repository evidence:

- Every tracked file under `internal/modules/imports`.
- The shared `internal/modules/tabularingest` package.
- Server and extension composition under `internal/app/server` and
  `internal/app/extensionassembly`.
- Network Flow import-facade and transaction-participant code.
- Import-create facades in artifacts, assessments, entities/hostidentity, evidence, indicators,
  parties, and tasksdecisions.
- Import migrations `db/migrations/00018_imports.sql` and
  `db/migrations/00028_import_source_streams_and_targets.sql`.
- The authored imports OpenAPI owner and generated Go and TypeScript consumer locations.
- The web import coordinator, Import Assistant, Network Flow import controller, unit tests, and
  browser tests.
- Verification-owner, test-family, test-catalog, and module-boundary mappings.

The implementation baseline is clean `main` at
`ee848b80cb21cb3fb94aff4dcdef4cf6f73cb672`. The prior inspection baseline
`effce7c1fb34e7e6eabe7c2e80017d38c539f123` remains useful because the intervening commit added
only this tracker. The active narrow baseline is
`make test-slice OWNER=module.imports`: five routed tests and three work units passed at
`.cartulary/test-results/20260728T224329Z-p1276405`.
The final workstream baseline is tracker checkpoint `c00f9ce1`; the RS-11 harness and closure
results are substantive commits `575f1999` and `32c5e38b`.

### 1.4 Mandatory workstream checkpoint

Each `RS-*` workstream is a separate implementation or specification change. The final action in
each workstream MUST update this tracker before the next workstream begins. The checkpoint MUST
record:

- completed slice, gate, and `IMP-*` state;
- baseline and resulting commit identifiers;
- exact substantive files and contracts changed;
- validation commands, outcomes, work-unit counts, and retained run roots;
- failures and whether they are related;
- compatibility, migration, rollback, generated-artifact, and residual-risk notes;
- the single next eligible workstream.

The tracker checkpoint MUST pass `make lint-markdown` and be committed separately from the
substantive change. A failed exit criterion leaves the current slice open.

## 2. Current-State Repository Inventory

| Path | Current responsibility | Exported/public symbols or package surface | Inbound callers | Outbound dependencies | Tests touching it | Generated artifacts or contracts touched | Suspected target owner module | Risk level | Notes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| `internal/modules/imports/api.go` | Import request/response DTOs, profile and state vocabulary, strict decoding, mapping validation and fingerprinting, normalization, and API errors | Import session, unit, mapping, preview, apply, warning, error, and profile types and constants | Routes, Store, tests, server composition, Network Flow facade | Standard library plus import contract/value helpers | Import integration and frontend contract-adapter tests indirectly | Authored imports OpenAPI and generated protocol models mirror this surface | imports | high | Public HTTP envelope and error compatibility MUST be frozen before movement. |
| `internal/modules/imports/apply_coordination.go` | Target resolution, generic-versus-analytical dispatch, apply result-reference ordering, source-cell indexing, and mapping transforms | Internal unit-apply coordinator | Apply jobs and owner apply adapters | Generated target registry, owner facade paths, jobs resource references | Imports integration and owner effect tests | Core dispatcher and common mapping contract | imports apply coordination | high | RS-06 changes the commit protocol without moving target semantics back into this coordinator. |
| `internal/modules/imports/apply_jobs.go` | Apply-job payload execution, unit iteration, cancellation/failure handling, progress, and terminal-success request | Internal apply job handler methods | Jobs runner through service registration | Store, auth store, apply coordinator, job finalizer | Imports service-backed tests | Core two-level completion contract | imports job coordination | critical | Current per-unit status and terminal publication are characterized inputs to the RS-06 replacement. |
| `internal/modules/imports/boundary_guard_test.go` | Source-level dependency and ownership guards for the imports package | Test-only package surface | Go test runner and verification catalog | Filesystem/source inspection | Self | Verification owner and family mappings | imports test ownership | medium | All responsibility and peer-boundary guards are explicitly routed; source-text evidence complements rather than replaces runtime conformance. |
| `internal/modules/imports/boundary_test.go` | Guards against workbook/projection ownership leakage and selected peer-owner coupling | Test-only package surface | Go test runner and verification catalog | Filesystem/source inspection | Self | Verification owner and family mappings | imports test ownership | medium | Source-text guards are accounted exactly once and remain boundary evidence, not runtime-conformance proof. |
| `internal/modules/imports/characterization_test.go` | Executable eleven-route and generated-target parity evidence plus safe internal-error fallback and hidden-sheet neutrality characterization | Test-only package surface | Go test runner | Imports route and target source inspection | Self | Verification owner and family mappings | imports test ownership | medium | RS-08 converted raw-error fallback to normative non-disclosure evidence; RS-09 converted the hidden-sheet gap to normative presentation-neutrality evidence. |
| `internal/modules/imports/discovery.go` | File-kind detection, bounded CSV/XLSX discovery dispatch, and normalized unit/preview/source-row construction | Internal discovery adapter methods | HTTP session creation | Shared tabular ingest, XLSX adapter, Limits, HTTP error helpers | Imports parser and integration tests | Core source discovery contract | imports discovery adapter | high | Locator expansion remains isolated to RS-09. |
| `internal/modules/imports/extension_facade.go` | Analytical import preview/apply contract, request/result and typed owner-error translation interfaces, facade registry, and dependency override lookup | Extension facade interfaces, preview/apply/error DTOs, registry construction, validation, and errors | Network Flow module, handlers, tests, server dependency override | `internal/modules/extensions` dependency set and shared import values | Network Flow and imports integration tests | Core import profile and Network Flow owner contract | imports orchestration with target-owner implementations | critical | Transaction convergence completed in RS-06; RS-08 now validates target-registered schema/translation identities and fails unknown owner errors closed. |
| `internal/modules/imports/http_handlers.go` | Eleven HTTP handlers and owner-route binding, authentication/CSRF/role admission, response/error mapping, path parsing, and pagination | Internal handler methods, binding helper, and route-path parser | `RegisterRoutes` in service composition | Auth, Store, mapping/discovery/apply services, pagination | Imports integration and browser tests | Authored imports OpenAPI and generated route/model consumers | imports HTTP adapter | high | Transport binding and policy remain separate from service construction and mapping orchestration. |
| `internal/modules/imports/imports_integration_test.go` | Service-backed HTTP, session, mapping, replay, authorization, atomicity/recovery, cancellation, bounded XLSX, generic-owner, Network Flow, evidence, journal, and failure-path coverage | Test-only fixtures and cases | Go test runner and exact module.imports verification rows | Server test support, PostgreSQL, object store, HTTP, module stores | Self | Verification owner and test-family rows | imports test ownership | high | RS-11 scopes lock probes to the tested transaction chain so cancellation ordering remains deterministic under the full concurrent topology. |
| `internal/modules/imports/job_finalization.go` | Narrow port for publishing successful import-job terminal state | `JobSuccessFinalizer` interface | Route/job execution and extension assembly adapter | Job finalization owner through injected application adapter | Imports integration tests indirectly | Job and import profile contracts | imports application coordination | high | Finalization MUST become a recoverable derivation separate from owner-resource creation. |
| `internal/modules/imports/jobs.go` | Job handler registration/recovery, discovery-job execution, payload decoding, and running/cancel transition mechanics | Internal job-shell methods | Service construction and jobs runner | Jobs manager, Store, finalizer | Imports service-backed tests | Jobs harness and Core discovery completion rules | imports job shell | high | RS-06 may extend recovery mechanics but MUST preserve this platform boundary. |
| `internal/modules/imports/limits.go` | Imports configuration DTO and archive-limit alias | `Limits`, `ArchiveLimits` | Server module settings, parser/session code | Platform archive policy | XLSX and resource-limit integration coverage | Core resource-limit contract | imports policy projection; platform owns archive mechanics | medium | Platform dependency is a typed policy adapter, not source-domain logic. |
| `internal/modules/imports/mapping.go` | Target availability validation, analytical mapping preparation, owner-result validation, and schema-registered safe owner-error conversion | Internal mapping service methods | Mapping handlers and apply coordinator | Target registry, view schemas, extension facades, source capabilities | Imports mapping and Network Flow tests | Core common mapping plus target-owner binding contract | imports mapping service | high | Preview contract/result failures now use the exact registered Core reasons and never echo raw owner errors. |
| `internal/modules/imports/owner_apply.go` | Generic unit transaction, change-set creation, row mapping, exact registry resolution, owner-facade invocation, and apply-journal writes | Primarily unexported apply coordinator; contributes Store apply behavior | Routes/jobs, Store, integration tests | Revisions and the injected closed owner-facade registry | Host identity, evidence, replay, and failure integration cases | Owner-create facade and Core import dispatcher contract | imports dispatcher using application-composed source-owner facades | high | RS-03 removed peer-store construction, peer-table SQL, and source-owner validation branches; RS-06 still replaces the current completion boundary. |
| `internal/modules/imports/owner_errors.go` | Closed common failure detail, typed analytical owner-error envelope, target binding translation validation, safe-detail cloning, and unknown-error fallback | `ExtensionImportOwnerError` and `ExtensionImportErrorTranslation`; remaining helpers are internal | Mapping preview, analytical apply, owner-create apply, unit-outcome finalization | Owner-create facade error contract and target facade translators | Dedicated unit and Imports/Network Flow integration tests | Core error registry plus generated analytical schema/binding identities | imports common error coordinator; target owners define exact unions | critical | Only schema-validated registered owner details cross the boundary; unknown tokens and raw causes collapse to the generic safe Core reason. |
| `internal/modules/imports/owner_errors_test.go` | Canonical mapping-fingerprint, legacy-token rejection, and fail-closed owner-error translation evidence | Test-only package surface | Go test runner and module.imports unit rows | Mapping decoder/fingerprint and owner-error translator | Self | Verification owner and family mappings | imports test ownership | medium | Canonical null/error cases are routed exactly once. |
| `internal/modules/imports/owner_registry.go` | Builds the exact expected enabled view-owner binding set from the generated target registry | Internal registry composition contract | Application Imports assembly | Generated target registry and ownerfacade registry | Imports assembly and boundary tests | Generated backend registry projection | imports | high | All 14 enabled view targets, including Timeline, resolve through this exact fail-closed registry. |
| `internal/modules/imports/ownerfacade/characterization_test.go` | Canonical `write_null`/`omit_field`, non-nullability, and typed safe owner-create error evidence | Test-only package surface | Go test runner | Owner-create facade vocabulary | Self | Verification owner and family mappings | imports test ownership | medium | The former known-gap assertion was replaced in RS-08; `use_null` is accepted nowhere. |
| `internal/modules/imports/ownerfacade/finalize.go` | Shared normalized field-plan finalization and revision metadata used by source-owner creates | Finalization request/result types and helper functions | Seven peer source-owner import-create implementations | Revision/value helpers | Peer module tests and imports integration tests indirectly | Internal owner-create contract | source-owner-neutral import facade | high | It MAY remain a narrow contract after owner semantics are characterized. |
| `internal/modules/imports/ownerfacade/owner_create.go` | Owner-create request/result DTOs, owner normalization hook, mutation-sequence allocator, canonical scalar/null conversion, action/value vocabulary, and typed safe validation helpers | `CreateImportRowRequest`, result/value/error types, scalar normalization, and related constants/helpers | View source owners and imports dispatcher | Standard/value parsing helpers | Peer tests and imports integration tests indirectly | Core owner-create facade contract and exact OwnerCreateError schema | imports shared facade with source-owner implementations | critical | RS-08 recognizes only `write_null`, checks create-field nullability, and exports only the closed safe error detail. |
| `internal/modules/imports/ownerfacade/registry.go` | Closed binding, adapter, owner normalizer, and exact owner-create registry contract | Binding, facade, adapter constructor, registry constructor, ordered bindings, and exact resolver | Source-owner constructors, Imports assembly, apply coordinator | Owner-create request/result contract | Dedicated registry and assembly tests | Core owner-create facade and generated target binding | imports shared facade contract | high | Construction fails closed on missing, duplicate, unexpected, mismatched, or nil facades; Timeline uses the same resolution boundary. |
| `internal/modules/imports/ownerfacade/registry_test.go` | Exact-order and fail-closed registry characterization | Test-only package surface | Go test runner and exact module.imports unit row | Ownerfacade registry | Self | Verification owner and family mappings | imports test ownership | medium | All four registry tests are accounted exactly once. |
| `internal/modules/imports/regions.go` | Operator-region route dispatch, bounded rectangle validation, durable creation/replay orchestration, and region error translation | Internal region handler and validation helpers | Import-session member handler | Store, XLSX rectangle decoder, HTTP error helpers | Imports region integration and frontend/browser flows | Additive operator-region OpenAPI contract | imports source-region service | high | RS-09 added the durable eleventh operation; RS-11 confirms its exact owner and browser accounting. |
| `internal/modules/imports/revision_append_port.go` | Narrow adapter for appending revision contributions during import-owned coordination | Internal revision-appender wrapper surface | Owner apply and route/job assembly | Revisions module | Imports integration tests indirectly | Revision/change-set contracts | revisions owner behind imports port | high | Revision order and idempotency MUST remain owner-defined. |
| `internal/modules/imports/selection.go` | Transactional unit-selection readiness and canonical worksheet-rectangle overlap enforcement | Internal selection-state, source-region, and overlap helpers | Store selection and apply admission | PostgreSQL unit/session state plus canonical locator parsing | Imports lifecycle integration and responsibility-boundary tests | Core selection lifecycle and Imports HTTP error contract | imports selection service | high | Session-first locking serializes concurrent selection; selection and apply both reject overlap with `import_apply_blocked/overlapping_units`. |
| `internal/modules/imports/service.go` | Public route options and registration, dependency validation, service construction, and application-facing composition | `Service`, `RouteOption`, `RegisterRoutes`, and option constructors | Server runtime | Store, owner registry, revisions, auth, jobs, extensions, pagination | Imports route and composition tests | Application facade and authored route inventory | imports composition facade | high | Exported declaration comparison is unchanged from the RS-04 baseline. |
| `internal/modules/imports/source_streams.go` | Import-owned opaque source-stream references, capability loading, and content-digest validation | Source capability/stream types and Store methods consumed by analytical facades | Network Flow import facade and transaction participants | Import Store and hashing/value helpers | Network Flow behavior and imports integration tests | Analytical import facade contract | imports | high | Capability binding MUST satisfy IRT-REQ-004 and IRT-REQ-007 before interface movement. |
| `internal/modules/imports/store.go` | Direct SQL persistence for import sessions, units, source rows, previews, idempotency, admission/state transitions, source streams, and apply journal | `Store`, constructor, session/unit/query/mutation methods, sentinel errors | Routes, owner apply, Network Flow through a restricted interface, tests, server assembly | PostgreSQL and import-owned schema | Imports and Network Flow tests | Import database schema and HTTP resources | imports persistence adapter | critical | Direct SQL is intentional for import-owned state; cross-owner SQL MUST NOT migrate here. |
| `internal/modules/imports/targets.go` | Runtime view-schema and analytical target lookups derived exclusively from the generated registry | Target lookup surface | Routes, mapping validation, owner apply, tests | Generated target registry | Target-registry and owner-apply integration cases | `cartulary.import_target_registry.v1` Go projection | imports contract-owner mapping | medium | RS-03 removed the manual backend target list, and RS-10 removed the frontend duplicate. |
| `internal/modules/imports/unit_outcomes.go` | Immutable applied/failed/canceled unit-outcome persistence, outcome replay, ordered session/job finalization, safe durable error detail, outcome digest derivation, and transaction-current job transition serialization | Internal outcome/finalization types and Store methods | Apply jobs and job finalization | PostgreSQL import-owned outcome schema, Jobs transition lock and resource/error summaries, hashing/JSON helpers | Imports atomicity, recovery, cancellation, and owner-error integration cases | Migrations 00049/00050 and generated SQL models | imports durable completion adapter | critical | Unit commits acquire the Jobs-owned per-job transition lock before current-state validation, so an already-waiting cancellation commits before a subsequent unit can begin. |
| `internal/modules/imports/xlsx.go` | Bounded ZIP/OpenXML XLSX indexing, shared strings, used ranges, tables, static named ranges, presentation metadata, cell kinds, and on-demand rectangle decoding | Internal XLSX index/row-loading surface | Discovery, preview, region, and application flow | ZIP/XML parsing and archive policy | Locator, formula, presentation, archive, and security fixtures | Core import profile and limit contract | imports source adapter using shared tabular-ingest semantics | high | RS-09 supplies complete locator and presentation-neutrality evidence. |
| `internal/modules/imports/xlsx_test.go` | Unit-level bounded workbook index, table/name/presentation/formula/archive, and rectangle-decoder evidence | Test-only fixtures and cases | Go test runner and exact module.imports verification rows | XLSX adapter and in-memory archives | Self | Verification owner and test-family rows | imports test ownership | medium | Locator/security cases are routed through the Imports unit family exactly once. |

The 33 tracked files above include the RS-00 characterization additions, the RS-03 through RS-05
registry/convergence/decomposition contracts, the RS-06/07 durable outcome and selection
boundaries, the RS-08 safe owner-error boundary, and the RS-09 region/XLSX additions. RS-11 removed
the obsolete `.gitkeep` and empty untracked `internal/modules/imports/tabularingest` placeholder.
The live shared parser package remains `internal/modules/tabularingest`.

## 3. Module Boundary Diagnosis

The dedicated imports boundary is legitimate. Core 01, Core 03, and the domain vocabulary assign it
source adapters, sessions, units, mappings, warnings, provenance, target dispatch, and import
orchestration. That valid boundary does not validate every responsibility currently placed inside
the package.

| Responsibility found | Current location | Correct owner candidate | Keep / move / split / defer | Evidence | Normative disposition |
| --- | --- | --- | --- | --- | --- |
| Import session, unit, mapping, source-stream, warning, and journal state | `api.go`, `store.go`, `source_streams.go` | imports | keep | Core 01/03 and imports migrations | Imports MUST retain this state behind its facade. |
| CSV and XLSX source adaptation and bounded discovery | `routes.go`, `xlsx.go`, shared tabular ingest | imports using owner-neutral tabular-ingest primitives | split | Core 01/03 and live call graph | Parsing/discovery MUST separate from HTTP and jobs without changing source semantics. |
| HTTP request parsing and response/error mapping | `routes.go` | imports transport adapter | split | Authored OpenAPI and route registration | The existing ten route shapes and envelopes MUST remain stable; RS-09 adds one compatible operator-region operation. |
| Job registration, recovery, execution, and terminal publication | `routes.go`, `job_finalization.go` | imports coordinator plus platform job shell | split | Core job rules and extension assembly | Finalization MUST follow the two-level model in IRT-REQ-005 and IRT-REQ-006. |
| Admission and apply-time authorization | `routes.go`, transaction paths | imports service using platform auth | split | Core 04 | Transaction-current authorization MUST be added only through an authorized correction. |
| Generic view-schema target dispatch | `targets.go`, `owner_apply.go` | imports dispatcher | keep | Core 01 dispatcher requirements | Dispatcher MUST select exactly one owner facade and MUST NOT know owner internals. |
| Concrete peer-store construction | `owner_apply.go` | application composition root | move | Application facade doctrine and live constructors | Construction MUST move to application composition. |
| Source-owner validation, defaults, references, and create rules | `owner_apply.go`, peer import-create files | each source-owner module | move | Core 01 owner-facade requirements | Imports MUST delegate these semantics to the selected source owner. |
| Timeline import mutation | Timeline-owned facade behind common apply coordinator | Timeline behind the owner-create facade | keep outside Imports internals | RS-04 `7e891c66`, dispatcher rule, and Timeline ownership | Timeline uses the same exact registry and unit transaction while retaining its defaults, provenance, revisions, projections, and collaboration effects. |
| Revision/change-set coordination | `owner_apply.go`, revision port | revisions owner behind coordination port | split | Core revision semantics | Imports MAY coordinate but MUST NOT redefine revision semantics. |
| Projection refresh and collaboration effects | Peer facades | corresponding source owner | move | Core owner-facade rule and live peer stores | Owner effects MUST remain behind the owner facade. |
| Network Flow normalization and table mutation | Network Flow implementation | Network Flow | keep outside imports | Adopted Network Flow NLSpec | Imports MUST retain only orchestration and Core capabilities. |
| Frontend import workflow state | Web coordinator and Import Assistant | web imports controller/feature | keep | Live frontend flow | Frontend MUST consume the generated semantic target projection after GATE-04. |
| Grid-vendor integration | Not found | grid adapter if later discovered | defer | Targeted search | No action is authorized on current evidence. |
| Saved views | Not directly owned or mutated | saved-view owner | defer | Live code and contract search | View-schema targeting MUST NOT be described as saved-view mutation. |
| Test-util mutation paths | No target-specific path found | test-util owner if later discovered | defer | Integration tests use reusable app/HTTP support | No test-util move is planned. |

Overall classification: **legitimate public imports facade over a mixed-responsibility package**,
including import/view orchestration, transport-adjacent and persistence-adjacent adapters, and
mutation coordination. The refactor MUST retain the imports boundary and make its dependencies
shallower; it MUST NOT delete or rename the boundary merely because its internals are mixed.

## 4. Public Contract and Behavior Freeze Map

### 4.1 Normative refactor requirements

| ID | Requirement | Current owner or required owner repair |
| --- | --- | --- |
| IRT-REQ-001 | The refactor MUST preserve the authority hierarchy in §1.2 and MUST NOT implement a proposed owner repair before coordinated adoption. | Repository procedure and Core 00 |
| IRT-REQ-002 | Structural slices MUST preserve the existing ten public import operations, operation IDs, request and response envelopes, WebSocket non-surface, and existing generated public types. RS-09 MUST add the compatible operator-region operation specified in §4.2 without narrowing an existing operation. | Core 01 and authored imports OpenAPI |
| IRT-REQ-003 | Core MUST own analytical dispatch, target selection, lifecycle, Core-issued capabilities, authorization, idempotency, cancellation, unit/session outcomes, and job publication. Each target NLSpec MUST exclusively own exact target request/result members, mapping, diagnostics, target errors, and owner resource mutation. | Proposed coordinated Core 00/Core 01/target-owner repair |
| IRT-REQ-004 | Every analytical target MUST register one `cartulary.imports.analytical_facade_binding.v1`; the binding MUST resolve each referenced schema exactly once and convey the semantic slots in §4.4. | Proposed Core 01 repair and machine projection |
| IRT-REQ-005 | One import-unit commit MUST atomically contain the selected owner effects, owner-required audit/revision/projection effect or durable obligation, unit outcome, apply journal, idempotency success, immutable owner result, transaction participants, and a recoverable completion fact. | Proposed clarification of Core 01 REQ-01-620c with Core 03 unit atomicity |
| IRT-REQ-006 | Session/job finalization MUST be idempotent, MUST derive terminal state and ordered resource references from durable unit outcomes, and MUST NOT create owner resources. | Proposed Core 01 clarification |
| IRT-REQ-007 | Immediately before authoritative unit mutation, apply MUST rederive current incident visibility, membership, role, lifecycle, extension claim, target availability, and facade availability. | Core 04 and Core 01 |
| IRT-REQ-008 | Authorization and incident lifecycle checks MUST share the commit serialization boundary: whichever valid state change commits first determines the other operation's outcome. | Core 04 acceptance behavior |
| IRT-REQ-009 | Selection MUST reject a proposed overlapping persisted unit set atomically; apply MUST independently recheck overlap; concurrent conflicting selections MUST serialize so at most one succeeds. | Core 03 |
| IRT-REQ-010 | A skipped unit MUST retain its approved mapping. Reselection MUST recompute its state and the session state without creating a new mapping or fingerprint. | Core 03 |
| IRT-REQ-011 | `write_null` MUST be the only public and newly persisted null token. `omit_field` MUST omit the value and permit owner create defaults. `write_null` MUST create explicit null only for nullable create fields. | Core 01/Core 03 |
| IRT-REQ-012 | Core import top-level errors MUST remain closed. Target failures MUST be schema-validated nested owner details translated through the registered analytical binding. Unknown owner errors MUST fail closed. | Core 01 and target owner |
| IRT-REQ-013 | Discovery MUST cover CSV file, worksheet used range, table, static single-sheet single-rectangle named range, and operator-selected region. Presentation metadata MUST NOT change discovered values or rectangles. Formulas MUST NOT execute. | Core 03 and Core 01 |
| IRT-REQ-014 | One governed `cartulary.import_target_registry.v1` projection MUST generate backend, frontend, adapter, verification, and integrity outputs deterministically. Tests or source scans MUST NOT become target authority. | Proposed Core 01 projection |
| IRT-REQ-015 | The Import Assistant MUST consume only the generated public target projection, MUST hide reserved targets, MUST claim-gate Network Flow, and MUST NOT fall back to a manually maintained ID set. | Proposed generated web contract |
| IRT-REQ-016 | Every active test MUST have exactly one owner, semantic family, row ID, exact selector, evidence class, and verification set. Generated topology MUST NOT be hand-edited. | Testing Harness NLSpec |
| IRT-REQ-017 | Imports MUST construct no concrete peer store, perform no cross-owner reference SQL, and directly write no source-owner, analytical, projection, workbook, or grid-vendor state. | Core 01 dispatcher/owner-facade boundary |
| IRT-REQ-018 | Structural authorization and observable-correction authorization MUST remain separate. Passing characterization does not authorize a correction, and adopting a behavior owner does not authorize production mutation. | This handoff's execution discipline |

### 4.2 Public HTTP freeze

| Operation | Frozen request behavior | Frozen success behavior | Refactor rule |
| --- | --- | --- | --- |
| `POST /api/v1/import-sessions` | Existing upload envelope, metadata, media, idempotency, auth, and limits | Common job and import-session discovery result | Structural work MUST NOT change the route, operation ID, envelope, or source limits. |
| `GET /api/v1/import-sessions/{import_session_id}` | Existing visible session lookup | Existing import-session resource | State names and required members MUST remain stable. |
| `GET /api/v1/import-sessions/{import_session_id}/units` | Existing paging and visibility | Existing ordered import-unit list | Discovery order and paging MUST remain stable during structural work. |
| `GET /api/v1/import-sessions/{import_session_id}/units/{import_unit_id}` | Existing session/unit lookup | Existing import-unit resource | Mapping, warning, and state serialization MUST remain stable. |
| `GET /api/v1/import-sessions/{import_session_id}/units/{import_unit_id}/preview` | Existing bounded preview request | Existing columns, rows, and truncation | Parser corrections require separate authorization. |
| `POST .../mapping-preview` | Existing analytical target/mapping candidate | Existing extension preview wrapper | Internal facade repair MUST NOT change this public request. |
| `PUT .../mapping` | Existing client transaction and exhaustive mapping | Existing import-unit resource | `write_null` correction MUST preserve the public token and fingerprint contract. |
| `POST .../select` | Existing client transaction | Existing session/selection/unit result | Backend overlap and reselection are authorized corrections, not structural side effects. |
| `POST .../skip` | Existing client transaction and optional reason | Existing session/selection/unit result | Skip/reselect correction MUST preserve the envelope. |
| `POST /api/v1/import-sessions/{import_session_id}/apply` | Existing client transaction and optional selected IDs | Common job; terminal import session and owner resource references | Unit/finalizer repair MUST preserve the public request and operation ID. |
| `POST /api/v1/import-sessions/{import_session_id}/units/{base_unit_id}/regions` | Additive `client_txn_id` plus one-based inclusive `source_rect`; the base unit MUST be the worksheet used-range unit | Created or exactly replayed durable `operator_region` import unit | RS-09 owns this eleventh operation; it MUST remain additive and pass OpenAPI compatibility. |

No import-specific WebSocket route or event exists. The refactor MUST NOT invent one. Source-owner
collaboration or projection effects remain owner-specific postconditions behind owner facades.
Saved-view behavior remains outside imports. No public `view_schema_resource_v2.import_target` field
or new target-discovery route is required while frontend and backend ship together.

### 4.3 Analytical ownership split

| Contract concern | Required primary owner | Secondary-owner boundary |
| --- | --- | --- |
| Dispatch, target selection, opaque source/actor/mapping/idempotency capabilities, public wrapper, unit/session outcomes, cancellation, and job publication | Core 01 | A target MAY consume these facilities but MUST NOT redefine Core lifecycle or public import behavior. |
| Exact target preview/apply request and result members, target mapping, target validation, diagnostics, owner errors, and resource mutation | Adopted target NLSpec | Core MUST register schema IDs and common semantic obligations but MUST NOT duplicate target member lists. |
| Target recognition and contract-owner precedence | Core 00 | The owner matrix MUST identify the split before the repaired interface is implementable. |
| Network Flow import request/result schemas and table commit semantics | Network Flow Activity NLSpec | Network Flow MUST NOT redefine Core authorization, session lifecycle, idempotency, or job publication. |

### 4.4 `cartulary.imports.analytical_facade_binding.v1`

Every member is required. The binding is internal and machine-readable.

| Member | Type or closed value | Rule |
| --- | --- | --- |
| `schema_id` | exact string | MUST equal `cartulary.imports.analytical_facade_binding.v1`. |
| `target_kind` | registered token | Identifies the analytical target family. |
| `extension_profile_id` | registered profile ID | Identifies the owning claimed extension. |
| `owner_contract_ref` | owner ID plus major | MUST resolve to one adopted target owner. |
| `facade_id` | registered internal facade ID | MUST resolve to exactly one application binding. |
| `contract_major` | positive integer | MUST match the binding and referenced schemas. |
| `mapping_schema_id` | governed schema ID | Exact target-owned mapping schema. |
| `preview_request_schema_id` | governed schema ID | Exact target-owned preview request schema. |
| `preview_result_schema_id` | governed schema ID | Exact target-owned preview result schema. |
| `apply_request_schema_id` | governed schema ID | Exact target-owned apply request schema. |
| `apply_result_schema_id` | governed schema ID | Exact target-owned apply result schema. |
| `commit_protocol_id` | governed protocol ID | MUST identify the Core unit-commit protocol. |

The binding MUST convey these semantic slots without requiring common target member names:

| Semantic slot | Core obligation | Target obligation |
| --- | --- | --- |
| Session and unit identity | Supply authorized immutable identities | Validate request-schema placement and target use |
| Actor authorization | Supply transaction-current opaque actor context | Consume it only through the Core authorization boundary |
| Source bytes | Supply read-only capability bound to exact bytes, incident, unit, target, and digest | Read only through the capability and revalidate digest |
| Mapping preview | Supply proposed target mapping candidate | Validate and return target-owned materialized mapping |
| Apply mapping | Supply immutable approved mapping, fingerprint, and approval reference | Revalidate and consume the approved mapping |
| Idempotency | Supply opaque context bound to admitted request | Join the unit commit and return the immutable prior result on replay |
| Operation schema | Select the binding's exact operation schema | Validate exact target request/result shape |
| Owner result | Validate registered schema and translate errors | Return only target-owned result and safe diagnostics |

For Network Flow, the exact schema IDs remain:

- `cartulary.network_flow.import_preview_request.v1`
- `cartulary.network_flow.import_preview_result.v1`
- `cartulary.network_flow.import_apply_request.v1`
- `cartulary.network_flow.import_unit_result.v1`

The following compatibility map is migration guidance, not normative duplicate payload ownership:

| Former Core Table 17.2-F concept | Network Flow representation |
| --- | --- |
| `incident_id`, `actor_user_id` | `actor_context_ref`, Core-bound to actor, incident, operation, role, and target |
| `import_source_capability` | `source_stream_ref` |
| Source content digest | `source_content_sha256` |
| Parser, locator, source revision, descriptors | Bound into source capability and approved mapping; not separately trusted owner input |
| `proposed_owner_mapping` | `mapping_candidate` |
| `canonical_owner_mapping` | `approved_mapping` |
| `mapping_fingerprint` | `mapping_fingerprint` |
| Core `client_txn_id` | `idempotency_context_ref` bound to admitted Core transaction |
| Generic response fields | Exact target-owned preview or apply result |

An interim adapter MAY translate current internal objects. It MUST remain private to imports, MUST
NOT log capabilities or source locations, and MUST be removed when the binding is canonical.

### 4.5 Unit commit and session/job finalization

The two-level model is mandatory after coordinated owner adoption:

1. **Unit commit.** The owner resource or rows, owner audit, revisions/projections or durable
   publication obligation, import-unit result, apply journal, idempotency success, immutable owner
   result, required transaction participants, and recovery fact MUST commit atomically. A
   precommit failure or observed cancellation MUST leave none of those authoritative effects.
2. **Session/job finalization.** After the frozen selected units have durable outcomes, an
   idempotent finalizer MUST derive `applied`, `partially_applied`, `failed`, or `canceled`, publish
   the terminal common-job result, and return ordered committed resource references. It MUST NOT
   create an owner resource.

A crash after unit commit and before finalization MUST recover the committed unit result without
recreating the resource. A single-unit implementation MAY combine the unit and terminal job commit
only when it has identical recovery and caller-visible behavior.

### 4.6 Conformance-correction decisions

| Area | Required behavior | Default or omitted case | Compatibility class |
| --- | --- | --- | --- |
| Apply authorization | Revalidate current session, incident, membership, role, lifecycle, extension claim, target, and facade immediately before mutation. | Admission authorization alone is insufficient. | Behavior correction |
| Authorization race | Bind revalidation to the unit-commit serialization boundary. The first committed state change governs the other operation. | No best-effort or cached-role fallback. | Behavior correction |
| Unit atomicity | Commit all owner and import-unit effects or none. | A later unit failure does not roll back earlier committed units. | Behavior correction/owner repair |
| Partial session | At least one committed plus at least one failed/canceled unit derives `partially_applied`. No committed units derives `failed` unless cancellation owns the outcome. | Session-wide rollback is forbidden. | Behavior correction |
| Overlap | Selection atomically validates the proposed persisted set; apply rechecks it; concurrent conflicts serialize. | Use existing `import_apply_blocked` / `overlapping_units`. | Behavior correction |
| Reselection | Preserve mapping and fingerprint; recompute unit and session readiness. | Applying and terminal non-skipped units retain current conflict behavior. | Behavior correction |
| Empty value | `omit_field` omits the owner input; `write_null` sends explicit null only to nullable create fields. | Omission applies ordinary owner defaults. | Internal correction unless retained legacy data exists |
| Error ownership | Core top-level codes remain closed; owner detail is nested and schema-validated. | Unknown/unregistered owner tokens fail closed. | Contract-compatible behavior correction |
| XLSX locators | Admit used range, table, static single-sheet/single-rectangle name, and operator region in addition to CSV file. | Dynamic, external, and multi-area names fail as unsupported. | Additive behavior correction |
| Presentation neutrality | Hidden state, filters, sorting, and styles do not alter source rectangles or values; formulas never execute. | Only cached formula values may be read; required missing cache uses `formula_cached_value_missing`. | Behavior correction |

RS-08 confirmed that public validation and approved mapping persistence have always admitted only
`write_null`; the sole live `use_null` branch was unreachable through the closed decoder. Migration
00050 performs the retained-data preflight and aborts before schema change if manually inserted
`approved_mapping_json` contains `use_null`. No compatibility decoder or synthetic fingerprint
rewrite exists: retained invalid state must be repaired explicitly, while all runtime and new
persistence paths emit only `write_null`.

### 4.7 Authorization, cancellation, replay, and error translation

| Condition | Unit outcome | Session/job outcome | Forbidden effect |
| --- | --- | --- | --- |
| Authorization/lifecycle failure before any unit commits | Current and remaining selected units fail deterministically | Session `failed`; common authorization or `incident_closed` failure | Owner mutation, journal success, resource ref, idempotency success |
| Authorization/lifecycle failure after earlier units commit | Earlier units remain applied; current and remaining units fail | Session `partially_applied` | Relabeling or rolling back earlier success |
| Cancellation before current unit commit | Current unit rolls back | Derived canceled/partial result from durable outcomes | Partial owner or import success |
| Cancellation after unit commit | Unit remains committed | Finalizer publishes/replays committed outcome | Deleting or relabeling committed success |
| Exact replay | Return immutable committed unit/session result | No new finalization side effect | Reauthorization that creates a second mutation |
| Replay detail read after role change | Recheck visibility before returning sensitive referenced resources | Return only currently visible detail | Leaking hidden owner resources |

Opaque actor, source, mapping-approval, and idempotency references MUST be bound to the intended
actor, incident, operation, session, unit, target, and invocation or authorization epoch. They MUST
NOT be reusable public bearer credentials and MUST NOT appear in logs, job results, diagnostics, or
audit payload values.

| Owner condition | Core top-level result | Nested owner detail |
| --- | --- | --- |
| Source digest, descriptor, or fingerprint changed | `import_apply_blocked` / `source_changed` | Optional registered source-change detail without bytes, paths, or capabilities |
| Network Flow has no data rows | `import_apply_blocked` / `owner_apply_validation_failed` | `network_flow_no_data_rows` plus registered reason |
| Network Flow rejects all rows | `import_apply_blocked` / `owner_apply_validation_failed` | `network_flow_all_rows_rejected` plus bounded diagnostics |
| Facade or schema missing/incompatible | `import_apply_blocked` / `owner_apply_contract_unavailable` | No internal stack, package, or registration path |
| Owner result is structurally invalid | `import_apply_blocked` / `owner_apply_validation_failed` | Safe schema ID and validation class only |
| Owner code is unknown | `import_apply_blocked` / `owner_apply_validation_failed` | Unregistered token MUST NOT be echoed |
| Mapping preview owner validation fails | `invalid_import_request` / `owner_preview_validation_failed` | Registered bounded preview detail |

## 5. Coupling and Boundary Findings

| Finding | Evidence | Risk | Classification | Proposed owner | Required planning action and requirement |
| --- | --- | --- | --- | --- | --- |
| Core and Network Flow duplicated exact analytical facade authority | RS-01 substantive commit `f05d3366` adopted the coordinated ownership split and exact target-owned schemas | Resolved interface incompatibility | `resolved_rs01` | Coordinated Core/Network Flow owners | Core owns orchestration and bindings; Network Flow exclusively owns its exact request/result/error schemas. |
| Imports constructed seven concrete peer stores | RS-03 substantive commit `c372c1ba` removed the constructors from `owner_apply.go` | Resolved cross-owner composition and change blast radius | `resolved_rs03` | application composition root | The generated join and exact application registry now supply source-owner-constructed facades. |
| Source-owner validation/default/reference logic was duplicated in imports | RS-03 moved the remaining user/record checks into artifacts, assessments, evidence, and tasks/decisions owners | Resolved drift and inconsistent ownership | `resolved_rs03` | each source owner | Boundary tests prohibit the former Imports-owned validation and target branches. |
| Store writes import-owned tables directly | `store.go` and imports migrations | Low when encapsulated | `intentional/no_action` | imports | Keep behind Store; do not generalize it. |
| Apply coordination performed cross-owner reference SQL | RS-03 removed direct `users` and `records` queries from Imports | Resolved owner-boundary bypass | `resolved_rs03` | relevant source owner | Source owners now validate their references in the unit transaction behind the selected facade. |
| Timeline used a separate row-by-row Imports apply path | RS-04 substantive commit `7e891c66` added the Timeline owner facade and removed Timeline construction and dispatch from Imports | Resolved atomicity and owner-boundary divergence | `resolved_rs04` | Timeline owner behind Imports coordination | Timeline now reserves owner mutation sequences and commits all row effects through the common unit transaction and journal. |
| HTTP, jobs, discovery, mapping, and apply shared `routes.go` | RS-05 substantive commit `7bbbb00d` replaced the monolith with explicit service, handler, job, mapping, discovery, and apply files | Resolved structural blast radius | `resolved_rs05` | imports internal service/adapters | Boundary evidence requires the responsibilities to remain separated while preserving the public package facade. |
| Unit publication and session/job finalization were conflated | RS-06 substantive commit `75c7c2ec` plus RS-11 transition-lock closure `575f1999` | Resolved partial-result and duplicate-recovery risk | `resolved_rs06_rs11` | imports, target owner, jobs | Atomic durable unit outcomes and outcome-only idempotent finalization now serialize with cancellation. |
| Current role was not visibly rechecked at mutation commit | RS-06 transaction-current authorization and race fixtures | Resolved unauthorized delayed-mutation risk | `resolved_rs06` | imports using platform auth | Membership, role, lifecycle, claim, target, source, and mapping state are revalidated inside the unit transaction. |
| Overlap was blocked only in the frontend | RS-07 substantive commit `356281c0` | Resolved alternate-client conflict | `resolved_rs07` | imports | Selection and apply both enforce canonical rectangle overlap under locks. |
| Skipped units could not visibly be reselected | RS-07 substantive commit `356281c0` | Resolved incorrect workflow state | `resolved_rs07` | imports | Reselection retains the approved mapping and fingerprint and recomputes readiness. |
| XLSX discovery lacked owned locator kinds and neutrality evidence | RS-09 substantive commit `fbae9afe` | Resolved missing or presentation-dependent units | `resolved_rs09` | imports source adapter | Bounded used ranges, tables, static names, regions, hidden data, formulas, and archive/security cases have exact fixtures. |
| Public `write_null` reaches an internal `use_null` switch | RS-08 substantive commit `64cdc912` replaced the switch, added retained-data preflight, and preserved canonical fingerprints | Resolved null rejection and vocabulary drift | `resolved_rs08` | imports contract/facade | Migration 00050 refuses manually retained `use_null`; runtime and new persistence accept only `write_null`. |
| Core and target error vocabularies need explicit translation | RS-08 added the closed common owner-error boundary, exact Network Flow union/translator, durable safe detail, and fail-closed fallback | Resolved client drift and unsafe leakage | `resolved_rs08` | Core plus target owner | Registered schema/binding identities validate before nested detail crosses the Imports boundary. |
| Frontend hardcoded 14 importable IDs | RS-10 substantive commit `b08dfaf1` | Resolved frontend/backend drift | `resolved_rs10` | Core import-target projection | Generic and analytical consumers use the generated 18-row projection and fail closed without fallback. |
| Verification rows omitted target, boundary, and security cases | RS-11 substantive commit `575f1999` and final catalog/check evidence | Resolved incomplete evidence accounting | `resolved_rs11` | imports/source owners/harness | All active tests are owned once; generated topology and duration baselines are current and broad closure passes. |
| Platform archive/auth/job dependencies occur at adapter boundaries | `limits.go`, `routes.go`, job finalizer port | Acceptable when isolated | `intentional/no_action` | platform mechanics plus imports adapter | Preserve ports; keep platform mechanics out of owner rules. |
| No direct grid-vendor coupling was found | Targeted searches | None on current evidence | `intentional/no_action` | grid adapter if later applicable | Retain boundary checks only. |
| No target-specific test-util mutation path was found | Integration test composition | None on current evidence | `intentional/no_action` | test-util owner | Reassess only if a later authorized slice touches test utilities. |
| Generated surfaces are downstream projections | Generated artifact policy | Hand-edit/drift risk | `intentional/no_action` | contract owners and generators | Change authored inputs and regenerate; never hand-edit generated roots. |

## 6. Refactor Workstreams and Execution Gates

### 6.1 Binary execution gates

These gates replace unresolved planning blockers. A gate is a prerequisite with a binary exit
condition, not a design choice left to an implementer.

| Gate | Required action | Status | Exit condition | Blocks |
| --- | --- | --- | --- | --- |
| GATE-01 Characterization | Add route, target, state, owner-effect, security, boundary, and frontend characterization from registry-driven inputs. | PASS | Current behavior is frozen; known non-conformance is labeled; required narrow baseline is green. | All structural slices |
| GATE-02 Coordinated owner repair | Adopt the IRT-REQ-003 through IRT-REQ-006 ownership split in Core 00, Core 01, Network Flow, and governed schemas as one logical change. | PASS | No exact payload has two owners; unit commit and session finalization are coherent. | Analytical facade and transaction changes |
| GATE-03 Correction authorization | Adopt one Imports Conformance Corrections Authorization row per observable correction. | PASS | Each correction has owner requirements, compatibility class, tests, migration posture, rollback boundary, approver, and adopted status. | RS-06 through RS-10 |
| GATE-04 Registry projection | Adopt and generate `cartulary.import_target_registry.v1`. | PASS | Backend, frontend, adapter, verification, and integrity outputs validate and share one source digest. | Registry injection and frontend cleanup |
| GATE-05 Structural authorization | Explicitly authorize behavior-preserving registry injection and file-level decomposition. | PASS | GATE-01, GATE-02, and GATE-04 pass; authorized files and rollback boundaries are recorded. | RS-03 through RS-05 |
| GATE-06 Correction implementation | Authorize and implement each observable correction independently. | PASS | Each selected correction's current and normative tests pass with required migration/compatibility evidence. | Final validation |
| GATE-07 Harness closure | Add exact authored owner/family rows, regenerate topology, and run narrow-to-broad checks. | PASS | No uncovered target, duplicate selector, unowned test, or generated drift remains. | Final handoff |

The conformance authorization artifact required by GATE-03 MUST contain:

| Field | Required meaning |
| --- | --- |
| `correction_id` | Stable identity for authorization, atomicity, overlap, reselection, null, errors, or discovery |
| `normative_owner_requirements[]` | Exact Core/subsystem requirement and acceptance IDs |
| `observable_change` | HTTP, state, stored-data, job, or frontend behavior affected |
| `compatibility_class` | `behavior_correction`, `additive_contract`, `data_migration`, or `internal_only` |
| `characterization_prerequisites[]` | Current-behavior tests required before correction |
| `normative_acceptance_tests[]` | Tests that prove the adopted behavior |
| `migration_requirement` | `none`, `decoder`, `data_migration`, or `regenerate_contracts` |
| `rollback_boundary` | Exact code, contract, data, and generated artifacts that revert together |
| `authorization_owner` | Person or process permitted to approve the behavior class |
| `status` | `proposed`, `adopted`, `implemented`, or `verified` |

**Imports Conformance Corrections Authorization**

The implementation request dated 2026-07-28 is the authorizing process for these rows. The adopted
owner requirements named below control behavior; this tracker records execution scope and does not
replace those owners.

| `correction_id` | `normative_owner_requirements[]` | `observable_change` | `compatibility_class` | `characterization_prerequisites[]` | `normative_acceptance_tests[]` | `migration_requirement` | `rollback_boundary` | `authorization_owner` | `status` |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| `imports.unit_commit_authorization_recovery.v1` | `REQ-01-620b..620c`, `REQ-03-293`, `AC-467..467A` | Unit mutation uses transaction-current authority, one durable atomic outcome, crash recovery, and outcome-only session/job finalization. | `data_migration` | RS-00 route, owner-effect, replay, and known-gap probes | Participant failure injection; role, membership, lifecycle, claim, target, source, and mapping races; crash-before/after-commit; partial cancellation; exact replay | `data_migration` | Migration `00049`, unit coordinator/store, auth ports, job recovery/finalizer, owner participants, and their tests revert together; terminal historical sessions remain untouched | 2026-07-28 implementation request plus adopted Core owners | `verified` |
| `imports.selection_lifecycle.v1` | `REQ-03-183`, `REQ-03-192`, `AC-065..066`, `AC-264` | Selection and apply reject overlapping rectangles; skipped units retain approved mappings and may be reselected; intentional re-import requires a fresh session. | `behavior_correction` | RS-00 session/unit route and frontend-state characterization | Raw-HTTP and concurrent overlap; apply-time recheck; skip/reselect and mapping retention; idempotency replay; fresh-session duplicate-source cases | `none` | Imports state service/store, route errors, frontend state handling, and selected tests revert together | 2026-07-28 implementation request plus adopted Core owners | `verified` |
| `imports.write_null.v1` | `REQ-01-469`, `REQ-01-474..475`, `AC-264`, `AC-468` | Public and internal empty-value policy uses only `write_null`; nullability/default behavior and fingerprints become deterministic. | `behavior_correction` | RS-00 owner-facade token characterization | Required, optional, defaulted, nullable, and non-nullable omit-versus-null matrix plus replay fingerprint stability | `none` | Imports decoding/normalization/fingerprinting, owner-facade token, affected tests, and generated contracts if changed revert together; no `use_null` compatibility reader is permitted | 2026-07-28 implementation request plus adopted Core owners | `verified` |
| `imports.owner_error_translation.v1` | `REQ-01-471`, `REQ-01-475`, `REQ-01-620a`, `NF-REQ-088d`, `AC-265` | Owner failures use a typed safe union and registered translation; unknown internal errors fail closed without disclosure. | `behavior_correction` | RS-00 raw-owner-error characterization and current facade cases | One fixture per registered translation; invalid result; unknown code fallback; safe-detail schema and API/log disclosure scans | `regenerate_contracts` | Core error registry, analytical binding/translator, Imports HTTP mapping, target errors, OpenAPI projections, and tests revert together | 2026-07-28 implementation request plus adopted Core and Network Flow owners | `verified` |
| `imports.xlsx_locators.v1` | `REQ-01-472`, `REQ-01-620e`, `REQ-03-181..182`, `REQ-03-181a`, `AC-064`, `AC-264B` | XLSX discovery includes deterministic used ranges, tables, static named ranges, and durable operator regions independent of presentation state; a compatible eleventh operation creates regions. | `additive_contract` | RS-00 route-parser and hidden-sheet characterization plus bounded-XLSX baseline | Locator ordering/replay/overlap; hidden/filter/sort/style neutrality; cached/missing formulas; malformed/archive-limit/external-link/macro cases; OpenAPI compatibility | `regenerate_contracts` | XLSX index/decoder, operator-region migration/state, authored OpenAPI, generated protocol clients, frontend region flow, fixtures, and tests revert together | 2026-07-28 implementation request plus adopted Core owners | `verified` |
| `imports.frontend_registry_consumption.v1` | `REQ-01-620`, `REQ-03-181a`, `AC-264B`, `AC-464` | Generic and analytical frontend flows consume generated target semantics, preserve claim gating, and use the durable operator-region route without a manual fallback list. | `behavior_correction` | RS-00 frontend target and workflow characterization; generated RS-02 registry parity | Exact 18-row disposition; generic/analytical routing; claimed/unclaimed Network Flow; region creation; server revalidation; no-fallback source scan and browser flow | `regenerate_contracts` | Authored target catalog, regenerated TS projection, generic assistant, Network Flow workspace, region UX, and tests revert together | 2026-07-28 implementation request plus adopted Core and Network Flow owners | `verified` |

**Imports Structural Refactor Authorization**

The implementation request dated 2026-07-28 authorizes these behavior-preserving structural
boundaries now that GATE-01, GATE-02, and GATE-04 pass.

| Slice | Authorized substantive scope | Required behavior boundary | Rollback boundary | Status |
| --- | --- | --- | --- | --- |
| RS-03 | `internal/modules/imports/owner_apply.go`, the narrow `ownerfacade` contract, source-owner adapter constructors, and application composition under `internal/app` | Preserve every characterized owner result while resolving each enabled view target exactly once from the generated registry; Imports retains no concrete peer store or peer-table SQL | Revert registry injection, source-owner adapters, assembly validation, and their tests together | `implemented` |
| RS-04 | Timeline-owned import facade, Imports registry registration, application composition, and Timeline/import integration tests | Preserve Timeline defaults, provenance, revisions, projections, events, replay, and public shapes while moving the apply path behind the common coordinator | Revert Timeline facade, registration, composition, and effect tests together | `implemented` |
| RS-05 | File-level extraction inside the existing public Imports package for HTTP, services, jobs, discovery/mapping, apply, persistence, and XLSX responsibilities | Preserve public symbols, route/error behavior, transactions, parser outcomes, and all RS-00 characterization; introduce no new cross-package behavior owner | Revert each extraction with its moved tests; no schema, migration, or public contract rollback is permitted in this structural slice | `implemented` |

### 6.2 Workstreams

| Workflow ID | Name | Class | Required previous workflows/gates | Required subsequent workflows | Goal | Validation | Handoff checkpoint |
| --- | --- | --- | --- | --- | --- | --- | --- |
| WF-00 | Scope, source, and tracker posture | root | None | WF-01 through WF-04 | Fix authority, baseline, language, and write boundary | `make lint-markdown` | Tracker is internally coherent and only it changed. |
| WF-01 | Live target inventory | chain | WF-00 | WF-02 through WF-04 | Account for every file, caller, dependency, and test | Repository inspection | All 32 tracked files have target-specific rows. |
| WF-02 | Contract and owner resolution | chain | WF-01 | WF-05 | Make ownership and interfaces decision-complete and adopt the coordinated owner correction before production changes | Human owner review; owner-selected documentation and shape checks | GATE-02/03 pass; exact analytical ownership, two-level completion, and correction authorization are adopted. |
| WF-03 | Characterization and evidence design | parallel | WF-01 | WF-05, WF-07 | Define exact coverage and accounting for all 18 targets | Owner slices and frontend checks | GATE-01 plan is complete. |
| WF-04 | Boundary and projection design | parallel | WF-01 | WF-05 | Specify owner registry, composition, and generated target projection | Boundary and generation checks | GATE-04 passes; all five projections share source digest `fdb8081f3b974b14fb89cea1e4d81de1a97b75086110f942e5a61e2bb2f9d99d`. |
| WF-05 | Structural sequence | chain | WF-02 through WF-04; GATE-01/02/04/05 | WF-06 | Inject facades and split responsibilities without behavior changes | Narrow owner and boundary targets | Imports is a thin coordinator with characterized behavior intact. |
| WF-06 | Conformance corrections | chain/parallel | WF-05; GATE-03 | WF-07 | Implement independently authorized observable corrections | Per-correction tests | Each correction is implemented and verified independently. |
| WF-07 | Harness and final handoff | chain | Applicable WF-05/06; GATE-07 | None | Complete accounting and narrow-to-broad evidence | `make agent-finalize`, owner slices, `make check` | Results, failures, run roots, and skips are recorded. |

## 7. Proposed Refactor Slice Plan

| Slice ID | Depends on | Intended change | Files/packages likely involved | Contract risks | Tests to add or preserve | Validation | Rollback and completion |
| --- | --- | --- | --- | --- | --- | --- | --- |
| RS-00 | None | Add behavior-freeze characterization for all routes, targets, states, security transitions, owner effects, boundaries, and frontend selectors. | Imports/source-owner tests, web tests, authored harness inputs later | Characterization MUST label known non-conformance and MUST NOT become normative authority. | §8 matrices | Owner slices and frontend checks | Revert only new tests; complete when GATE-01 passes. |
| RS-01 | RS-00 | Adopt coordinated owner repair for analytical ownership and two-level commit; no production code. | Core 00, Core 01, Network Flow owner and governed schemas in a separate authorized owner task | An intermediate adoption could remain self-contradictory. | Owner contract/fixture validation | Owner-selected documentation and contract targets | Revert the logical owner repair together; complete when GATE-02 passes. |
| RS-02 | RS-01 | Author and generate `cartulary.import_target_registry.v1` and integrity projections; no hand edits to outputs. | Core-owned contract input, generators, generated Go/TS/verification projections | Target availability or schema drift | Generator validation and 18-row parity | `make generate-drift`; generated policy checks | Revert authored input and regenerate; complete when GATE-04 passes. |
| RS-03 | RS-00 through RS-02 | Inject one application-composed owner registry; remove concrete peer-store construction and cross-owner SQL from imports. | `owner_apply.go`, ownerfacade, application assembly, peer facades | Owner order, validation, defaults, revisions, projection effects | Owner matrix, missing/duplicate bindings, rollback | Imports owner slice; backend boundary check | Revert registry injection as one slice; complete when exactly one owner is selected and imports has no concrete stores. |
| RS-04 | RS-03 | Route Timeline through the same owner-create registry. | Imports apply path, Timeline facade, application composition | Timeline defaults, event/revision order | Existing Timeline case plus rollback/replay/projection/effect cases | Service-backed imports and Timeline owner slices | Restore Timeline registration and adapter together; complete on effect parity. |
| RS-05 | RS-04 | Split HTTP handlers, service, job coordination, discovery/mapping, apply coordination, and Store by file responsibility inside the public imports package. | Primarily routes, store, XLSX, API, job/facade files | Accidental route, error, transaction, or parser change | Entire RS-00 suite | Imports slice and boundary checks | Revert each extraction independently; complete when public symbols and behavior are unchanged. |
| RS-06 | RS-01, RS-03, RS-05; GATE-03 | Add the next authored migration, transaction-current authorization, durable unit outcomes, and two-level unit/finalizer commit. | Imports service/Store/jobs, auth port, revisions, target participants, migration | Observable auth, transaction, recovery, and terminal-state changes | Role/membership/close/claim races, failure injection, crash recovery, cancellation, replay | Service-backed owner slices, migration drift, and `make test-fast` | Revert the migration and complete auth/transaction slice together; complete when IRT-REQ-005 through 008 pass. |
| RS-07 | RS-06; GATE-03 | Enforce backend overlap and skipped-unit reselection; require a fresh session for intentional re-import. | Store/service state machine and frontend tests | Observable state/error changes | Raw HTTP overlap, concurrent select, skip/reselect, mapping retention, fresh-session duplicate source | Service-backed imports and frontend unit | Revert state-machine slice; complete when IRT-REQ-009/010 pass. |
| RS-08 | RS-07; GATE-03 | Replace internal `use_null`, implement typed registered error translation, and preserve canonical fingerprints. | API, ownerfacade, route error translation, owner binding | Stored mapping and client error compatibility | Empty policies, retained-data preflight, every translation row, unknown owner error | Imports slice; compatibility/generation checks if contract changes | Revert implementation and any migration together; complete when IRT-REQ-011/012 pass. |
| RS-09 | RS-08; GATE-03 | Add required XLSX locator kinds, presentation neutrality, bounded workbook indexing, and the additive operator-region operation. | XLSX adapter, HTTP/OpenAPI, owner-neutral tabular-ingest primitives if needed, fixtures | Discovery order, locator, warnings, source bounds, public compatibility | Used range, table, named range variants, region/replay, hidden state, formula cache, limits | Service-backed imports slice and OpenAPI compatibility | Revert the authored API and locator implementation together; complete when IRT-REQ-013 passes. |
| RS-10 | RS-02, RS-07, RS-09; GATE-03/04 | Replace frontend hardcoded target IDs with generated semantic catalog and add the operator-region flow. | Generated UI contracts, Import Assistant, coordinator/tests | Target visibility, claimed/unclaimed workflow, and region selectors | 18-row disposition, selector stability, region creation, no fallback, server revalidation | Frontend unit/typecheck/boundary/browser checks | Revert authored projection and consumer together; complete when IRT-REQ-014/015 pass. |
| RS-11 | All applicable slices | Add exact harness rows, regenerate topology, finalize, and run risk-appropriate broad checks. | Authored verification/test-family/catalog inputs and generated topology | Missing/duplicate accounting and hand-edit risk | Every active test mapped exactly once | Owner slices, generate drift, `make agent-finalize`, `make check` | Revert authored inputs and regenerate; complete when GATE-07 and IRT-REQ-016 pass. |

## 8. Validation and Evidence Plan

### 8.1 Current 18-target evidence matrix

| Target selector | Availability | Facade | Required minimum evidence |
| --- | --- | --- | --- |
| `cartulary.view.timeline.v2` | enabled/selectable | owner create | Valid apply, Timeline defaults, revision, projection, collaboration, rollback |
| `cartulary.view.hosts.v1` | enabled/selectable | owner create | Valid apply, authoritative row/version, host validation, projection, rollback |
| `cartulary.view.identities.v1` | enabled/selectable | owner create | Valid apply, identity validation/defaults, projection, rollback |
| `cartulary.view.evidence.v1` | enabled/selectable | owner create | Valid apply, evidence owner effects, revision/journal, rollback |
| `cartulary.view.notes.v1` | enabled/selectable | owner create | Valid note variant, owner defaults/references, projection, rollback |
| `cartulary.view.indicators.v1` | enabled/selectable | owner create | Valid indicator normalization/deduplication, projection, rollback |
| `cartulary.view.assessments.v1` | enabled/selectable | owner create | Valid assessment, direct references, projection, rollback |
| `cartulary.view.task_requests.v1` | enabled/selectable | owner create | Valid task request, references/defaults, projection, rollback |
| `cartulary.view.decisions.v1` | enabled/selectable | owner create | Valid decision, references/defaults, projection, rollback |
| `cartulary.view.parties.v1` | enabled/selectable | owner create | Valid party, incident/reference validation, projection, rollback |
| `cartulary.view.comm_log.v1` | enabled/selectable | owner create | Valid artifact variant, party references, projection, rollback |
| `cartulary.view.handoff.v1` | enabled/selectable | owner create | Valid artifact variant, task/decision/risk references, rollback |
| `cartulary.view.status_review.v1` | enabled/selectable | owner create | Valid artifact variant, task/evidence/decision references, rollback |
| `cartulary.view.lesson.v1` | enabled/selectable | owner create | Valid artifact variant, task/evidence references, rollback |
| `cartulary.view.findings.v1` | reserved/hidden | no enabled binding | Mapping/apply unavailable; absent from frontend selection |
| `cartulary.view.investigative_queries.v1` | reserved/hidden | no enabled binding | Mapping/apply unavailable; absent from frontend selection |
| `cartulary.view.forensic_keywords.v1` | reserved/hidden | no enabled binding | Mapping/apply unavailable; absent from frontend selection |
| `target_kind=network_flow_table; extension_profile_id=network_flow_activity` | claim-gated | owner preview/apply | Unclaimed unavailability; claimed preview/apply; no-data/all-rejected/partial/source-change/cancel/recovery/replay |

Every enabled view-schema target MUST prove correct owner selection, authoritative record and
`row_version`, one unit change set, committed journal, expected projection, and rollback. Failure
injection MAY be parameterized by distinct facade/transaction implementation, but a target with
different defaults or projections requires target-specific assertions.

### 8.2 Route, state, security, and owner-effect coverage

The existing ten operations and the RS-09 operator-region operation in §4.2 require exact success,
malformed request, authorization, visibility, state-conflict, and owner-failure coverage. The
state suite MUST cover every legal and illegal
session/unit transition, idempotent select/skip, skip/reselection, mapping retention, overlap at
selection/apply, concurrent selection, frozen selected set, deterministic order, duplicate apply,
fresh-session intentional re-import, exact committed replay, and all four terminal session
outcomes.

Security coverage MUST include role revocation, membership removal, incident close race, claim
removal, facade loss, cross-incident actor context, cross-session/unit source capability, target
substitution, source and fingerprint change, unauthorized job polling/cancellation, and replay
after a role change with safe visibility.

For each applicable owner family, evidence MUST assert exactly one change set, correct actor/reason/
session/unit/provenance, no effect on rollback, projection visibility after commit, authoritative
row refresh, and owner-required collaboration or outbox effects. Tests MUST NOT invent an
imports-specific WebSocket event.

### 8.3 Registry projection and generator contract

`cartulary.import_target_registry.v1` MUST use these closed fields:

| Field | Rule |
| --- | --- |
| `target_kind` | `view_schema` or `network_flow_table` |
| Selector | Exactly one of `target_view_schema_id` or `extension_profile_id` |
| `owner_contract_ref` | Exact adopted owner and major |
| `facade_kind` | `owner_create` or `owner_preview_apply` |
| `availability_kind` | `enabled`, `reserved`, or `claim_gated` |
| `mapping_contract_schema_id` | Exact governed mapping schema |
| `default_unknown_column_policy` | Exact policy or target-owned marker |
| `entity_bearing_default` | Exact Core value, target-owned marker, or explicit none |
| `facade_id` | Exact internal binding identity |
| Analytical schema IDs | Required only for `owner_preview_apply` |
| `public_projection_disposition` | `selectable`, `hidden_reserved`, or `extension_claim_gated` |

The authored source MUST be explicitly cataloged, schema-validated, canonically ordered, and free of
timestamps, host paths, branches, random values, process IDs, modification times, or unordered-map
output. It MUST NOT be generated by parsing Markdown, scanning directories, inspecting filenames,
reflecting Go packages, probing routes, reading frontend components, or treating tests as authority.

Generation MUST produce:

1. Backend target bindings used by mapping and dispatch.
2. A frontend semantic catalog containing no package, SQL, store, route-internal, or grid-vendor
   details.
3. Typed contract adapters.
4. A verification parameter projection that does not restate product behavior.
5. An integrity manifest proving one reviewed source digest.

Generation MUST fail for duplicate selectors; both/neither selector variants; unknown owner,
facade, or disposition; enabled target without binding; reserved target projected selectable;
analytical target missing a schema ID; unknown view schema; projection digest mismatch; or
nondeterministic output.

The Import Assistant MUST intersect the generated catalog with discovered server target IDs,
present only `selectable`, omit `hidden_reserved`, and gate `extension_claim_gated` against current
extension claims. The server MUST independently revalidate all target and authorization conditions.

### 8.4 Harness families

| Family | Scope |
| --- | --- |
| `imports.http_contract` | Eleven public route contracts and errors after RS-09 |
| `imports.state_machine` | Session and unit transitions |
| `imports.discovery` | CSV/XLSX discovery, ordering, limits, and neutrality |
| `imports.owner_dispatch` | Registry selection and owner facade routing |
| `imports.unit_of_work` | Commit, rollback, replay, and finalization |
| `imports.security_transitions` | Current role, lifecycle, claim, and capability changes |
| `imports.owner_effects` | Revisions, projections, row refresh, and collaboration |
| `imports.boundaries` | Static dependency and ownership guards |
| `imports.frontend_workflow` | Coordinator, assistant, generated target catalog, and selectors |

Behavior-freeze characterization and normative conformance MUST remain distinct. When a correction
lands, a legacy test encoding non-conforming behavior MUST be retired or replaced. No test or tool
may read documentation text, line numbers, headings, hashes, or formatting to establish product
conformance.

### 8.5 Make-owned validation

CP-00 is tracker-only. Later implementation commands are required when their owning workstream is
active and MUST be recorded in the checkpoint.

| Layer | Command | Required phase |
| --- | --- | --- |
| Tracker documentation | `make lint-markdown` | Every checkpoint |
| Fast baseline | `make test-fast`; `make frontend-unit` | GATE-01 |
| Imports owner slice | `make test-slice OWNER=module.imports` | GATE-01 and every backend slice |
| Service-backed owner slice | `make service-backed-test-slice OWNER=module.imports` | GATE-01 and persistence/transaction slices |
| Browser | `make browser-e2e-webserver-backed` | Frontend/public workflow changes |
| Generated drift | `make generate-drift` | GATE-04 and generated changes |
| Generated policy | `make generated-artifact-policy-check` | GATE-04 and generated changes |
| OpenAPI compatibility | `make openapi-compatibility-check` | Authorized public contract change only |
| Backend boundary | `make backend-module-boundary-check` | RS-03 through RS-05 |
| Frontend boundary/type | `make frontend-import-boundary-check`; `make frontend-typecheck` | RS-10 |
| Finalization | `make agent-finalize` | Before broad implementation verification |
| Full check | `make check` | Final risk-appropriate implementation handoff |

## 9. Top-Level Work Tracker

| ID | Work item | Workstream | Status | Depends on | Evidence or artifact | Exit condition |
| --- | --- | --- | --- | --- | --- | --- |
| IMP-001 | Fix target scope, authority, baseline, and write boundary | WF-00 | DONE | None | §1 | Exact scope and non-goals are normative. |
| IMP-002 | Inventory every tracked target file and direct boundary | WF-01 | DONE | IMP-001 | §2 | All 32 tracked files have live target-specific rows. |
| IMP-003 | Resolve analytical ownership and commit semantics in the tracker | WF-02 | DONE | IMP-002 | IRT-REQ-003 through 006; RB-001 | Planning decision is complete without claiming owner adoption. |
| IMP-004 | Resolve conformance behavior decisions in the tracker | WF-02 | DONE | IMP-002 | §4.6/4.7; RB-002 | Every correction has exact behavior, default, and compatibility class. |
| IMP-005 | Define complete characterization and harness posture | WF-03 | DONE | IMP-002 | §8; RB-003 | All 18 targets and cross-cutting invariants have binary evidence obligations. |
| IMP-006 | Define one generated target registry | WF-04 | DONE | IMP-002 | §8.3; RB-004 | Fields, outputs, failures, and frontend rules are decision-complete. |
| IMP-007 | Complete characterization baseline | WF-03 | DONE | IMP-005; GATE-01 | RS-00; `1ba06c97` | Required narrow suites pass with known non-conformance labeled. |
| IMP-008 | Adopt coordinated owner repair | WF-02 | DONE | IMP-003; GATE-02 | RS-01; `f05d3366` | Core/Network Flow/machine owners are coherent and adopted together. |
| IMP-009 | Adopt and generate target registry | WF-04 | DONE | IMP-006, IMP-008; GATE-04 | RS-02 `c6c72504`; RS-08 contract refresh `64cdc912` | All five projections cover 18 ordered rows and share source digest `fdb8081f3b974b14fb89cea1e4d81de1a97b75086110f942e5a61e2bb2f9d99d`. |
| IMP-010 | Inject owner registry and remove ownership leakage | WF-05 | DONE | IMP-007 through IMP-009; GATE-05 | RS-03 `c372c1ba`; RS-04 `7e891c66` | All 14 enabled view targets resolve exactly once with no concrete peer stores, peer-table SQL, or target-specific Timeline path in Imports. |
| IMP-011 | Split imports internal responsibilities | WF-05 | DONE | IMP-010; GATE-05 | RS-05 `7bbbb00d` | Exported declarations, ten routes, errors, transactions, parser behavior, and characterization remain unchanged behind explicit file responsibilities. |
| IMP-012 | Adopt conformance correction authorization | WF-06 | DONE | IMP-004, IMP-007; GATE-03 | §6.1 Imports Conformance Corrections Authorization | Every correction row is adopted before implementation. |
| IMP-013 | Implement transaction/auth correction | WF-06 | DONE | IMP-008, IMP-010 through IMP-012; GATE-06 | RS-06; `75c7c2ec` | IRT-REQ-005 through 008 pass. |
| IMP-014 | Implement state/null/error/discovery corrections | WF-06 | DONE | IMP-011/012; GATE-06 | RS-07 `356281c0`; RS-08 `64cdc912`; RS-09 `fbae9afe` | IRT-REQ-009 through 013 pass. |
| IMP-015 | Replace frontend hardcoded registry | WF-06 | DONE | IMP-009, IMP-012; GATE-06 | RS-10 `b08dfaf1` | IRT-REQ-014/015 pass with selector parity. |
| IMP-016 | Complete harness accounting and final evidence | WF-07 | DONE | Applicable implementation rows; GATE-07 | RS-11 `575f1999`, `32c5e38b` | Every active test is accounted for once; required checks are recorded. |
| IMP-017 | Validate this NLSpec-style tracker revision | WF-00 | DONE | IMP-001 through IMP-006 | `make lint-markdown` | Markdown and structural checks passed with only this file changed. |
| IMP-018 | Activate the tracker as the remediation control artifact | WF-00 | DONE | IMP-017 | CP-00; §1.4 | Current baseline, API posture, authorization, and checkpoint protocol are accurate; only RS-00 is eligible. |

## 10. Session Handoff Log

### Workstream checkpoints

| Time | Slice | Baseline and result | Substantive changes | Validation evidence | Compatibility, migration, rollback, and residual risk | Next eligible slice |
| --- | --- | --- | --- | --- | --- | --- |
| 2026-07-28 18:53 EDT | CP-00 | Baseline `ee848b80cb21cb3fb94aff4dcdef4cf6f73cb672`; checkpoint commit pending | Activated this tracker; recorded the active baseline and narrow run; added the separate checkpoint protocol; assigned the additive operator-region route to RS-09; replaced same-session re-import with fresh-session re-import | `make lint-markdown` passed at `.cartulary/test-results/20260728T225321Z-p1298103`; final diff/status checks run before commit | Documentation-only; no migration or product compatibility effect; rollback is this tracker activation; all implementation risks remain gated | RS-00 only |
| 2026-07-28 19:00 EDT | RS-00 | Baseline `8a1e0fbb`; substantive result `1ba06c97` | Added executable characterization for the current route parser, exact 18-target inventory, raw internal-error echo, hidden-sheet omission, and `use_null` mismatch; retained existing integration, owner-effect, boundary, coordinator, and browser characterization | `make format` passed at `.cartulary/test-results/20260728T225642Z-p1302587`; `make test-fast` passed 891 tests and 2/2 work units at `.cartulary/test-results/20260728T225657Z-p1305602`; `make frontend-unit` passed at `.cartulary/test-results/20260728T225919Z-p1357390`; Imports `test-slice` and `service-backed-test-slice` each passed five tests and 3/3 work units at `.cartulary/test-results/20260728T225919Z-p1357250` and `.cartulary/test-results/20260728T225919Z-p1357264` | Test-only; no migration or product compatibility effect; rollback is the two characterization files; temporary known-nonconformance tests MUST be replaced in RS-08/09, while transaction/auth and state correction probes remain assigned to RS-06/07 | RS-01 only |
| 2026-07-28 19:15 EDT | RS-01 | Baseline `a4c7c679`; substantive result `f05d3366` | Adopted the Core/analytical-target ownership split, generated-registry semantics, typed analytical binding, common unit commit and outcome-only finalizer, transaction-current authorization, safe owner errors, fresh-session re-import, and additive operator-region contract across Domain, Core 00/01/03/04, Extensions `0.7.1`, and Network Flow `2.0.3`; recorded all correction authorizations | `make lint-markdown` passed before and after final owner edits at `.cartulary/test-results/20260728T231255Z-p1403240` and `.cartulary/test-results/20260728T231332Z-p1405532`; `make json-shape-check` passed at `.cartulary/test-results/20260728T231309Z-p1404768`; checkpoint lint passed at `.cartulary/test-results/20260728T231532Z-p1407756`; documentation/shape targets expose no work-unit count | Specification and contract only; existing ten routes remain stable and the eleventh route is additive in RS-09; no production, migration, generated artifact, or stored-data change occurred; coordinated owner files revert together; machine projection remains for RS-02 and behavior corrections remain for RS-06 through RS-10 | RS-02 only |
| 2026-07-28 19:46 EDT | RS-02 | Baseline `4b43ce5c`; substantive result `c6c72504` | Added the Core view-target input catalog and closed schema set, Network Flow owner binding/error schema, Extension binding contribution, deterministic joined generator, exact 18-row backend Go and safe frontend TypeScript catalogs, embedded adapter/verification/integrity projections, generator failure tests, family/policy declarations, and regenerated outputs | `make format` passed at `.cartulary/test-results/20260728T233827Z-p1486846`; `make generate` passed at `.cartulary/test-results/20260728T233913Z-p1492663`; `make test-fast` passed 891 tests and 2/2 work units at `.cartulary/test-results/20260728T233459Z-p1431786`; `make json-shape-check`, `make generated-artifact-policy-check`, and `make generate-drift` passed at `.cartulary/test-results/20260728T233921Z-p1494846`, `.cartulary/test-results/20260728T233931Z-p1495412`, and `.cartulary/test-results/20260728T233938Z-p1495788`; `make frontend-typecheck`, `make frontend-unit`, and `make lint-biome` passed at `.cartulary/test-results/20260728T233952Z-p1499658`, `.cartulary/test-results/20260728T234452Z-p1586588`, and `.cartulary/test-results/20260728T234543Z-p1588641`; Imports `test-slice` and `service-backed-test-slice` each passed five tests and 3/3 work units at `.cartulary/test-results/20260728T234103Z-p1500781` and `.cartulary/test-results/20260728T234153Z-p1519991`; Extensions and Network Flow owner slices passed 26 tests in 4/4 work units and 57 tests in 1/1 work unit at `.cartulary/test-results/20260728T234243Z-p1538839` and `.cartulary/test-results/20260728T234243Z-p1538848`; checkpoint `make lint-markdown` passed at `.cartulary/test-results/20260728T234737Z-p1589948` | Additive internal contracts and generated projections only; no runtime dispatch, public route, database, or stored-data change; rollback removes the authored Imports/Network Flow/Extension inputs and generator, then regenerates all outputs; generated files were changed only by `make generate`, including the topology render index after its checker source digest changed; initial `make generate` failed at `.cartulary/test-results/20260728T233024Z-p1418204` because an internal owner error was incorrectly projected as a public schema, and two `make json-shape-check` runs failed at `.cartulary/test-results/20260728T233718Z-p1485815` and `.cartulary/test-results/20260728T233841Z-p1491912` while the new family policy/order was incomplete; all three related failures were corrected by keeping the owner error internal and closing the family policy; manual backend and frontend consumers intentionally remain until RS-03 and RS-10 | RS-03 only |
| 2026-07-28 20:20 EDT | RS-03 | Baseline `c379b104`; substantive result `c372c1ba` | Added `internal/app/importassembly/owner_registry.go` and its test, updated `internal/app/server/runtime.go`, added the closed registry in `internal/modules/imports/owner_registry.go` and `ownerfacade/registry.go` with its test, changed Imports `owner_apply.go`, `routes.go`, `store.go`, `targets.go`, `boundary_guard_test.go`, and `characterization_test.go`, moved validation/adapter construction through artifacts, assessments, entities/hostidentity, evidence, indicators, parties, and tasksdecisions `import_create.go`, and corrected the RS-02 error capitalization in `tools/contractgen/import_targets.go` | `make format` passed at `.cartulary/test-results/20260729T001535Z-p1883277`; Imports `test-slice` and `service-backed-test-slice` passed five tests and 3/3 work units each at `.cartulary/test-results/20260729T001543Z-p1886173` and `.cartulary/test-results/20260729T001634Z-p1906176`; `make backend-module-boundary-check` passed at `.cartulary/test-results/20260729T001722Z-p1925289`; `make test-fast` passed 891 tests and 2/2 work units at `.cartulary/test-results/20260729T001727Z-p1925689`; artifacts, assessments, entities, evidence, indicators, parties, and tasks/decisions owner slices passed 1/1, 3/3, 10/10, 10/10, 2/2, 2/2, and 2/2 work units respectively at `.cartulary/test-results/20260729T000534Z-p1721571`, `.cartulary/test-results/20260729T000534Z-p1721591`, `.cartulary/test-results/20260729T000534Z-p1721555`, `.cartulary/test-results/20260729T000954Z-p1827740`, `.cartulary/test-results/20260729T000710Z-p1765346`, `.cartulary/test-results/20260729T000710Z-p1765361`, and `.cartulary/test-results/20260729T000917Z-p1810972`; `make generate-drift` and `make generated-artifact-policy-check` passed at `.cartulary/test-results/20260729T001324Z-p1877942` and `.cartulary/test-results/20260729T001336Z-p1881750`; checkpoint `make lint-markdown` passed at `.cartulary/test-results/20260729T002412Z-p1983044` | Internal structural change only: all ten routes, public payloads, database state, and generated outputs are unchanged; rollback reverts all 20 substantive files together; the first Imports slice failed on two related compile defects at `.cartulary/test-results/20260728T235936Z-p1601598` and passed after correction; one Evidence slice failed a browser-upload timing assertion while seven owner slices ran concurrently at `.cartulary/test-results/20260729T000710Z-p1765334`, then passed in isolation, so it is classified as unrelated resource contention; `make lint` failed at `.cartulary/test-results/20260729T001211Z-p1852915` on the corrected RS-02 capitalization plus unrelated Collaboration, Incident portability, Incidents, Extensions, and S3 proxy findings; targeted staticcheck at `.cartulary/test-results/20260729T001309Z-p1877400` confirmed the Imports/registry files clean while the unrelated findings remain; the exact registry contains 13 generic owners and intentionally leaves Timeline to RS-04 | RS-04 only |
| 2026-07-28 20:50 EDT | RS-04 | Baseline `cfb01613`; substantive result `7e891c66` | Added Timeline’s owner-created import facade and provenance/normalization tests; registered all 14 enabled view owners exactly through `internal/app/importassembly`; removed Imports’ direct Timeline dependency and special row loop; extended the narrow owner facade with owner normalization, collection identity, and a contiguous mutation sequencer; refactored Timeline row creation to participate in the caller’s transaction and change set; expanded integration evidence for exact effects, replay, and rollback across 14 substantive files | `make format` passed at `.cartulary/test-results/20260729T004858Z-p2197580`; Imports `test-slice` and `service-backed-test-slice` passed five tests and 3/3 work units each at `.cartulary/test-results/20260729T004035Z-p2043893` and `.cartulary/test-results/20260729T004124Z-p2063322`; Timeline `test-slice` passed 48 tests and 9/9 work units at `.cartulary/test-results/20260729T004213Z-p2082395`; Timeline `service-backed-test-slice` passed 33 tests and 9/9 work units at `.cartulary/test-results/20260729T004703Z-p2173190`; `make backend-module-boundary-check`, `make generate-drift`, `make test-fast`, and `make generated-artifact-policy-check` passed at `.cartulary/test-results/20260729T004344Z-p2107659`, `.cartulary/test-results/20260729T004347Z-p2107933`, `.cartulary/test-results/20260729T004402Z-p2111851` with 891 tests and 2/2 work units, and `.cartulary/test-results/20260729T004654Z-p2172784`; checkpoint `make lint-markdown` passed at `.cartulary/test-results/20260729T005243Z-p2203519` | Internal structural change only: all ten routes, public shapes, database state, generated outputs, and historical sessions are unchanged; rollback reverts all 14 substantive files together; the first staticcheck run at `.cartulary/test-results/20260729T004636Z-p2171229` found five related capitalized Timeline error strings, which were corrected; the rerun at `.cartulary/test-results/20260729T004902Z-p2200663` contains only unrelated pre-existing Collaboration, Incidents, Extensions, and S3 proxy findings and no changed-path finding; durable unit outcomes and outcome-only finalization remain deliberately assigned to RS-06 | RS-05 only |
| 2026-07-28 21:09 EDT | RS-05 | Baseline `161792f8`; substantive result `7bbbb00d` | Replaced `routes.go` with `service.go`, `http_handlers.go`, `jobs.go`, `apply_jobs.go`, `apply_coordination.go`, `discovery.go`, and `mapping.go`; retained `store.go`, `owner_apply.go`, and `xlsx.go` as cohesive persistence, view-owner transaction, and XLSX adapter boundaries; added a source-level responsibility-separation guard across nine substantive files | Final `make format` passed at `.cartulary/test-results/20260729T010405Z-p2233683`; Imports `test-slice` and `service-backed-test-slice` passed five tests and 3/3 work units at `.cartulary/test-results/20260729T010825Z-p2317397` and `.cartulary/test-results/20260729T010418Z-p2236611`; `make backend-module-boundary-check` passed at `.cartulary/test-results/20260729T010508Z-p2256391`; `make test-fast` passed 891 tests and 2/2 work units at `.cartulary/test-results/20260729T010517Z-p2256797`; `make generate-drift` passed at `.cartulary/test-results/20260729T010758Z-p2313483`; checkpoint `make lint-markdown` passed at `.cartulary/test-results/20260729T011103Z-p2337179`; an exact sorted exported-declaration comparison against baseline `161792f8` produced no diff | Internal structural change only: the exported declaration set, ten routes, payloads, errors, transactions, parser outcomes, database state, generated outputs, and historical sessions are unchanged; rollback reverts the nine-file decomposition together; no failed validation occurred; transaction, recovery, state, null/error, XLSX, and frontend behavior remain assigned to RS-06 through RS-10 | RS-06 only |
| 2026-07-28 22:23 EDT | RS-06 | Baseline `3b803b5c`; substantive result `75c7c2ec` | Added migration 00049, immutable apply plans/outcomes, job-first unit serialization, transaction-current actor/role/membership/incident/source/mapping/target checks, caller-owned view and Network Flow owner transactions, outcome-only finalization, crash recovery, truthful partial cancellation, and exact owner/harness evidence; exact paths and failure dispositions are recorded below | Imports `test-slice` and `service-backed-test-slice` each passed 10 tests and 7/7 work units; affected Timeline, Network Flow, Extensions, and Job API owner slices passed 48, 57, 26, and 3 tests; migration, generation, generated-policy, JSON-shape, and boundary checks passed; `make test-fast` passed 896 tests and 2/2 work units; exact run roots are recorded below | The ten public Imports routes and Network Flow resource shape remain compatible; migration 00049 adds durable state and aborts on ambiguous active apply state, does not backfill or reopen terminal sessions, and requires code/schema rollback together; authority lost before commit now fails by design; generated files came only from `make generate`; no residual RS-06 correctness risk is open | RS-07 only |
| 2026-07-28 22:50 EDT | RS-07 | Baseline `b00fcd1c`; substantive result `356281c0` | Added the cohesive selection boundary, server-side overlap rejection at selection and apply, session-first concurrent serialization, skipped-unit reselection with immutable mapping retention, fresh-session re-import evidence, frontend approval/selection state separation, additive lifecycle-state OpenAPI correction, and exact Go/Vitest harness rows; exact paths and failure dispositions are recorded below | Final Imports `test-slice` passed 13 tests and 9/9 work units twice; service-backed Imports passed 12 tests and 9/9 work units; focused lifecycle rows, frontend unit/type, both boundaries, generation/drift/policy, JSON shape, OpenAPI compatibility, and the 898-test fast suite passed; exact run roots are recorded below | No route, request, or database migration changed; overlapping persisted selections now fail with the adopted 409 code/reason, skipped mappings are retained, same-session duplicate apply remains blocked, and intentional duplicate-source import requires a new session; the lifecycle enum expansion is additive and governed by the 2.0 change set; generated files came only from `make generate`; rollback reverts all 17 substantive files together | RS-08 only |
| 2026-07-28 23:31 EDT | RS-08 | Baseline `219139de`; substantive result `64cdc912` | Replaced the unreachable `use_null` branch with canonical `write_null`, added closed typed view-owner and Network Flow owner errors, registered/schema-validated safe analytical translation, fail-closed preview/apply/internal errors, durable ordered error outcomes, migration 00050, corrected Core error projections, and exact Go/harness evidence; exact paths and failure dispositions are recorded below | Imports `test-slice` passed 17 tests and 10/10 work units; service-backed Imports passed 14 tests and 10/10 work units; Network Flow and Timeline owner slices passed 58 and 48 tests; focused null/error rows, migration/generation/policy/shape/boundary/OpenAPI checks, format, and the 905-test fast suite passed; exact run roots are recorded below | Existing routes and valid mappings remain compatible; migration 00050 refuses non-contract `use_null`, backfills safe details for prior failed/canceled outcomes, and adds durable retryability/detail fields; unknown errors now disclose less by design; generated artifacts came only from `make generate`; rollback reverts all 31 substantive files together; unrelated repository-wide lint debt is explicitly retained for RS-11 | RS-09 only |
| 2026-07-29 00:01 EDT | RS-09 | Baseline `92c0e654`; substantive result `fbae9afe` | Replaced visible-sheet materialization with bounded workbook indexing and on-demand rectangle decoding; added used-range, table, static named-range, hidden-presentation, inert-formula, archive/security semantics; added migration 00051 and the durable additive operator-region operation with exact and semantic replay; corrected the runtime locator vocabulary and added exact Go/harness evidence | Imports `test-slice` passed 19 rows and 6/6 work units; service-backed Imports passed 15 rows and 4/4 work units; focused locator/region rows, migration/generation/policy/shape/boundary/OpenAPI, format, and Markdown checks passed; exact run roots are recorded below | Existing ten routes remain compatible; the eleventh route and `operator_region` enum member are additive while released `xlsx_region` remains transport-read compatible but is never emitted; migration 00051 adds private region lineage/sequence and formula-blocking state without rewriting historical units; generated artifacts came only from `make generate`; rollback reverts all 27 substantive files together; frontend region UX and generated target consumption remain exclusively RS-10 | RS-10 only |
| 2026-07-29 00:20 EDT | RS-10 | Baseline `2d8d184f`; substantive result `b08dfaf1` | Added the omitted region operation to the authored TypeScript surface; introduced one fail-closed generated target adapter; replaced the Import Assistant target list, target-specific default, and suggestion IDs with generated selectable semantics; made Network Flow resolve its claim-gated row from owner-generated identity; added typed operator-region coordination and inclusive coordinate UX; added exact frontend/harness evidence | Focused Imports frontend rows passed 4/4; complete Imports passed 22 tests and 11/11 work units; Web Network Flow passed 30/30; Protocol TS passed 5/5; frontend unit/type/boundary, Biome, generation/policy/shape/OpenAPI, and two browser-backed scenarios passed; exact run roots are recorded below | No database or public route changed; the RS-09 additive route is now present in generated TS bindings and the UI; unavailable/reserved/unknown targets fail closed with no fallback; generated outputs came only from `make generate`; rollback reverts all 16 substantive files together; only final exact harness accounting and broad handoff remain | RS-11 only |
| 2026-07-29 01:32 EDT | RS-11 | Baseline `c00f9ce1`; substantive results `575f1999`, `32c5e38b` | Added five exact Imports family rows covering all 16 previously unrouted Go tests; refreshed complete-run duration baselines and regenerated topology; repaired two responsibility-boundary leaks exposed by those tests; added a Jobs-owned per-job transition lock and deterministic cancellation fixture; enabled bounded frontend-port collision recovery; removed the obsolete Imports placeholder | Catalog passes with 60 owners, 204 families, 923 rows, and 1,716 selectors; Imports passes 27/27 and service-backed 17/17; all affected owners, frontend/boundary/drift/schema/migration/OpenAPI/browser/harness gates pass; `make check` passes 181/181 work units and 781 tests; exact run roots and failure dispositions are recorded below | Internal behavior/harness closure only; no public route, shape, database migration, or historical state changed; generated topology came only from `make generate`; rollback reverts the 13 substantive files and regenerates; retained-run maintenance was skipped because no current compatible `RESULTS_DIR` was supplied; no remediation risk is deferred | None; remediation complete |

#### RS-06 checkpoint detail

- **Completed slice and state:** `RS-06`; `IMP-013` is `DONE`; the RS-06 portion of
  `GATE-06` passes. Baseline `3b803b5c`; substantive commit `75c7c2ec`.
- **Exact substantive files:** `db/migrations/00049_import_unit_apply_outcomes.sql`;
  `internal/app/extensionassembly/import_jobs.go`; `internal/app/server/runtime.go`;
  `internal/gen/sql/models.go`; `internal/modules/imports/apply_coordination.go`;
  `internal/modules/imports/apply_jobs.go`; `internal/modules/imports/boundary_guard_test.go`;
  `internal/modules/imports/extension_facade.go`;
  `internal/modules/imports/imports_integration_test.go`;
  `internal/modules/imports/job_finalization.go`; `internal/modules/imports/owner_apply.go`;
  `internal/modules/imports/store.go`; `internal/modules/imports/targets.go`;
  `internal/modules/imports/unit_outcomes.go`; `internal/modules/incidents/access.go`;
  `internal/modules/incidents/models.go`; `internal/modules/networkflow/import_facade.go`;
  `internal/modules/networkflow/module.go`; `internal/platform/authn/store.go`;
  `internal/platform/jobs/collaboration_producer.go`; `internal/platform/jobs/jobs.go`;
  `internal/testutil/httptestx/httptestx.go`; `tools/execution_topology_render_index.json`;
  `tools/migration_history_manifest.json`; `tools/scheduler_manifest.json`;
  `tools/schema_object_ownership_manifest.json`; and
  `tools/test_families/module.imports.json`.
- **Migration and generated-artifact notes:** migration 00049 adds
  `import_apply_unit_plans`, `import_unit_apply_outcomes`, and the durable `canceled` unit state.
  Its preflight refuses existing `applying` session/unit state because such state has no provable
  pre-migration outcome. Existing terminal sessions remain readable historical rows and receive no
  synthetic plans or outcomes. `internal/gen/sql/models.go`, the scheduler manifest, and topology
  index were regenerated only through `make generate`. Rollback must revert the code and migration
  together; the down migration maps `canceled` units to `failed`.
- **Focused validation:** `make format` passed at
  `.cartulary/test-results/20260729T021545Z-p2514402`; the transaction-current race matrix passed at
  `.cartulary/test-results/20260729T015000Z-p2424798`; crash-before-commit and
  crash-after-unit-commit recovery passed at
  `.cartulary/test-results/20260729T020513Z-p2454331`; partial cancellation passed at
  `.cartulary/test-results/20260729T021237Z-p2480556`; and exact Network Flow atomic outcome
  evidence passed at `.cartulary/test-results/20260729T021552Z-p2517313`.
- **Owner and broad validation:** `make test-slice OWNER=module.imports` passed 10 tests and 7/7
  work units at `.cartulary/test-results/20260729T021605Z-p2518982`;
  `make service-backed-test-slice OWNER=module.imports` passed 10 tests and 7/7 work units at
  `.cartulary/test-results/20260729T021656Z-p2538393`; Timeline, Network Flow, Extensions, and Job
  API owner slices passed at `.cartulary/test-results/20260729T021749Z-p2557791`,
  `.cartulary/test-results/20260729T021749Z-p2557829`,
  `.cartulary/test-results/20260729T021749Z-p2557830`, and
  `.cartulary/test-results/20260729T021749Z-p2557798`. `make migration-drift`,
  `make generate-drift`, `make backend-module-boundary-check`,
  `make generated-artifact-policy-check`, and `make json-shape-check` passed at
  `.cartulary/test-results/20260729T021303Z-p2482228`,
  `.cartulary/test-results/20260729T021303Z-p2482221`,
  `.cartulary/test-results/20260729T021303Z-p2482401`,
  `.cartulary/test-results/20260729T022013Z-p2633742`, and
  `.cartulary/test-results/20260729T022100Z-p2655637`. `make test-fast` passed 896 tests and 2/2 work
  units at `.cartulary/test-results/20260729T022013Z-p2634037`; checkpoint
  `make lint-markdown` passed at `.cartulary/test-results/20260729T022500Z-p2697952`.
- **Failure disposition:** related development failures were retained rather than hidden.
  Generation rejected an unknown/unsorted collaborator at
  `.cartulary/test-results/20260729T015530Z-p2435531` and
  `.cartulary/test-results/20260729T015731Z-p2438365`; the recovery test exposed incompatible
  package-scoped S3 fixture reuse at `.cartulary/test-results/20260729T015824Z-p2443286` and then a
  case-specific interrupted-state expectation at
  `.cartulary/test-results/20260729T020420Z-p2449598`; partial-cancellation development runs exposed
  incomplete XLSX mappings, an incorrect one-based sequence trigger, and the production
  incident/job lock-order deadlock at `.cartulary/test-results/20260729T020853Z-p2462037`,
  `.cartulary/test-results/20260729T020945Z-p2466864`, and
  `.cartulary/test-results/20260729T021142Z-p2475972`; Network Flow outcome assertions exposed the
  persisted facade-ID versus binding-ID mismatch at
  `.cartulary/test-results/20260729T021453Z-p2512684`; and JSON shape ownership rejected the new
  schema objects at `.cartulary/test-results/20260729T022013Z-p2633761`. Each failure was related,
  corrected structurally, and covered by the passing evidence above.
- **Compatibility and residual risk:** no route or released response member changed. Unit effects,
  journal/provenance, outcome, and unit status now share one commit; finalization creates no owner
  resource and derives terminal state only from ordered outcomes. Revoked authority, changed source
  or mapping, unavailable target/facade, and cancellation lose before mutation according to
  transaction commit order. Recovery reuses a committed outcome and never replays owner effects.
  No RS-06 risk is deferred. Selection overlap/reselection remains exclusively in `RS-07`;
  null/error translation, XLSX locator completion, frontend generated consumption, and final
  accounting remain in `RS-08` through `RS-11`.
- **Single next eligible workstream:** `RS-07` only.

#### RS-07 checkpoint detail

- **Completed slice and state:** `RS-07`; the RS-07 portion of `IMP-014` is `DONE`, and the RS-07
  portion of `GATE-06` passes. Baseline `b00fcd1c`; substantive commit `356281c0`.
- **Exact substantive files:**
  `apps/web/src/workbook/features/ImportAssistantFeature.tsx`;
  `apps/web/src/workbook/features/ImportAssistantFeature.test.tsx`;
  `contracts/openapi-releases/2.0.0.change-set.json`;
  `contracts/openapi-source/owners/module.imports/openapi.json`;
  `contracts/openapi/cartulary.openapi.yaml`;
  `contracts/verification/owners/module.imports.json`;
  `internal/gen/contractopenapi/artifacts_gen.go`;
  `internal/gen/openapioperations/catalog_gen.go`;
  `internal/modules/imports/boundary_guard_test.go`;
  `internal/modules/imports/imports_integration_test.go`;
  `internal/modules/imports/selection.go`; `internal/modules/imports/store.go`;
  `packages/protocol-ts/src/generated/core-http-types.ts`;
  `packages/protocol-ts/src/generated/protocol-validators.ts`;
  `tools/execution_topology_render_index.json`; `tools/scheduler_manifest.json`; and
  `tools/test_families/module.imports.json`.
- **Selection and lifecycle result:** selection now parses canonical one-based A1 rectangles,
  compares only worksheet units on the same sheet, locks the session before candidate and selected
  units, and rejects a conflicting proposed persisted set with
  `import_apply_blocked/overlapping_units`. Apply admission locks and independently rechecks the
  exact selected unit set before creating a job or durable unit plan. A skipped unit is selectable
  again and derives `ready` from its retained approved mapping and fingerprint without rewriting
  either value. Exact action replay remains immutable.
- **Frontend and re-import result:** the Import Assistant now tracks approval independently from
  selection. Skip and selection-conflict paths retain the approved mapping locally, and reselection
  issues only the select operation. Identical source bytes with different upload transaction IDs
  produce distinct sessions and may both apply; a second apply in one terminal session remains
  `duplicate_apply_blocked`, and an invented `reimport` request member fails the closed decoder.
- **Contract and generated-artifact notes:** the authored Imports OpenAPI now includes `selected`,
  `rejected`, and `canceled` in the unit lifecycle enum because adopted behavior and runtime
  resources already use those states. The expansion is additive and is recorded by fingerprint in
  the governed 2.0 release change set. The assembled OpenAPI, generated Go catalogs, generated
  TypeScript types/validators, scheduler manifest, and topology index were produced only by
  `make generate`; no generated root was hand-edited.
- **Focused validation:** the Vitest reselection row passed 1 test and 1/1 work units at
  `.cartulary/test-results/20260729T023553Z-p2716192`; the concurrent overlap/reselection and
  fresh-session re-import rows passed 2 tests and 2/2 work units at
  `.cartulary/test-results/20260729T023601Z-p2716589`; and the existing partial-cancellation row
  passed in isolation at `.cartulary/test-results/20260729T024154Z-p2828651`.
- **Owner and broad validation:** final `make test-slice OWNER=module.imports` runs passed 13 tests
  and 9/9 work units at `.cartulary/test-results/20260729T024906Z-p2921157` and
  `.cartulary/test-results/20260729T025003Z-p2940639`;
  `make service-backed-test-slice OWNER=module.imports` passed 12 tests and 9/9 work units at
  `.cartulary/test-results/20260729T023713Z-p2739134`; `make frontend-unit` passed at
  `.cartulary/test-results/20260729T024619Z-p2887324`; and `make frontend-typecheck` passed with no
  retained wrapper run root. `make backend-module-boundary-check` and
  `make frontend-import-boundary-check` passed at
  `.cartulary/test-results/20260729T024652Z-p2894163` and
  `.cartulary/test-results/20260729T024652Z-p2894206`. Final `make generate`,
  `make generate-drift`, `make openapi-compatibility-check`,
  `make generated-artifact-policy-check`, and `make json-shape-check` passed at
  `.cartulary/test-results/20260729T024559Z-p2884650`,
  `.cartulary/test-results/20260729T024619Z-p2887141`,
  `.cartulary/test-results/20260729T024619Z-p2887158`,
  `.cartulary/test-results/20260729T024652Z-p2893907`, and
  `.cartulary/test-results/20260729T024652Z-p2893935`. Final `make format` passed at
  `.cartulary/test-results/20260729T024902Z-p2918238`; `make test-fast` passed 898 tests and 2/2
  work units at `.cartulary/test-results/20260729T024208Z-p2830086`; the tracker checkpoint
  `make lint-markdown` passed at `.cartulary/test-results/20260729T025421Z-p2960960`.
- **Failure disposition:** the first catalog-aware format invocation rejected Vitest evidence
  because the Imports verification contract admitted only Go and Playwright; adding the missing
  evidence kind corrected that related routing defect. `make test-fast` at
  `.cartulary/test-results/20260729T023903Z-p2766680` exposed an RS-06 cancellation assertion that
  observed apply admission instead of asynchronous finalization; the fixture now waits for the
  durable terminal condition and retains exact session/job/unit/outcome diagnostics.
  `make generate` at `.cartulary/test-results/20260729T024506Z-p2882218` and its direct
  `generate-artifacts` diagnosis at `.cartulary/test-results/20260729T024517Z-p2883400` correctly
  rejected an unaccounted OpenAPI enum delta; the governed release change set now accounts for all
  110 changes. One later complete owner slice at
  `.cartulary/test-results/20260729T024704Z-p2895645` hit the same asynchronous cancellation
  assertion under load; the focused row, broad fast suite, and two subsequent complete owner
  slices passed. This is classified as transient fixture timing outside the RS-07 selection path;
  the retained diagnostics and RS-11 broad rerun guard against recurrence.
- **Compatibility, migration, rollback, and residual risk:** no migration is required. The existing
  ten routes and request members remain unchanged. Overlap rejection and fresh-session-only
  re-import are intentional adopted behavior corrections; clients that attempted an overlapping
  persisted selection now receive the stable 409 error rather than reaching partial apply.
  Lifecycle enum expansion is additive and documents runtime states rather than introducing a new
  state. Rollback must revert the 17 substantive files together and regenerate from the reverted
  authored contracts/catalog inputs. No RS-07 functional risk is deferred; canonical null/error
  work remains exclusively in RS-08, XLSX locators in RS-09, frontend registry consumption in
  RS-10, and final accounting in RS-11.
- **Single next eligible workstream:** `RS-08` only.

#### RS-08 checkpoint detail

- **Completed slice and state:** `RS-08`; the RS-08 portion of `IMP-014` is `DONE`, the
  `imports.write_null.v1` and `imports.owner_error_translation.v1` correction rows are
  `verified`, and the RS-08 portion of `GATE-06` passes. Baseline `219139de`; substantive commit
  `64cdc912`.
- **Exact substantive files:** `contracts/errors/index.json`;
  `contracts/imports/schemas.v1.json`;
  `db/migrations/00050_import_owner_error_outcomes.sql`;
  `internal/gen/contracterrors/artifacts_gen.go`;
  `internal/gen/contractimports/artifacts_gen.go`;
  `internal/gen/importtargetregistry/registry_gen.go`; `internal/gen/sql/models.go`;
  `internal/modules/imports/api.go`; `internal/modules/imports/apply_jobs.go`;
  `internal/modules/imports/characterization_test.go`;
  `internal/modules/imports/extension_facade.go`;
  `internal/modules/imports/http_handlers.go`;
  `internal/modules/imports/imports_integration_test.go`;
  `internal/modules/imports/mapping.go`; `internal/modules/imports/owner_apply.go`;
  `internal/modules/imports/owner_errors.go`;
  `internal/modules/imports/owner_errors_test.go`;
  `internal/modules/imports/ownerfacade/characterization_test.go`;
  `internal/modules/imports/ownerfacade/owner_create.go`;
  `internal/modules/imports/targets.go`; `internal/modules/imports/unit_outcomes.go`;
  `internal/modules/networkflow/import_facade.go`;
  `internal/modules/networkflow/import_owner_errors.go`;
  `internal/modules/networkflow/network_flow_contract_test.go`;
  `packages/protocol-ts/src/generated/errors-artifacts.ts`;
  `packages/protocol-ts/src/generated/import-target-registry.ts`;
  `tools/execution_topology_render_index.json`; `tools/migration_history_manifest.json`;
  `tools/scheduler_manifest.json`; `tools/test_families/module.imports.json`; and
  `tools/test_families/module.networkflow.json`.
- **Null and owner-error result:** decoding, approved mapping, fingerprinting, persistence,
  preview, and owner scalar normalization now use only `write_null`; `omit_field` continues to
  trigger owner defaults, and explicit null requires a clearable create field. View-owner failures
  use the exact closed `OwnerCreateError` projection. Network Flow owns its exact six-member error
  union and translator; Imports checks the generated error-schema and translation IDs, validates
  safe detail through the target facade, and collapses unknown, invalid, or mismatched errors to
  `import_apply_blocked/owner_apply_validation_failed` without returning a raw cause.
- **Durable outcome and contract result:** failed/canceled unit outcomes now persist retryability
  and closed safe detail atomically, include those facts in the immutable outcome digest, and
  supply the first ordered failure to outcome-only job finalization. Core error inputs now contain
  the adopted analytical preview/apply and source-change reasons, and the runtime mapping-variant
  reason is corrected to the adopted `invalid_target_variant` token. Regeneration refreshed the
  five target projections to source digest
  `fdb8081f3b974b14fb89cea1e4d81de1a97b75086110f942e5a61e2bb2f9d99d` and registry digest
  `93b0817967ebe7698c208165332b2f8e09cb51b8d80afffb65a805b9d6405362`.
- **Focused and owner validation:** the four new Imports null/error rows passed four tests and 1/1
  work units at `.cartulary/test-results/20260729T031616Z-p3025714`; the Network Flow translator
  row passed one test and 1/1 work units at
  `.cartulary/test-results/20260729T031638Z-p3028907`. Complete
  `make test-slice OWNER=module.imports` passed 17 tests and 10/10 work units at
  `.cartulary/test-results/20260729T031647Z-p3029778`;
  `make service-backed-test-slice OWNER=module.imports` passed 14 tests and 10/10 work units at
  `.cartulary/test-results/20260729T031745Z-p3051078`; complete Network Flow and Timeline owner
  slices passed 58 tests in 1/1 work units and 48 tests in 9/9 work units at
  `.cartulary/test-results/20260729T031834Z-p3070083` and
  `.cartulary/test-results/20260729T032041Z-p3099843`.
- **Contract and broad validation:** final `make generate`, `make migration-drift`, and
  `make generate-drift` passed at `.cartulary/test-results/20260729T031604Z-p3023461`,
  `.cartulary/test-results/20260729T032239Z-p3127398`, and
  `.cartulary/test-results/20260729T032252Z-p3129775`.
  `make generated-artifact-policy-check`, `make json-shape-check`, and
  `make backend-module-boundary-check` passed at
  `.cartulary/test-results/20260729T032312Z-p3133691`,
  `.cartulary/test-results/20260729T032312Z-p3133705`, and
  `.cartulary/test-results/20260729T032312Z-p3133894`. Final `make format` passed at
  `.cartulary/test-results/20260729T032359Z-p3135359`;
  `make openapi-compatibility-check` passed at
  `.cartulary/test-results/20260729T032914Z-p3232922`; and `make test-fast` passed 905 tests and
  2/2 work units at `.cartulary/test-results/20260729T032612Z-p3150096`. Checkpoint
  `make lint-markdown` passed at `.cartulary/test-results/20260729T033530Z-p3256625`.
- **Failure disposition:** related development runs remain recorded. `make test-slice` first found
  an unused import at `.cartulary/test-results/20260729T030510Z-p2972010` and then the intentionally
  changed Timeline safe fallback token at `.cartulary/test-results/20260729T030551Z-p2990303`;
  the focused corrected Timeline row passed at
  `.cartulary/test-results/20260729T030728Z-p3011144`. `make generate` rejected unsorted authored
  row IDs and selector tests at `.cartulary/test-results/20260729T031307Z-p3015075` and
  `.cartulary/test-results/20260729T031340Z-p3017715`; both authored inputs were corrected before
  successful regeneration. The first `make migration-drift` at
  `.cartulary/test-results/20260729T032216Z-p3125419` correctly rejected the missing migration
  history entry; the immutable migration checksum was then added. The first broad fast run at
  `.cartulary/test-results/20260729T032408Z-p3138407` exhausted `/tmp` while Go wrote build
  metadata. This was unrelated infrastructure exhaustion: the 14 GB Go build cache and orphaned
  `go-build*` directories were cleared, `/tmp` fell from 100% to 9% use, the cold-cache rerun
  passed, and the post-run filesystem was healthy at 17% use with no orphaned build directories.
  `make lint` at `.cartulary/test-results/20260729T032939Z-p3233662` retains unrelated pre-existing
  Biome non-null-assertion warnings and Go vet/staticcheck findings in Collaboration, incident
  portability, Incidents, dormant Network Flow transaction-participant placeholders,
  contract generation, and the S3 CORS proxy. No finding names an RS-08 changed Go/TypeScript
  implementation file; repository-wide lint debt is an explicit RS-11 closure item.
- **Compatibility, migration, rollback, and residual risk:** the existing ten routes and valid
  request/resource shapes remain compatible. The stricter unknown-error fallback is an intentional
  security correction. No `use_null` decoder or value migration exists because the public closed
  mapping contract never admitted that token. Migration 00050 nevertheless fails before schema
  change if manually inserted retained mappings contain `use_null`, adds non-null durable
  error-retryability/detail columns, and backfills only prior failed/canceled outcome details with
  their existing reason code. Applied outcomes and terminal sessions are not reopened or
  synthesized. Migration, runtime, contracts, and generated projections must roll back together;
  every generated file above came from `make generate`, not a hand edit. No RS-08 correctness risk
  is deferred. XLSX locator/API work remains exclusively in RS-09, frontend consumption in RS-10,
  and the retained unrelated lint/accounting closure in RS-11.
- **Single next eligible workstream:** `RS-09` only.

#### RS-09 checkpoint detail

- **Completed slice and state:** `RS-09`; `IMP-014` is `DONE`,
  `imports.xlsx_locators.v1` is `verified`, and the RS-09 portion of `GATE-06` passes.
  Baseline `92c0e654`; substantive commit `fbae9afe`.
- **Exact substantive files:** `contracts/openapi-releases/2.0.0.change-set.json`;
  `contracts/openapi-source/owners/module.imports/openapi.json`;
  `contracts/openapi/cartulary.openapi.yaml`;
  `db/migrations/00051_import_operator_regions.sql`;
  `docs/spec/01_architecture_storage_and_view_contracts.md`;
  `docs/spec/03_workbook_interaction_collaboration_and_workflows.md`;
  `internal/gen/contractopenapi/artifacts_gen.go`;
  `internal/gen/openapioperations/catalog_gen.go`; `internal/gen/sql/models.go`;
  `internal/modules/imports/api.go`; `internal/modules/imports/boundary_guard_test.go`;
  `internal/modules/imports/characterization_test.go`;
  `internal/modules/imports/discovery.go`; `internal/modules/imports/http_handlers.go`;
  `internal/modules/imports/imports_integration_test.go`;
  `internal/modules/imports/regions.go`; `internal/modules/imports/selection.go`;
  `internal/modules/imports/service.go`; `internal/modules/imports/store.go`;
  `internal/modules/imports/xlsx.go`; `internal/modules/imports/xlsx_test.go`;
  `packages/protocol-ts/src/generated/core-http-types.ts`;
  `packages/protocol-ts/src/generated/protocol-validators.ts`;
  `tools/execution_topology_render_index.json`; `tools/migration_history_manifest.json`;
  `tools/scheduler_manifest.json`; and `tools/test_families/module.imports.json`.
- **Workbook and locator result:** XLSX ingest now indexes bounded archive members, workbook order,
  worksheet semantic cells, relationships, tables, static names, presentation metadata, merged
  ranges, and safe warnings before decoding only a requested rectangle. Hidden and filtered rows,
  columns, and sheets remain semantically visible; style-only cells do not expand the used range.
  Cached formula results are inert `formula_cached` cells, and missing caches remain blank with an
  affected-column readiness blocker until that column is excluded. Dynamic, external, multi-area,
  malformed, path-escaping, and over-limit inputs fail through the closed source error registries;
  macros, formulas, and external relationships are never executed or fetched.
- **Operator-region result:** the additive
  `POST /api/v1/import-sessions/{import_session_id}/units/{base_unit_id}/regions` operation accepts
  only a client transaction and positive inclusive source rectangle. It requires containment by
  the addressed worksheet used-range unit, revalidates current incident mutation authority and
  source digest under session/base locks, creates no mapping/selection/job/owner resource, copies
  one private source capability, and persists monotonic session-local lineage. Exact transaction
  replay and same-base/same-rectangle semantic replay return the original unit; divergent
  transaction replay fails closed.
- **Migration and compatibility:** migration 00051 adds private
  `base_import_unit_id`, `operator_region_sequence`, and
  `blocking_source_column_ordinals` state plus lineage and semantic-identity uniqueness. It does
  not rewrite or reopen historical units and rolls back only with the region/index runtime.
  Existing ten operations and response members remain unchanged. `operator_region` is an additive
  OpenAPI enum value and the eleventh route is an additive path recorded in the governed 2.0
  change set. The released `xlsx_region` enum spelling remains in OpenAPI for read compatibility,
  but adopted owners and runtime state forbid emitting or persisting it.
- **Focused and owner validation:** bounded used-range discovery passed at
  `.cartulary/test-results/20260729T035048Z-p3281208`; the locator/security/formula and durable
  region rows passed two routed rows and 2/2 work units at
  `.cartulary/test-results/20260729T035356Z-p3293173`. Final
  `make test-slice OWNER=module.imports` passed 19 rows and 6/6 work units at
  `.cartulary/test-results/20260729T035856Z-p3335665`;
  `make service-backed-test-slice OWNER=module.imports` passed 15 rows and 4/4 work units at
  `.cartulary/test-results/20260729T035953Z-p3355751`.
- **Contract and broad validation:** final `make format` and `make generate` passed at
  `.cartulary/test-results/20260729T035453Z-p3295499` and
  `.cartulary/test-results/20260729T035457Z-p3298369`.
  `make migration-drift`, `make openapi-compatibility-check`, `make generate-drift`,
  `make generated-artifact-policy-check`, `make json-shape-check`,
  `make backend-module-boundary-check`, and pre-checkpoint `make lint-markdown` passed at
  `.cartulary/test-results/20260729T040048Z-p3375441`,
  `.cartulary/test-results/20260729T040048Z-p3375342`,
  `.cartulary/test-results/20260729T040048Z-p3375218`,
  `.cartulary/test-results/20260729T040048Z-p3375260`,
  `.cartulary/test-results/20260729T040048Z-p3375463`,
  `.cartulary/test-results/20260729T040048Z-p3375799`, and
  `.cartulary/test-results/20260729T040048Z-p3375819`. The completed tracker checkpoint passed
  `make lint-markdown` at `.cartulary/test-results/20260729T040309Z-p3385403`.
- **Failure disposition:** related development failures remain recorded. The first focused slice
  at `.cartulary/test-results/20260729T034913Z-p3270385` found the removed parser symbol in the
  characterization/boundary tests and a missing standard-library test import. The first generated
  run at `.cartulary/test-results/20260729T035002Z-p3277343` correctly rejected the four
  unaccounted additive OpenAPI changes; the governed release change set was extended before the
  successful run. The first migration drift at
  `.cartulary/test-results/20260729T035105Z-p3284224` correctly rejected the absent immutable
  migration-history entry. The first complete Imports run at
  `.cartulary/test-results/20260729T035504Z-p3300593` exposed nil CSV warning/blocking slices
  being encoded as SQL `NULL` after the new non-null column; normalization to canonical empty
  arrays corrected the shared discovery boundary, and the focused CSV rerun and complete owner
  reruns passed. All failures were related and structurally corrected.
- **Rollback and residual risk:** rollback reverts all 27 substantive files together and runs the
  generators after reverting authored OpenAPI/harness inputs; migration 00051 and runtime code
  must move together. No RS-09 backend correctness or compatibility risk is deferred. The generic
  Import Assistant still lacks durable operator-region UX and generated target-catalog
  consumption; those frontend-only obligations remain exclusively `RS-10`. Final exact harness
  accounting and repository-wide closure remain exclusively `RS-11`.
- **Single next eligible workstream:** `RS-10` only.

#### RS-10 checkpoint detail

- **Completed slice and state:** `RS-10`; `IMP-015` is `DONE`, `GATE-06` passes, and
  `imports.frontend_projection.v1` is `verified`. Baseline `2d8d184f`; substantive commit
  `b08dfaf1`.
- **Exact substantive files:** `apps/web/src/imports/importCoordinator.test.ts`;
  `apps/web/src/imports/importCoordinator.ts`;
  `apps/web/src/networkFlow/useNetworkFlowImportController.ts`;
  `apps/web/src/services/importContractAdapter.ts`;
  `apps/web/src/services/importTargetContractAdapter.test.ts`;
  `apps/web/src/services/importTargetContractAdapter.ts`;
  `apps/web/src/services/networkFlowContractAdapter.ts`;
  `apps/web/src/workbook/features/ImportAssistantFeature.test.tsx`;
  `apps/web/src/workbook/features/ImportAssistantFeature.tsx`;
  `contracts/protocol-ts/http-operations.v1.json`;
  `packages/protocol-ts/src/generated/core-http-types.ts`;
  `packages/protocol-ts/src/generated/http-operation-bindings.ts`;
  `packages/protocol-ts/src/generated/protocol-validators.ts`;
  `packages/protocol-ts/src/index.test.ts`; `tools/execution_topology_render_index.json`; and
  `tools/test_families/module.imports.json`.
- **Generated target result:** the generic Import Assistant now joins only generated
  `selectable`/`enabled`/`always` view-target rows to exactly one view contract and fails module
  initialization on a missing or duplicate contract. Target suggestions score generated contract
  fields instead of carrying target IDs, and mapping approval uses each generated row's
  unknown-column policy. Reserved and analytical rows never enter the generic selector. The
  Network Flow controller resolves its claim-gated analytical row through the target owner's
  generated kind/profile identity, retains owner-specific mapping UX and schemas, and has no
  fallback binding.
- **Operator-region result:** `createImportUnitRegion` is now an authored Protocol TS operation and
  a generated typed binding. The shared coordinator creates a durable region, fetches its preview,
  and remains guarded by Import-profile availability. Each XLSX used-range card exposes bounded
  one-based inclusive coordinates; exact or semantic replay replaces the existing region in place,
  while a new region receives an independent mapping/selection draft. Availability loss discards a
  stale completion.
- **Focused and owner validation:** the final focused catalog, coordinator, assistant, and
  reselection run passed four tests and 4/4 work units at
  `.cartulary/test-results/20260729T041935Z-p3467035`.
  `make test-slice OWNER=module.imports` passed 22 tests and 11/11 work units at
  `.cartulary/test-results/20260729T041453Z-p3410632`;
  `make test-slice OWNER=web.networkflow` passed 30 tests and 30/30 work units after final review at
  `.cartulary/test-results/20260729T041956Z-p3468756`; and
  `make test-slice OWNER=package.protocol_ts` passed five tests and 5/5 work units at
  `.cartulary/test-results/20260729T041550Z-p3431760`.
- **Frontend and browser validation:** final `make frontend-unit` passed at
  `.cartulary/test-results/20260729T041956Z-p3468832`;
  `make frontend-typecheck`, `make lint-biome`, and
  `make frontend-import-boundary-check` passed at
  `.cartulary/test-results/20260729T041935Z-p3467164`,
  `.cartulary/test-results/20260729T041935Z-p3467181`, and
  `.cartulary/test-results/20260729T041735Z-p3458344`. The claimed production workflow and
  unclaimed-absence browser scenarios passed two tests in one work unit at
  `.cartulary/test-results/20260729T041645Z-p3439039`.
- **Contract and generation validation:** final `make generate` passed at
  `.cartulary/test-results/20260729T041150Z-p3397938`.
  `make generate-drift`, `make generated-artifact-policy-check`, `make json-shape-check`, and
  `make openapi-compatibility-check` passed at
  `.cartulary/test-results/20260729T041621Z-p3433880`,
  `.cartulary/test-results/20260729T041621Z-p3433858`,
  `.cartulary/test-results/20260729T041621Z-p3433844`, and
  `.cartulary/test-results/20260729T041621Z-p3433866`. The completed tracker checkpoint passed
  `make lint-markdown` at `.cartulary/test-results/20260729T042256Z-p3473348`.
- **Failure disposition:** the first focused run at
  `.cartulary/test-results/20260729T041202Z-p3400220` found that the new assistant test counted
  field-mapping options in addition to target options; it was corrected to inspect the target
  control. The first complete frontend run at
  `.cartulary/test-results/20260729T041235Z-p3401740` found a selector-policy violation in the new
  test's named-heading readiness assertion; the assertion now waits on semantic status and checks
  the rendered heading without using a readiness selector. The first Biome run at
  `.cartulary/test-results/20260729T041735Z-p3458351` found four non-null assertions in the changed
  fixture file, including two pre-existing assertions; all four were replaced with explicit
  fixture guards. All three failures were related and corrected before the final passes.
- **Compatibility, rollback, and residual risk:** no migration, server route, or released shape
  changed in this slice. Adding the already-public RS-09 operation to the authored TypeScript
  projection is additive. The current 14 enabled view targets remain selectable, three reserved
  targets remain hidden, and Network Flow remains extension-claim gated. There is no manual target
  registry, guessed fallback, or generic analytical mapping UX. Rollback reverts all 16 substantive
  files together and regenerates Protocol TS and topology outputs from the reverted authored
  inputs. No RS-10 product risk is deferred; final exact test accounting, retained-run
  finalization, repository-wide validation, and handoff completion remain exclusively `RS-11`.
- **Single next eligible workstream:** `RS-11` only.

#### RS-11 checkpoint detail

- **Completed slice and state:** `RS-11`; `IMP-016` is `DONE`, `GATE-07` passes,
  `IRT-REQ-016` and `IRT-AC-013/015` pass, and the remediation sequence is complete. Baseline
  `c00f9ce1`; substantive commits `575f1999`, `32c5e38b`, and retained-run evidence commit
  `86ab9438`.
- **Exact substantive files:** deleted `internal/modules/imports/.gitkeep`;
  `internal/modules/imports/http_handlers.go`;
  `internal/modules/imports/imports_integration_test.go`;
  `internal/modules/imports/mapping.go`; `internal/modules/imports/service.go`;
  `internal/modules/imports/unit_outcomes.go`; `internal/platform/jobs/jobs.go`;
  `tools/browser_e2e_duration_baselines.json`; `tools/execution_topology_render_index.json`;
  `tools/go_test_duration_baselines.json`; `tools/harness_smoke_duration_baselines.json`;
  `tools/harness/browser/start-web-e2e.sh`;
  `tools/harness/tests/test-harness-contracts.mjs`; `tools/scheduler_manifest.json`;
  `tools/service_backed_make_target_duration_baselines.json`; and
  `tools/test_families/module.imports.json`.
- **Exact accounting result:** five authored Imports rows now account for all 16 formerly unrouted
  tests: twelve tests in `internal/modules/imports` and four in
  `internal/modules/imports/ownerfacade`. An exact source-to-catalog audit found no remaining
  Imports or ownerfacade test without one row. `make test-catalog-check` passes with 60 owners,
  204 families, 923 rows, 1,716 selectors, Go/Playwright/shell/Vitest counts of
  449/146/6/322, catalog digest
  `sha256:48ee5980eb7a05274c1bb1028d03d3e53c2070de352cd3804550900ad8a9784f`,
  and verification-routing digest
  `sha256:2724d2e6dd0ca97448ceeee5f799b7af8f036b15d087c8ace77f4be2e5d08d94`
  at `.cartulary/test-results/20260729T053213Z-p214205`.
- **Closure repairs exposed by exact routing:** the newly routed responsibility test found route
  binding in `service.go` and mapping orchestration in `http_handlers.go`; binding now lives with
  the HTTP adapter and approve/save orchestration with the mapping service. Full concurrency then
  exposed that row-lock scheduling alone could let a later unit overtake a waiting cancellation.
  Jobs now owns one transaction-scoped per-job transition lock used by cancel, terminalization,
  and Imports unit-current-state checks. The cancellation fixture observes that exact lock chain
  rather than unrelated global waiters. Repeated strict-port collisions also exposed a dormant
  browser-harness retry path; Vite strict-port conflicts are now typed `resource_conflict` and
  receive at most two alternate-port retries under the existing lease and CORS-range policy.
- **Harness and complete service validation:** `make harness-contract` passes at
  `.cartulary/test-results/20260729T050703Z-p4092318`; the final
  `make go-test-duration-baseline-coverage` passes at
  `.cartulary/test-results/20260729T050657Z-p4092045`. The authored duration baseline was refreshed
  only from the complete successful 507-test, 11/11-work-unit `make test-service-backed` run at
  `.cartulary/test-results/20260729T050249Z-p4014948`, with the refresh passing at
  `.cartulary/test-results/20260729T050651Z-p4091794`. Final `make generate` passes at
  `.cartulary/test-results/20260729T050748Z-p4093621`.
- **Owner validation:** `make test-slice OWNER=module.imports` passes 27 tests and 13/13 work units
  at `.cartulary/test-results/20260729T050808Z-p4096149`; the service-backed Imports slice passes
  17 tests and 13/13 work units at `.cartulary/test-results/20260729T050900Z-p4115806`.
  Timeline, Network Flow, Extensions, and Web Network Flow pass 48, 58, 26, and 30 tests at
  `.cartulary/test-results/20260729T050953Z-p4134863`,
  `.cartulary/test-results/20260729T051125Z-p4160638`,
  `.cartulary/test-results/20260729T051330Z-p4190173`, and
  `.cartulary/test-results/20260729T051436Z-p16046`.
- **Frontend, boundary, and contract validation:** `make frontend-unit`,
  `make frontend-typecheck`, `make frontend-import-boundary-check`, and
  `make backend-module-boundary-check` pass at
  `.cartulary/test-results/20260729T051504Z-p17809`,
  `.cartulary/test-results/20260729T051531Z-p19721`,
  `.cartulary/test-results/20260729T051545Z-p20359`, and
  `.cartulary/test-results/20260729T051554Z-p20944`. `make generate-drift`,
  `make generated-artifact-policy-check`, `make json-shape-check`, `make migration-drift`, and
  `make openapi-compatibility-check` pass at
  `.cartulary/test-results/20260729T051602Z-p21258`,
  `.cartulary/test-results/20260729T051616Z-p25082`,
  `.cartulary/test-results/20260729T051624Z-p25468`,
  `.cartulary/test-results/20260729T051633Z-p26031`, and
  `.cartulary/test-results/20260729T051644Z-p28417`. `make lint-shell` passes at
  `.cartulary/test-results/20260729T050232Z-p4013801`.
- **Browser and final validation:** the required `make browser-e2e-webserver-backed` rerun passes
  both sessions at `.cartulary/test-results/20260729T052257Z-p74315`.
  `make agent-finalize` passes at `.cartulary/test-results/20260729T052827Z-p104789` and records
  generated output unchanged, with retained-run duration maintenance skipped because
  `RESULTS_DIR` was unset. The first committed-tree `make check` passes 181/181 work units and 781
  tests with zero failed or missing tests at
  `.cartulary/test-results/20260729T054039Z-p222021`; a genuinely warm retained source run passes
  the same 181/181 units and 781 tests at
  `.cartulary/test-results/20260729T054444Z-p322168`. Retained-run
  `make agent-finalize RESULTS_DIR=.cartulary/test-results/20260729T054444Z-p322168` passes at
  `.cartulary/test-results/20260729T054739Z-p421202`, refreshes all six governed duration/topology
  artifacts, and passes its internal checks. `make generate-drift`,
  `make generated-artifact-policy-check`, `make go-test-duration-baseline-coverage`, and
  `make harness-contract` then pass at
  `.cartulary/test-results/20260729T054838Z-p428366`,
  `.cartulary/test-results/20260729T054838Z-p428383`,
  `.cartulary/test-results/20260729T054838Z-p428491`, and
  `.cartulary/test-results/20260729T054838Z-p428644`. The final post-refresh `make check` passes
  177/177 rebalanced work units and the unchanged 781-test surface with zero failed or missing
  tests at `.cartulary/test-results/20260729T054952Z-p434347`. The supplemental tracker checkpoint
  passes `make lint-markdown` at `.cartulary/test-results/20260729T055315Z-p532834`.
- **Related failure disposition:** initial harness/coverage runs at
  `.cartulary/test-results/20260729T042356Z-p3477278` and
  `.cartulary/test-results/20260729T042437Z-p3478796` correctly found stale golden counts and ten
  missing integration baselines. Partial owner evidence at
  `.cartulary/test-results/20260729T042537Z-p3479907` was correctly rejected for baseline refresh
  at `.cartulary/test-results/20260729T042630Z-p3500474` and
  `.cartulary/test-results/20260729T042643Z-p3500753`. The parallel owner/harness runs at
  `.cartulary/test-results/20260729T043445Z-p3609942` and
  `.cartulary/test-results/20260729T043445Z-p3610055` exposed the unrouted responsibility failure
  and the still-missing new baselines. Broad service runs at
  `.cartulary/test-results/20260729T043907Z-p3655676`,
  `.cartulary/test-results/20260729T044552Z-p3747431`, and
  `.cartulary/test-results/20260729T045143Z-p3831768` exposed the cancellation ordering race;
  focused intermediate probes at `.cartulary/test-results/20260729T044417Z-p3742814` and
  `.cartulary/test-results/20260729T044500Z-p3744390` refined the transaction-scoped fixture.
  The later broad run at `.cartulary/test-results/20260729T045708Z-p3936569` passed all 507 tests
  but found the Vite port-allocation race. All related defects were structurally corrected before
  the final passes.
- **Unrelated/transient failure disposition:** the first complete browser acceptance run at
  `.cartulary/test-results/20260729T051652Z-p29005` had one Collaboration inline-edit timing
  failure after every Imports and Network Flow browser row passed. Its exact owner row passed at
  `.cartulary/test-results/20260729T052215Z-p57475`, and the required complete browser rerun passed
  at `.cartulary/test-results/20260729T052257Z-p74315`. The first retained-run finalization attempt
  at `.cartulary/test-results/20260729T052816Z-p104395` rejected the older successful check root
  because its source snapshot was incompatible; no older-results override was used. A first
  exact-source retained finalization at `.cartulary/test-results/20260729T054403Z-p321437` made no
  source changes and rejected a cold timing sample: two build units exceeded their 15-second warm
  thresholds and the service-backed phase exceeded its 155-second budget. The immediate warm
  run and retained finalization passed at the roots recorded above, so no budget suppression or
  manual baseline edit was used.
- **Compatibility, migration, rollback, and generated artifacts:** RS-11 adds no route, public
  member, database migration, stored-data rewrite, or historical-session change. The transition
  lock makes already-authorized cancellation ordering deterministic and the browser retry remains
  bounded and fail-closed. Generated topology files were changed only by repository-owned
  generation/finalization; duration baselines were refreshed only from the complete successful
  retained run. Rollback reverts the substantive files and retained-run evidence commit together,
  then regenerates topology from the reverted family and baseline inputs. One hundred inactive
  top-level Go/Cartulary scratch directories, approximately 179 MB, were removed from `/tmp`;
  shared caches and system-managed paths were preserved. No product, compatibility, migration,
  security, verification, or operational remediation risk is deferred.
- **Single next eligible workstream:** none; the remediation and handoff are complete.

### Scope and authority

| Time | Agent/session | Current state | Files inspected or touched | Commands run | Result | Blockers | Next action |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 2026-07-28 17:48 EDT | Codex tracker-planning session | Scope, hierarchy, baseline, and non-goals fixed | Inspected planning framework, domain/Core/subsystem owners; touched this tracker only | Repository reads/searches; `git status --short --branch`; `git rev-parse HEAD`; `make lint-markdown` | Planning baseline complete; Markdown passed at `.cartulary/test-results/20260728T215218Z-p1253262` | None for tracker publication | Preserve the one-file diff; implementation needs a new task. |
| 2026-07-28 18:29 EDT | Codex NLSpec-style tracker revision | Normative planning posture and decision/gate distinction added | Read analysis notes, NLSpec guide, local owners, current registry/code; touched this tracker only | `rg`, `sed`, `find`, `git status`, exact owner/code reads; `make lint-markdown`; structural checks | RB decisions resolved; validation passed at `.cartulary/test-results/20260728T223545Z-p1268589` | No open design question; GATE-01 through GATE-07 remain | Preserve the one-file write boundary; implementation needs a later task. |

### Backend module boundary

| Time | Agent/session | Current state | Files inspected or touched | Commands run | Result | Blockers | Next action |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 2026-07-28 17:48 EDT | Codex tracker-planning session | Valid imports boundary diagnosed as internally mixed; all target files inventoried | Inspected all `internal/modules/imports` files, app composition, Network Flow, seven peer owner facades, and migrations; touched this tracker only | `rg`/`git ls-files`/file reads; `make task-guide ROLE=module-author OWNER=module.imports`; target explanations | Inventory and coupling scan complete; tracker Markdown passed | Historical RB-001/RB-003 | Characterize behavior, resolve owner contract, then inject owner registry. |
| 2026-07-28 18:29 EDT | Codex NLSpec-style tracker revision | Owner registry, composition, and two-level commit are specified as gated future requirements | Same live backend evidence plus owner tables; touched this tracker only | Exact Core 01/Network Flow reads and target-registry inspection | Structural path is decision-complete; tracker validation passed | GATE-01, GATE-02, GATE-04, GATE-05 | Complete characterization and coordinated adoption before code movement. |

### Frontend module boundary

| Time | Agent/session | Current state | Files inspected or touched | Commands run | Result | Blockers | Next action |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 2026-07-28 17:48 EDT | Codex tracker-planning session | Controller/assistant surfaces mapped; registry duplication found; no direct grid vendor coupling found | Inspected import coordinator/tests, Import Assistant, Network Flow controller, browser spec, generated contract adapter locations; touched this tracker only | Targeted searches and target explanations | Frontend risk and test posture recorded; tracker Markdown passed | Historical RB-004 | Preserve selectors; wait for an authoritative projection. |
| 2026-07-28 18:29 EDT | Codex NLSpec-style tracker revision | Generated catalog fields, availability rules, and no-fallback consumption are specified | Import Assistant hardcoded set, view-schema index, generated roots; touched this tracker only | Exact file reads and projection-pattern searches | RB-004 design is resolved; tracker validation passed | GATE-04 and GATE-06 | Generate catalog before removing the manual set. |

### Contract and codegen

| Time | Agent/session | Current state | Files inspected or touched | Commands run | Result | Blockers | Next action |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 2026-07-28 17:48 EDT | Codex tracker-planning session | Ten HTTP operations and generated consumers mapped; analytical facade contradiction identified | Inspected authored imports OpenAPI, Core/Network Flow owners, generated consumer locations, target registry; touched this tracker only | `jq`, searches, file reads, generation/compatibility target explanations | Contract freeze map complete except contradicted facade; tracker Markdown passed | Historical RB-001 | Obtain adopted owner resolution before interface changes. |
| 2026-07-28 18:29 EDT | Codex NLSpec-style tracker revision | Binding schema, ownership split, projection schema, generated outputs, and failure rules are specified | Core/Network Flow exact facade tables, extension projection pattern, generated policy; touched this tracker only | Exact owner and contract-pattern reads | Contract design is complete without claiming adoption; tracker validation passed | GATE-02 and GATE-04 | Adopt owners and authored machine projection as one coordinated change. |

### Tests and harness

| Time | Agent/session | Current state | Files inspected or touched | Commands run | Result | Blockers | Next action |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 2026-07-28 17:48 EDT | Codex tracker-planning session | Existing tests and five routed owner rows mapped; missing owner/boundary/accounting coverage identified | Inspected imports, frontend, Network Flow tests, and verification inputs; touched this tracker only | Owner/test/target explanation commands | Gap analysis recorded; no test suite run; tracker Markdown passed | Historical RB-003 | Add characterization before structural movement. |
| 2026-07-28 18:29 EDT | Codex NLSpec-style tracker revision | Eighteen-target, route/state/security/effect, boundary, family, and exact-accounting obligations specified | Same test/harness evidence plus notes recommendations; touched this tracker only | Repository searches and exact harness reads | RB-003 design is resolved; no implementation suite run; tracker validation passed | GATE-01 and GATE-07 | Implement RS-00 in a later authorized task. |

### Security and authorization

| Time | Agent/session | Current state | Files inspected or touched | Commands run | Result | Blockers | Next action |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 2026-07-28 17:48 EDT | Codex tracker-planning session | Admission checks found; immediate pre-mutation current-role recheck not visible | Inspected route authorization, Store guards, Network Flow participants, Core 04; touched this tracker only | Targeted searches and exact file reads | Security gap recorded; no behavior changed; tracker Markdown passed | Historical RB-002 | Add role-revocation characterization and authorize correction. |
| 2026-07-28 18:29 EDT | Codex NLSpec-style tracker revision | Transaction-current authorization, race, cancellation, replay, and capability rules specified | Core 04 acceptance behavior, routes, transaction participants; touched this tracker only | Exact owner and code reads | RB-002 security decisions are complete; tracker validation passed | GATE-03 and GATE-06 | Adopt correction authorization before RS-06. |

### Open risks and next session

| Time | Agent/session | Current state | Files inspected or touched | Commands run | Result | Blockers | Next action |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 2026-07-28 17:48 EDT | Codex tracker-planning session | Workstreams and reversible slices sequenced; implementation unauthorized | This tracker only was touched; evidence read-only | `make help-all` plus targeted explanations; `make lint-markdown` | Handoff decision-complete subject to historical blockers; tracker passed | Historical RB-001 through RB-004 | Resolve RB-001 and begin characterization in a new task. |
| 2026-07-28 18:29 EDT | Codex NLSpec-style tracker revision | All four RB decisions resolved; seven binary gates replace ambiguous blockers | This tracker only touched; analysis notes and authorities read-only | Repository inspection; `make lint-markdown`; diff/structural/one-file checks | No open planning choice remains; tracker validation passed | GATE-01 through GATE-07 are required prerequisites, not open questions | Start with GATE-01 only after a later task authorizes test changes. |

## 11. Resolved Questions and Remaining Gates

There are no remaining design questions for the refactor sequence described by this tracker. The
former RB items are closed at the planning layer as follows:

| ID | Resolution | Decision status | What is not claimed | Required next gate |
| --- | --- | --- | --- | --- |
| RB-001 | Core owns generic orchestration and semantic obligations; the target NLSpec owns exact target payloads; the binding and two-level commit model join them. | IMPLEMENTED | Registry injection, Timeline convergence, durable unit commits, analytical transaction convergence, and outcome-only finalization are complete. | None |
| RB-002 | Authorization, races, unit/partial outcomes, overlap, reselection, nulls, errors, XLSX, cancellation, replay, and capability behavior are exact in §4. | IMPLEMENTED | RS-06 through RS-10 implement and verify every authorized correction. | None |
| RB-003 | The 18-target matrix, cross-cutting suites, boundary rules, harness families, and exact accounting define a complete evidence baseline. | IMPLEMENTED | Exact catalog and source audits, owner slices, complete browser/service-backed runs, and final `make check` prove closure. | None |
| RB-004 | One Core-backed deterministic registry supplies backend, frontend, adapter, verification, and integrity projections; no public field is required for same-release deployment. | IMPLEMENTED | Backend dispatch, generic view selection, and claim-gated Network Flow consumption use generated projections without fallback. | None |

An implementation agent MUST treat any unmet gate in §6.1 as a hard dependency. The active
implementation request authorizes the sequence, but `RESOLVED_IN_TRACKER` alone does not permit a
later slice to start before its dependencies and the preceding tracker checkpoint pass.

## 12. Binary Completion Criteria

### 12.1 Requirement-to-acceptance mapping

| Acceptance ID | Requirements | Pass condition |
| --- | --- | --- |
| IRT-AC-001 | IRT-REQ-001, IRT-REQ-018 | No production slice begins before its owner, characterization, and authorization gates; structural and correction changes remain separate. |
| IRT-AC-002 | IRT-REQ-002 | The existing ten HTTP operations remain compatible through all structural slices; RS-09 adds exactly one compatible operator-region operation; no imports WebSocket event is added. |
| IRT-AC-003 | IRT-REQ-003, IRT-REQ-004 | Core and target ownership are adopted without duplicated exact payload authority; every analytical binding and referenced schema resolves exactly once. |
| IRT-AC-004 | IRT-REQ-005, IRT-REQ-006 | Precommit failure/cancellation leaves no authoritative unit effects; postcommit crash recovers one result; finalization creates no owner resource. |
| IRT-AC-005 | IRT-REQ-007, IRT-REQ-008 | Role/membership/claim/lifecycle removal before commit prevents mutation; a mutation committed first is observed by the administrative change. |
| IRT-AC-006 | IRT-REQ-009 | Overlap fails atomically at selection and apply; concurrent conflicting selection yields at most one success. |
| IRT-AC-007 | IRT-REQ-010 | Skip then select retains the mapping/fingerprint and recomputes unit/session readiness without remapping. |
| IRT-AC-008 | IRT-REQ-011 | `write_null` succeeds only for nullable create fields, `omit_field` applies defaults, new state never emits `use_null`, and retained-data handling matches the preflight. |
| IRT-AC-009 | IRT-REQ-012 | Every registered error translation produces the exact Core result and safe nested owner detail; unknown tokens fail closed without leakage. |
| IRT-AC-010 | IRT-REQ-013 | CSV and all four XLSX locator kinds are deterministic and bounded; hidden/style/filter/sort metadata has no semantic effect; formulas do not execute. |
| IRT-AC-011 | IRT-REQ-014 | All five registry projections are byte-deterministic, share one source digest, cover all 18 rows, and fail every invalid-generation case in §8.3. |
| IRT-AC-012 | IRT-REQ-015 | Frontend has no manual target-ID set; selectable/reserved/claim-gated behavior and selectors pass unit and browser evidence; server revalidation remains mandatory. |
| IRT-AC-013 | IRT-REQ-016 | Every active test resolves to exactly one owner/family/row/selector/evidence/verification set, with zero uncovered targets and duplicate selectors. |
| IRT-AC-014 | IRT-REQ-017 | Imports constructs no concrete peer stores, performs no cross-owner SQL, and writes no owner, analytical, projection, workbook, or grid state directly. |
| IRT-AC-015 | All | Narrow owner and frontend checks pass before `make agent-finalize`; risk-appropriate broader checks and any skips are recorded with run roots. |

### 12.2 Tracker readiness

- [x] Every tracked file in `internal/modules/imports` is inventoried; the empty untracked directory
  is explicitly explained.
- [x] The existing ten public HTTP operations are frozen and the additive eleventh
  operator-region contract is assigned exclusively to RS-09.
- [x] Core-versus-target analytical ownership and the binding interface are exact.
- [x] Unit commit and session/job finalization are specified separately.
- [x] Authorization, race, overlap, reselection, null, errors, XLSX, cancellation, replay, and
  capability defaults are explicit.
- [x] All 18 target rows have availability and evidence obligations.
- [x] Registry fields, outputs, frontend behavior, and generator failures are explicit.
- [x] Every workflow and implementation slice has dependencies, validation, rollback, and a binary
  completion condition.
- [x] Former RB items are `RESOLVED_IN_TRACKER`; unmet adoption/execution work is represented by
  binary gates without false completion claims.
- [x] Prior session history is preserved and the current revision session is appended.
- [x] The complete remediation sequence is authorized subject to the binary workstream gates.
- [x] CP-00 `make lint-markdown`, `git diff --check`, and one-file status check pass.
- [x] RS-06 commits generic, Timeline, and analytical unit effects with one durable outcome,
  revalidates transaction-current authority and input identity, recovers both crash boundaries
  without replay, and derives truthful partial cancellation.
- [x] RS-07 rejects overlapping worksheet rectangles at selection and apply, serializes concurrent
  selection, reselects skipped units without remapping, requires a fresh session for intentional
  duplicate-source import.
- [x] RS-08 uses only canonical `write_null`, preserves deterministic mapping fingerprints,
  persists schema-validated safe owner failures, fails unknown errors closed without leakage, and
  leaves only RS-09 eligible.
- [x] RS-09 discovers bounded used ranges, tables, static names, and hidden data; treats formulas
  and external workbook features inertly; persists exact durable operator regions through the
  additive eleventh operation; and leaves only RS-10 eligible.
- [x] RS-10 consumes generated selectable/claim-gated target semantics without fallback, exposes
  the typed durable operator-region workflow, preserves generic-versus-analytical ownership, and
  leaves only RS-11 eligible.
- [x] RS-11 accounts for every active test exactly once, regenerates topology from authored
  inputs, refreshes timings only from complete successful evidence, closes the discovered
  responsibility/cancellation/harness races, passes all narrow-to-broad acceptance gates, and
  leaves no next eligible workstream.
