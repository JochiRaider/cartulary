# indicators Module Refactoring Tracker and Handoff

## 1. Scope and Source Posture

- **Target path:** `internal/modules/indicators`
- **Target label:** `indicators` (validated lowercase kebab case; no spaces, path separators, shell metacharacters, or unsafe filename characters)
- **Output path:** `docs/handoffs/indicators-module-refactor-tracker.md`
- **Repository baseline:** branch `main`, commit `67d2ce2c98ce9f124c87ca6d980ec9321b4d2ef7`, observed at `2026-08-03T08:32:42-04:00`
- **Status:** Iteration 1 complete; Iteration 2 complete
- **Allowed change:** the specification, authored contracts, implementation, tests, migrations, harness inputs, generated projections, and handoff evidence required by SL-00 through SL-08
- **Non-goals:** unrelated frontend timestamp inference, draft Reference Pack ownership changes, and the historically Timeline-named runtime projection bundle
- **Implementation authorization:** the user authorized the complete remediation plan on `2026-08-03`, including IND-016 owner closure and SL-00 through SL-08

### Active execution protocol

- Execute `tracker bootstrap -> SL-00 -> IND-015 -> IND-016 -> SL-02 -> SL-01 -> SL-03 -> SL-04 -> SL-05 -> SL-06 -> SL-07 -> SL-08`.
- Treat every named workstream as a separately reviewable and reversible commit.
- After validating a workstream, update this tracker with its status, commands, run roots, risks, and next action; commit that checkpoint before starting the next workstream.
- Mark a workstream `BLOCKED` when an entry or exit gate cannot be met, and do not begin dependent work.
- Update authored inputs and invoke Make-owned generators; never hand-edit generated roots or lockfiles.

Checkpoint commits are `23f756f1` (tracker bootstrap), `4aee70a2` (SL-00), `b32ee3c6` (IND-015), `f894d9ca` (IND-016), `c3e54385` (SL-02), `ce06fb35` (SL-01), `ed529695` (SL-03), `4f46b8ff` (SL-04), `7090083b` (SL-05), `c1facd10` (SL-06), `d0b71fbe` (SL-07), and `eae355dc` (SL-08 validation and handoff). The SL-07 SHA ledger closed at `ea6b251d`; this final ledger-only commit records the SL-08 SHA because a content commit cannot contain its final self-referential SHA.

### Implementation baseline

- Starting branch and commit: `main` at `67d2ce2c98ce9f124c87ca6d980ec9321b4d2ef7`.
- Starting tracked change: this newly added tracker only; no pre-existing production, contract, test, or generated-artifact changes.
- `make backend-module-boundary-check` passed at `.cartulary/test-results/20260803T135505Z-p3870704`.
- `make generated-artifact-policy-check` passed at `.cartulary/test-results/20260803T135507Z-p3871025`.
- `make json-shape-check` passed at `.cartulary/test-results/20260803T135508Z-p3871422`.
- `make service-backed-test-slice OWNER=module.indicators` passed at `.cartulary/test-results/20260803T135514Z-p3871882`.

The authority order used for this plan is:

1. adopted subsystem NLSpecs within their named scope;
2. Core 00 through Core 04 for implementation-conformance behavior;
3. Core 05 only for claim-bearing timed or fixture-sensitive publication;
4. domain vocabulary and implementation-support guides;
5. current repository code and tests;
6. prior plans, handoffs, and the planning framework as evidence only.

Core 05 is not applicable to this planning artifact because this task publishes no timed, benchmark, or fixture-sensitive claim. No owner contradiction was found. The draft Reference Pack NLSpec is evidence only and does not supersede the current Core 02 assignment of canonical indicator behavior to the Indicators owner.

### Document conventions

This tracker uses four statement classes. A later agent MUST determine the class before treating any sentence as an implementation instruction.

| Class | Meaning | Normative effect |
| --- | --- | --- |
| Current-state finding | A fact observed in the repository baseline. | Descriptive evidence only; it MUST be rechecked if the baseline changes. |
| Adopted-owner requirement | A requirement cited to an adopted Core or subsystem NLSpec. | Binding within that owner's scope. `MUST`, `MUST NOT`, and `MAY` retain their ordinary normative meanings. |
| Authorized implementation requirement | A slice-local requirement that translates adopted behavior into implementation and acceptance gates. | Binding only in a later repository-change task whose scope includes that slice. |
| Proposed owner language | Text that an owner document still needs to adopt. | Non-authoritative until adoption. Code, tests, contracts, and this tracker MUST NOT treat it as current product behavior. |

Unless a requirement explicitly states otherwise, the default is behavior preservation: public routes, envelopes, errors, events, view and saved-view identity, projections, authorization, generated contracts, and frontend selectors MUST remain unchanged. An omitted mechanism is intentionally left to the implementer only when two conforming implementations remain interchangeable at every affected boundary. `TODO` identifies missing evidence; `BLOCKED` identifies a gate that forbids implementation. Requirements are defined once in Sections 4 and 7 and referenced by stable ID elsewhere.

### Owner documents inspected

- `docs/handoffs/cartulary_modular_refactor_planning_framework.md` (read first; template and doctrine only)
- `docs/domain.md`
- `docs/spec/00_document_set_status_and_precedence.md`
- `docs/spec/01_architecture_storage_and_view_contracts.md`
- `docs/spec/02_domain_model_schema_and_history.md`
- `docs/spec/03_workbook_interaction_collaboration_and_workflows.md`
- `docs/spec/04_security_deployment_and_conformance.md`
- `docs/network-flow-activity-nlspec.md` (adopted/current)
- `docs/graph_projection_nlspec.md` (adopted/current; explicitly not the workbook-grid projection owner)
- `docs/testing-harness-nlspec.md` (adopted/current)
- `docs/reference-pack-subsystem-nlspec.md` (draft; non-authoritative evidence only)

### Supporting planning material inspected

- `temp/analysis-notes.md` (gap analysis and proposed closure language; evidence only)
- `docs/research/nlspec-spec.md` (writing and evaluation guidance; non-authoritative)

### Repository files inspected

- Every file under `internal/modules/indicators`, inventoried individually in Section 2.
- Composition and caller paths: `internal/app/workbookassembly/catalog.go`, `internal/app/projectionassembly/catalog.go`, `internal/app/importassembly/owner_registry.go`, `internal/app/incidentportabilityassembly/catalog.go`, `internal/app/recoveryassembly/state_catalog.go`, `internal/app/revisionassembly/revisions.go`, and `internal/app/server/runtime.go`.
- Workbook and Network Flow adapters: `internal/modules/workbook/mutation_contributions.go`, `internal/modules/workbook/mutation_api.go`, `internal/modules/workbook/routes.go`, `internal/modules/networkflow/ports.go`, `internal/modules/networkflow/transaction_participants.go`, `internal/modules/networkflow/indicator_link.go`, and `internal/modules/networkflow/binding_store.go`.
- Projection and revision paths: `internal/modules/projections/provider_factories.go`, `internal/modules/projections/provider_registry.go`, `internal/modules/projections/entity_grids.go`, `internal/modules/revisions/appender.go`, `internal/modules/revisions/indicator_children_test.go`, and relevant portions of projection query, rebuild, and delete/restore tests.
- Authored contracts and support manifests: `contracts/view-schemas/cartulary.view.indicators.v1.json`, `contracts/imports/view-targets.v1.json`, `contracts/imports/index.json`, `contracts/projection-providers/index.json`, `contracts/incident-bundles/source_catalog.json`, `contracts/recovery/fixtures/recovery-state-catalog.v1.json`, `contracts/verification/owners/module.indicators.json`, `tools/test_families/module.indicators.json`, `tools/schema_object_ownership_manifest.json`, and `tools/backend_module_boundaries.json`.
- Storage inputs: `db/migrations/00009_indicator_source.sql`, `db/migrations/00016_workbook_projections.sql`, `db/migrations/00026_indicator_child_rollback_tombstones.sql`, `db/migrations/00030_network_flow_indicator_bindings.sql`, and `db/migrations/00044_collaboration_owner_producers.sql`.
- Generic frontend and view-contract consumers: `packages/view-contracts/src/index.ts`, `packages/view-contracts/src/index.test.ts`, `packages/ui-contracts/src/workbook-shell-grid-selectors.test.ts`, `apps/web/src/workbook/models/workbookQuery.ts`, relevant Indicator cases in `apps/web/src/workbook/WorkbookShell.surfaces.test.tsx`, `apps/web/src/workbook/WorkbookShell.query.test.tsx`, `apps/web/e2e/keyboard.spec.ts`, and `apps/web/e2e/incident-administration.spec.ts`.
- Cross-owner test support: `internal/modules/workbook/testsupport/scenariotest/route_inventory.go`, `internal/modules/workbook/testsupport/scenariotest/record_fixtures.go`, and `internal/modules/workbook/notes_indicators_test.go`.

Generated consumers under `internal/gen/**`, `packages/protocol-ts/src/generated/**`, and `packages/ui-contracts/src/generated/**` were identified by search as drift-sensitive downstream artifacts. They must never be hand-edited; any later change must start from the adopted owner and authored contract input and use the Make-owned generator.

## 2. Current-State Repository Inventory

All 50 files currently under `internal/modules/indicators` are in scope and inventoried below. None is excluded.

| Path | Current responsibility | Exported/public symbols or package surface | Inbound callers | Outbound dependencies | Tests touching it | Generated artifacts or contracts touched | Suspected target owner module | Risk level | Notes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| `internal/modules/indicators/api.go` | Indicator view identity, root `Store`, required typed dependencies, semantic create/participant DTOs, command validation, and mutation result assembly. | `ViewSchemaID`, `IndicatorFindOrCreateParticipantV1`, `ErrInvalidCreateRequest`, `Store`, `StoreDependencies`, `ProjectionPort`, `NewStore`, `CreateCommand`, `ValidateCreateCommand`, participant/record/result types, `BuildMutationPayload`. | Workbook create contribution; Indicator store/import/tests; Network Flow consumes record/participant types. | Auth, Records, Revisions, Postgres, PGX, UUID; no HTTP, view-schema, or concrete Projections dependency. | Route, store, identity, projection-delegation, Workbook admission, and Network Flow tests. | Indicator view schema and generated consumers remain external contract inputs. | Indicators. | high | SL-04 completed the required `{Postgres, Revisions, Projections}` constructor; the narrow port preserves dependency direction. |
| `internal/modules/indicators/boundary_guard_test.go` | Production sibling-import allowlist plus source-prefix and admission transport-neutrality guards. | `TestIndicatorsProductionImportBoundaries`, `TestIndicatorsDoNotUseEntitiesSourcePrefixes`, `TestIndicatorAdmissionIsTransportNeutral`. | Go test and broad harness execution. | Go parser/filesystem inspection. | Self. | Backend module-boundary policy by alignment. | Indicators test boundary. | medium | SL-01 now locks HTTP/view-schema adapters out of the Indicator admission/API seam; projection-storage enforcement remains SL-04. |
| `internal/modules/indicators/internal/providers/deleterestore/provider.go` | Indicator source snapshot, tombstone update, view resolution, and delete preconditions for Revisions. | Owner-internal `Source`, constructor, snapshot, state-update, view, and precondition methods. | Root `NewRevisionContribution`; Revisions only receives its generic contract. | PGX, rollback/delete-restore contracts, fixed Indicator SQL. | Revisions delete/restore and integration tests. | Revision provider catalog and Indicator view contract. | Indicators source-owned provider. | high | SL-05 makes the implementation Go-internal and boundary-confined. |
| `internal/modules/indicators/import_create.go` | Indicator-owned Imports facade and caller-transaction row creation. | `ImportCreateCommand`, `NewImportCreateFacade`, `Store.CreateImportRowTx`. | Import assembly owner registry and Imports owner facade. | Imports owner facade, Revisions appender, PGX, indicator store internals. | Imports characterization/registry tests and indicator owner integration indirectly. | Import target/index projections. | Indicators, exposed through Imports facade. | high | Legitimate thin adapter; must keep import transaction and result semantics stable. |
| `internal/modules/indicators/incident_bundle_contribution.go` | Constructs the complete public owner contribution for portability and subtype presence. | `IncidentBundleContribution`, `NewIncidentBundleContribution`. | Incident portability assembly catalog and owner tests. | Generic source-port and subtype-presence contracts plus the owner-internal provider. | Indicator catalog/boundary and Incident Bundle source-catalog tests. | Incident-bundle source catalog. | Indicators contribution façade. | high | Incident Bundles receives generic contracts and cannot import Indicator portability semantics. |
| `internal/modules/indicators/internal/providers/incidentbundle/portable_apply.go` | Applies prepared Indicator source rows with fixed-column parameterized SQL and exact affected-row checks. | Owner-internal apply and attribution helpers. | Owner-internal source port only. | PGX, source-port context, fixed Indicator SQL, Records reference reads. | Focused final-state invariants and full Incident Bundle imports. | Three Indicator source-major-1 row contracts. | Indicators portability provider. | critical | No generic record population, conflict-ignore, independent transaction, or raw database error projection remains. |
| `internal/modules/indicators/internal/providers/incidentbundle/portable_export.go` | Selects explicit source columns, verifies envelope/attribution/semantic state, and emits canonical ordered NDJSON. | Owner-internal export/load/encode helpers. | Owner-internal source port only. | Incident portability canonical JSON, owner identity/origin, source attribution resolver, fixed SQL. | Portable characterization and Incident Bundle v1/v2 round trips. | Three Indicator source-major-1 row contracts. | Indicators portability provider. | critical | Physical column order and table-shaped JSON are excluded from the wire contract. |
| `internal/modules/indicators/internal/providers/incidentbundle/portable_model.go` | Defines typed prepared rows, immutable context binding, canonical scalar parsing, closed invariant ranking, and deterministic failure selection. | Owner-internal model and pure helpers. | Owner-internal prepare/apply/validate paths. | UUID, source-port context, origin registry, bounded hashing. | Strict decoding, binding, precedence, and safe-failure tests. | Core 01 REQ-01-640 invariant order. | Indicators portability provider. | critical | Internal digests only break ties when stable identity is unavailable and are never exposed. |
| `internal/modules/indicators/internal/providers/incidentbundle/portable_prepare.go` | Strictly decodes exact rows and performs row-local representation, normalization, uniqueness, chronology, and coherence admission. | Owner-internal prepare helpers. | Owner-internal source port only. | Strict NDJSON decoder, owner identity/origin, typed source context. | One negative case per prepare-owned invariant plus three multi-defect permutations. | Indicator row schemas and AC-531. | Indicators portability provider. | critical | Unknown, missing, duplicate, aliased, wrongly typed, noncanonical, multivalue, and trailing input fail without repair. |
| `internal/modules/indicators/internal/providers/incidentbundle/portable_validate.go` | Rechecks final transaction state, Records envelopes, attributions, references, exact rows, and repeated observations. | Owner-internal validation/load/equality helpers. | Owner-internal source port only. | PGX transaction, Records read boundary, typed prepared model. | Focused cross-family/final-state invariants and coordinator atomicity suites. | Core 01 REQ-01-640/641 and AC-531. | Indicators portability provider. | critical | Validation observes the caller transaction and never commits, repairs, publishes, or leaks storage details. |
| `internal/modules/indicators/internal/providers/incidentbundle/source_port.go` | Constructs the typed portability descriptor and delegates strict export/prepare/apply/validate operations. | Owner-internal `NewSourcePort`. | Root Incident Bundle contribution only. | Source-port contract and typed owner-internal portability functions. | Source-catalog, strict invariant, route, and round-trip tests. | `contracts/incident-bundles/source_catalog.json`. | Indicators portability provider. | critical | All ten invariants are closed and prepared values are operation/incident/version/contract bound. |
| `internal/modules/indicators/internal/providers/incidentbundle/subtype_presence.go` | Supplies Indicator record subtype presence to the root contribution. | Owner-internal `SubtypeContribution` and source methods. | Root Incident Bundle contribution only. | Records subtype-presence contract and PGX. | Incident Bundle catalog/integration tests. | Incident-bundle subtype/source catalog. | Indicators portability provider. | low | Narrow implementation is invisible to generic coordination. |
| `internal/modules/indicators/identity_characterization_test.go` | Locks normalization, representation validation, dedupe inputs, registry coverage, and invalid aliases before identity extraction. | `TestIndicatorIdentityCharacterization`, `TestIndicatorIdentityCharacterizationRejectsAliasesAndIncompleteHashes`. | Focused Indicator identity row. | Target-private identity functions only. | Self. | `module.indicators` identity evidence. | Indicators tests. | high | Covers every supported type and every currently legal type/value-kind combination without blessing aliases. |
| `internal/modules/indicators/identity_concurrency_test.go` | Proves two overlapping transactions converge on one active canonical identity and create no orphan Record. | `TestConcurrentIndicatorFindOrCreateConvergesOnOneActiveIdentity_Integration`. | Dedicated Indicator identity-concurrency row. | Indicator owner façade, application store harness, Postgres lock visibility, and Revisions support. | Self. | `module.indicators.verification.identity_parity_and_concurrency`. | Indicators tests. | critical | Verifies the existing incident-open transaction lock and unique identity constraint serialize competing owner workflows without adding a redundant lock. |
| `internal/modules/indicators/identity_portability_test.go` | Proves portable Indicator preparation uses canonical normalization and rejects duplicate canonical identities. | `TestIndicatorPortablePreparationUsesCanonicalIdentity`. | Focused Indicator identity row. | Indicator source port and owner-internal identity service. | Self. | `module.indicators` identity and portability evidence. | Indicators tests. | high | Uses a local bundle test interface so owner-port imports remain within the production contribution boundary. |
| `internal/modules/indicators/internal/identity/identity.go` | Pure canonical identity, representation validation, observation candidate normalization, and dedupe derivation for all Indicator entry paths. | Owner-internal `Input`, `Canonical`, `ValidationError`, and pure normalization functions. | Indicator Store, rollback provider, and portability preparation. | `fieldnorm` plus Go standard-library value parsers and hashing only. | Identity, IP, portability, rollback, import, Network Flow, and service-backed Indicator tests. | Core 02 Indicator identity and Core 01 portability invariants. | Indicators. | critical | Transport- and SQL-independent single semantic implementation; defanged and STIX presentation values remain outside dedupe material. |
| `internal/modules/indicators/internal/origin/origin.go` | Closed observation-origin registry, exact parser, and opaque producer capability. | Owner-internal origin constants, `Parse`, ordinary producer constructors, `TrustedSystemProducer`, and `ProducerContext.OriginForWrite`. | Indicator root façade, observation repository, rollback provider, and portability preparation. | Go standard library only. | Focused origin, rollback, portability, and service-backed observation tests. | Core 02 origin registry and Core 04 AC-530. | Indicators. | critical | `system` is parseable for trusted stored/imported data but only owner-internal code can construct its write capability. |
| `internal/modules/indicators/indicators_test.go` | Canonical identity, repeated observations, lifecycle derivation, and Network Flow participant rollback evidence. | `TestIndicatorsCanonicalObservationLifecycle_Unit`, `TestNetworkFlowCore02_IndicatorFindOrCreateParticipantRollback`. | Focused owner row for the canonical lifecycle test; broad Go suite for participant coverage. | App test support, auth fixtures, timeline fixtures, revisions support, PGX. | Self. | `module.indicators` test-family evidence. | Indicators tests. | medium | Direct analyst-entry observations now use the exact `manual_entry` owner token. |
| `internal/modules/indicators/ip_identity_test.go` | Exact IPv4/IPv6 normalization, rejection, create validation, and dedupe evidence. | Four exported test functions. | Broad Go suite; not mapped to a focused `module.indicators` row. | Target-private identity functions. | Self. | Core 02 identity behavior; no direct generated artifact. | Indicators tests. | high | Required characterization before identity extraction. |
| `internal/modules/indicators/lifecycle_repository.go` | Fixed lifecycle interval insert and current-summary SQL over a caller-owned transaction. | Owner-private `lifecycleRepository` methods. | Indicator Store workflows and projection derivation. | PGX and Indicator row types only. | Canonical lifecycle and transaction rollback tests. | Indicator authoritative table ownership. | Indicators source repository. | high | SL-03 extracted persistence without granting transaction, revision, projection, or idempotency ownership. |
| `internal/modules/indicators/portability_characterization_test.go` | Locks deterministic export, exact member/null presence, canonical timestamps, stable path order, and shared v1/v2 source support. | `TestIndicatorPortableRowsCharacterization_Integration`. | Focused Indicator portability row. | Indicator facade, strict source port, portability decoder, Postgres fixtures. | Self. | `module.indicators` portability evidence and test-family topology. | Indicators tests. | critical | Confirms source-major-1 export is schema-bound and deterministic. |
| `internal/modules/indicators/portability_final_state_test.go` | Exercises valid apply/validate plus observation/interval same-incident and repeated-observation final-state failures. | `TestIndicatorPortableFinalStateInvariants_Integration`. | Focused Indicator portability state row. | Public Indicator contribution, source-port contracts, Postgres fixtures. | Self. | `module.indicators.verification.portability_invariants`. | Indicators tests. | critical | Uses caller-owned transactions and explicit source attribution to prove final-state behavior. |
| `internal/modules/indicators/portability_invariants_test.go` | Exercises strict shape/scalar rejection, all prepare-owned invariants, binding, safe redaction, and deterministic multi-defect precedence. | Four exported portability tests. | Focused Indicator portability partition row. | Public Indicator contribution and owner identity helpers. | Self. | `module.indicators.verification.portability_invariants`. | Indicators tests. | critical | Hostile values never appear in the public family/invariant failure. |
| `internal/modules/indicators/network_flow_participant.go` | Active indicator lookup and Core 02 find-or-create participant inside the caller transaction. | `Store.GetActiveIndicatorParticipant`, `GetActiveIndicatorParticipantTx`. | Network Flow ports, binding store, and transaction participants. | PGX, fixed indicator queries, root identity/upsert behavior. | Indicator participant rollback and Network Flow route/behavior tests. | Network Flow generated/request contracts by behavioral dependency only. | Indicators participant port. | high | Must retain no independent commit, observation, lifecycle, link, binding, or audit side effect. |
| `internal/modules/indicators/observation_origin.go` | Public Indicator-owned observation-origin type and six ordinary producer capabilities. | `ObservationOrigin`, seven exact token constants, `ParseObservationOrigin`, `ObservationProducerContext`, and six non-system producer constructors. | Observation writers and cross-owner test fixtures. | Owner-internal origin registry only. | Focused origin surface/parser tests and all observation workflows. | Core 02 exact origin vocabulary. | Indicators façade. | critical | There is deliberately no public `system` producer constructor and no raw origin string in observation create parameters. |
| `internal/modules/indicators/observation_origin_integration_test.go` | Proves exact database enforcement, valid ordinary writes, and stored `system` support. | `TestIndicatorObservationOriginConstraint_Integration`. | Focused service-backed origin row. | Indicator façade, Postgres harness, auth/timeline fixtures. | Self. | Migration 00055 and AC-530 storage evidence. | Indicators tests. | high | Uses a savepoint so the expected invalid write cannot poison the harness transaction. |
| `internal/modules/indicators/observation_origin_test.go` | Proves exact parsing, producer mapping, absence of a public system constructor, and pre-transaction rejection. | Three focused test functions. | Focused unit origin row. | AST parser, Indicator façade, inert Postgres seam. | Self. | `module.indicators.verification.observation_origin`. | Indicators tests. | high | Locks rejection of empty, alias, case, whitespace, and extension-shaped inputs before transaction start. |
| `internal/modules/indicators/observation_repository.go` | Fixed observation insert/load/resolve, aggregate, and source-membership SQL over caller-owned transactions. | Owner-private `observationRepository` methods and aggregate type. | Indicator observation workflows and projection derivation. | Identity service, Records/Revisions sentinel semantics, field normalization, PGX. | Observation separation, resolution, route, and transaction rollback tests. | Indicator authoritative table ownership. | Indicators source repository. | critical | SL-03 keeps repeated observations distinct and affected-row checks explicit while excluding transaction coordination. |
| `internal/modules/indicators/internal/providers/projection/provider.go` | Shared canonical derivation plus transactional row refresh and incident-wide rebuild of `indicator_grid_projection`. | Owner-internal refresh and rebuild functions. | Root projection contribution only. | PGX; Records, Indicators, observations, intervals, Links, and Projections-owned storage. | Indicator route/rebuild equality, projection delegation/atomicity, and Projections provider tests. | Projection provider descriptor advertises `refresh_row=true`. | Indicators source provider. | high | SL-05 prevents Projections from importing this implementation leaf. |
| `internal/modules/indicators/internal/providers/projection/query_surfaces.go` | Declares generic query fields, storage columns, and row assembly metadata. | Owner-internal query-surface constructor. | Root projection contribution only. | Generic projection provider contract. | Indicator contribution and assembled query tests. | Projection provider descriptor and Indicator view schema. | Indicators source query descriptor. | high | Query semantics remain source-owned while execution remains generic. |
| `internal/modules/indicators/projection_contribution.go` | Adapts owner-internal projection behavior into a neutral Projections source and query contract. | `ProjectionContribution`, `NewProjectionContribution`, `Source`, `QuerySurfaces`. | Projection assembly. | Generic Projections contracts plus owner-internal projection provider. | Projection catalog, source-ownership, and owner contribution tests. | Projection provider manifest/import policy. | Indicators contribution façade. | high | Projections receives only the neutral source interface and provider descriptor inputs. |
| `internal/modules/indicators/projection_contribution_test.go` | Locks completeness of the Indicator query contribution against its view schema. | `TestProjectionContributionOwnsCompleteIndicatorQuerySurface`. | Indicator unit slice. | View-schema registry and root contribution. | Self. | Indicator projection contract evidence. | Indicators tests. | medium | Detects field drift without exposing the provider leaf. |
| `internal/modules/indicators/provider_encapsulation_test.go` | Rejects generic-coordinator imports of Indicator implementation packages and validates contribution completeness. | `TestIndicatorProviderImplementationsAreInternal`. | Focused Indicator structure row. | Go parser/filesystem and root contributions. | Self. | Backend boundary and owner test-family inputs. | Indicators boundary test. | high | Supplements Go `internal` enforcement with an explicit architecture regression lock. |
| `internal/modules/indicators/recovery_state.go` | Declares three authoritative Indicator tables for recovery. | `RecoveryStateContribution`. | Recovery assembly state catalog. | Recovery state contract. | Recovery catalog/restore tests indirectly. | Recovery state catalog. | Indicators recovery contribution. | low | `indicator_grid_projection` correctly remains Projections-owned derived state. |
| `internal/modules/indicators/repositories.go` | Declares the three unexported caller-transaction repository seams and their ownership constraint. | Owner-private `sourceRepository`, `observationRepository`, and `lifecycleRepository`. | Root Store construction. | None. | Store composition boundary test. | Backend SQL access policy by alignment. | Indicators. | medium | Repository types cannot begin/commit transactions or own revisions, projections, or idempotency. |
| `internal/modules/indicators/resolution_integration_test.go` | Real HTTP create/query, attribution, observations/lifecycle projection, and rebuild-equality evidence. | `TestIndicatorsRoute_Integration`. | Focused Indicator integration test row. | Server/app support, workbook scenario query helper, timeline fixtures, target Store. | Self. | Indicator behavior and incident-portability verification IDs. | Indicators integration test. | medium | Strong route/rebuild baseline; direct analyst-entry fixtures now use `manual_entry`. |
| `internal/modules/indicators/revision_append_port.go` | Consumer-owned narrow adapter to the Revisions append-only facade. | Private port and adapter methods. | Root Store only. | Revisions appender, PGX, UUID. | Indicator store tests exercise it; Revisions tests cover appended history/intents. | Revisions/collaboration behavior contracts. | Indicators application adapter. | medium | `AppendRecordRevisionTx` already appends the collaboration intent through Revisions. |
| `internal/modules/indicators/revision_provider_contribution.go` | Composes Indicator record delete/restore, row rollback, and observation/interval rollback contributions. | `NewRevisionContribution`. | Revision assembly. | Owner-internal delete/restore and rollback providers; generic Revisions contract. | Revision assembly, delete/restore, child rollback, and encapsulation tests. | Revisions provider catalog. | Indicators contribution façade. | high | Revisions receives only the generic contribution; provider IDs and target kinds remain stable. |
| `internal/modules/indicators/internal/providers/rollback/children.go` | Describes and inverses observation/lifecycle history entries, locks affected records, tombstones or restores child state, and reports changed fields. | Owner-internal child provider surface. | Root revision contribution through Revisions. | PGX, rollback contract, direct Indicator child and Records SQL. | Local child tests and `revisions/indicator_children_test.go`. | Core 02 rollback behavior. | Indicators rollback provider. | critical | Go-internal ownership preserves exact protected sets, tombstones, projection effects, and history. |
| `internal/modules/indicators/internal/providers/rollback/children_test.go` | Parser compatibility, identity-drift rejection, and affected-field evidence. | Three test functions. | Broad Go suite. | Target rollback provider internals. | Self. | Rollback behavior only. | Indicators tests. | medium | Moved with the provider so private invariants remain locally testable. |
| `internal/modules/indicators/internal/providers/rollback/provider.go` | Validates historical Indicator values and restores the authoritative Indicator source row. | Owner-internal row provider surface. | Root revision contribution through Revisions. | PGX, rollback contract, shared Indicator identity service. | Local provider and Revisions rollback tests. | Indicator identity/history contract. | Indicators rollback provider. | high | SL-02 removed duplicate identity rules; SL-05 removes external package visibility. |
| `internal/modules/indicators/internal/providers/rollback/provider_test.go` | Historical value filtering and derived-field exclusion evidence. | Local test function. | Broad Go suite. | Target rollback provider internals. | Self. | Indicator rollback contract. | Indicators tests. | medium | Preserved alongside the internal provider. |
| `internal/modules/indicators/source_repository.go` | Fixed Indicator source load/insert/update, incident-validation, and support-count SQL over caller-owned transactions. | Owner-private `sourceRepository` methods. | Indicator Store workflows and projection derivation. | PGX and Indicator row scanners. | Create/replay, Network Flow, route, and transaction rollback tests. | Indicator authoritative table ownership and backend SQL access policy. | Indicators source repository. | critical | SL-03 centralizes source lock/query shape without changing identity, transaction, or public behavior. |
| `internal/modules/indicators/store.go` | Coordinates create, observation, lifecycle, idempotency, Records, Revisions, repositories, and transactional projection refresh/load through the injected port. | `IndicatorCreateValidationError`; observation/lifecycle parameter and record types; five public `Store` methods. | Workbook create adapter, Imports facade, Network Flow participant, target and cross-owner tests. | Auth, Records, Revisions, Postgres/PGX, repositories, and the owner projection port; no projection-table SQL. | Indicator store/route/unit/IP tests; workbook, revisions, Network Flow, projection, and import tests indirectly. | View schema, projection provider, import, portability, collaboration, recovery, and generated consumers. | Indicators workflow facade. | critical | SL-04 removed physical projection coupling and uses generic row load for mutation responses and history values. |
| `internal/modules/indicators/store_composition_test.go` | Requires complete typed Store composition and statically excludes workflow concerns from repository files. | `TestIndicatorStoreCompositionAndRepositoryBoundaries`. | Focused Indicator structure row. | Local source inspection and inert Postgres interface. | Self. | `module.indicators` behavior verification. | Indicators tests. | high | Prevents constructor fallback and repository responsibility regression. |
| `internal/modules/indicators/store_test_helpers_test.go` | Centralizes checked construction of the typed Indicator Store in external-package tests. | Owner-test-private `newIndicatorTestStore`. | Indicator service-backed tests. | Indicator Store, Revisions appender, Postgres interface. | Test support only. | None. | Indicators tests. | low | Removes ignored constructor errors from fixtures. |
| `internal/modules/indicators/testsupport/fixtures.go` | Shared canonical Indicator example values and times. | `Example`, `Examples`, time constants. | Indicator target tests. | Go time package only. | Indicator store and route tests. | Test evidence only. | Indicators test support. | low | SL-04 removed its direct projection-table lookup; external tests load through the generic coordinator. |
| `internal/modules/indicators/testsupport/routetest/inventory.go` | Incident authorization control inventory for Indicator query. | `ControlQuery`. | Incident HTTP conformance tests. | Generic route inventory and Indicator view ID. | Incidents conformance suites. | Route inventory/evidence accounting. | Indicators test support with Workbook route ownership. | medium | Local inventory covers query; generic workbook scenario inventory covers create/replay/auth. |
| `internal/modules/indicators/transaction_atomicity_test.go` | Injects revision failure after repository/projection work and proves source, projection, history, idempotency, observation, and lifecycle rollback. | `TestIndicatorWorkflowRollsBackRepositoryWritesOnRevisionFailure_Integration`. | Focused Indicator transaction row. | Postgres fixture, Indicator internals, auth and incident fixtures. | Self. | `module.indicators` behavior verification and generated topology. | Indicators tests. | critical | Provides the SL-03 all-or-nothing regression lock; projection-port-specific injection follows in SL-04. |
| `internal/modules/indicators/unit_test.go` | Focused repeated-observation separation and projection aggregation evidence. | `TestIndicatorObservationSeparation_Unit`. | Focused Indicator store row. | App/store fixtures, timeline fixtures, revisions support, target Store. | Self. | `module.indicators` test-family evidence. | Indicators tests. | medium | Repeated direct analyst-entry observations use `manual_entry`. |

## 3. Module Boundary Diagnosis

The current target is a legitimate permanent source-owner module, not an accidental boundary created solely by the directory name. Core 01 requires an Indicators concern, and Core 02 assigns canonical indicators, source-bound observations, lifecycle intervals, and the named Network Flow transaction participant to that owner. SL-01 through SL-05 removed transport admission, identity duplication, authoritative persistence, physical projection coupling, the redundant query path, and generic-coordinator access to Indicator provider implementations from the workflow root. SL-06 and SL-07 closed exact provenance and schema-bound portability; SL-08 now provides explicit verification ownership and final repository evidence.

| Responsibility found | Current location | Correct owner candidate | Keep / move / split / defer | Evidence | Notes |
| --- | --- | --- | --- | --- | --- |
| Canonical Indicator identity, normalization, validation, and dedupe | `api.go`, `store.go`, duplicated in `rollbackprovider/provider.go` | Indicators | split | Core 02 REQ-02-072 through REQ-02-074C; IP tests; live/rollback implementations | Create one owner-internal identity component while preserving exact current conformant outputs. |
| Canonical row create application coordination | `Store.CreateIndicatorRow` | Indicators | keep | Core 01 row-create contract; workbook contribution; route integration test | Keep as a facade, but separate transaction/idempotency coordination from persistence. |
| HTTP JSON/view-schema admission and HTTP error construction | `api.go`, called by Workbook contribution | Workbook transport adapter plus Indicators semantic validation | move | Generic workbook routes own the public envelope; `api.go` imports `httpapi` | Do not change request fields, normalization, errors, or hash/replay semantics. |
| Indicator source persistence | `store.go` | Indicators | split | Schema ownership maps `indicators`, `indicator_observations`, and `indicator_state_intervals` to Indicators | Fixed SQL may remain, but behind a source repository seam. |
| Observation capture/resolution | `store.go` | Indicators | keep | Core 02 REQ-02-075 through REQ-02-078 and REQ-02-260 | Raw text, source binding, repeated rows, attribution, and rollback are frozen. |
| Indicator lifecycle interval append | `store.go` | Indicators | keep | Core 02 REQ-02-079, REQ-02-080, and REQ-02-260 | Append-only semantics remain distinct from observation times. |
| Network Flow canonical find/create participant | `network_flow_participant.go`, root Store helpers | Indicators | keep | Core 02 REQ-02-074C and adopted Network Flow NLSpec | Remain binding-only and caller-transaction scoped. |
| Projection source derivation and query descriptor | `projectionprovider/**` | Indicators source provider | keep | Core 01 REQ-01-622 and live provider descriptor | Projection storage lifecycle remains Projections-owned. |
| Projection row refresh | `projectionprovider/provider.go` through the injected Projections coordinator | Indicators source provider behind a Projections-owned coordination port | split complete | Provider descriptor advertises row refresh and the boundary policy confines projection-table writes | Same-transaction refresh and rebuild share one derivation. |
| Projection query execution | Generic Projections query service with the Indicators query descriptor | Projections query service with Indicators query descriptor | move complete; local path removed | Workbook assembly and mutation row loads use generic query services; Indicator keyset coverage moved to the generic suite | Sorting/filtering/grouping/cursor behavior has one production implementation. |
| Imports apply | `import_create.go` | Indicators owner facade coordinated by Imports | keep | Import owner registry and target contracts | No parser or job coordination belongs in Indicators. |
| Incident portability | `incident_bundle_*` | Indicators owner port coordinated by Incident Bundles | keep | Core 01 REQ-01-639/640 and source catalog | Strict source-major-1 export, preparation, apply, and validation are complete behind the owner contribution. |
| Recovery state | `recovery_state.go` | Indicators contribution coordinated by Recovery | keep | Recovery state catalog | Only authoritative source tables are contributed. |
| Record and child history/rollback | `revision_*`, `deleterestore`, `rollbackprovider` | Indicators providers coordinated by Revisions | keep | Core 02 REQ-02-260 and Revisions provider catalog | Narrow exported providers; do not centralize source semantics in Revisions. |
| Collaboration publication | Revisions `Appender`, reached through `revision_append_port.go` | Collaboration/Revisions | keep | Core 01 REQ-01-271A; `AppendRecordRevisionTx` appends one intent | Indicators supplies row semantics but owns no WebSocket transport. |
| Saved-view behavior | Generic saved-view/query controllers and contracts | Saved Views/Workbook | defer | No saved-view code or import exists in the target | Freeze view/query identity; no Indicator-specific saved-view module. |
| Frontend timestamp filter inference | `apps/web/src/workbook/models/workbookQuery.ts` | Workbook/view-contract consumer | defer | Raw checks for Indicator observation timestamp field keys | Prefer future `read_kind` metadata consumption; not part of this backend module refactor. |
| Frontend shell/controller and grid-vendor integration | Generic Workbook shell, UI contracts, grid adapter | Workbook/UI/grid adapter | defer | No target production frontend or grid-vendor import exists | No reason to create an Indicator-specific frontend controller or vendor adapter. |
| Future normalization registry | Current Indicator owner; draft Reference Pack direction | Indicators until a later adopted owner changes it | defer | Reference Pack NLSpec is draft | Do not move behavior based on draft ownership. |

Repository/framework mismatch finding: the live production query is already generic and Projections-owned, while the target still retains a separate direct query implementation. In addition, the server exposes the generic projection catalog through the historically named `Runtime.Timeline.ProjectionCatalog` bundle. These names and duplicate paths are current implementation state, not evidence that Timeline owns Indicator behavior.

## 4. Public Contract and Behavior Freeze Map

| Contract | Current owner | Evidence | Existing tests | Required characterization tests | Refactor risk | Notes |
| --- | --- | --- | --- | --- | --- | --- |
| `POST /api/v1/incidents/{incident_id}/views/cartulary.view.indicators.v1/rows` | Workbook route; Indicators create semantics | Core 01 REQ-01-032, REQ-01-057, REQ-01-331; workbook route/contribution | Indicator route integration; generic workbook scenario inventory; browser create cases | Closed body, minimum signal, CSRF, viewer denial, hidden incident, `201` first commit, `200` exact replay, divergent `client_txn_conflict`, response-row equality | critical | Transport admission movement must not change the wire. |
| `POST /api/v1/incidents/{incident_id}/views/cartulary.view.indicators.v1/query` | Workbook/Projections | Core 01 query and projection requirements; generic projection assembly | Indicator route integration, workbook query tests, browser shell tests | Default sort, filters, grouping, keyset cursor binding, terminal paging, auth loss, create/query row parity | critical | Production query uses generic Projections, not `Store.QueryRowsPage`. |
| `cartulary.view.indicators.v1` discovery and view-row shape | Core 01/view schema; source semantics Indicators | Authored view-schema contract and view-contract consumers | View-schema registry, view-contract, UI selector, Workbook surface tests | Exact 13 cells, technical fields, create-only writeability, no grid editing, inspector features, stable selector identity | high | No `view_schema_id` or field-key change is planned. |
| Saved views over the Indicator schema | Saved Views/Workbook | Core 01/03/04 saved-view contracts; browser saved-view scenario | Saved Views browser and Workbook controller tests | Saved query/layout continues to resolve the same base schema after query-path cleanup | high | Target owns neither persistence nor authorization. |
| Canonical create and dedupe | Indicators | Core 02 REQ-02-072 through REQ-02-074B | Canonical lifecycle/unit tests and IP tests | All indicator/value kinds, hash-pair rules, defanged/STIX non-identity, concurrent same-key create, idempotency/dedupe distinction | critical | Identity logic must have one implementation. |
| `indicator_find_or_create_participant_v1` | Indicators; Network Flow consumer | Core 02 REQ-02-074C; adopted Network Flow NLSpec | Participant rollback; Network Flow route/behavior tests | Created/reused result, canonical return, caller rollback, concurrent convergence, no observation/lifecycle/link/binding side effect | critical | Keep caller transaction and no independent audit/publication. |
| Indicator observation create/resolve | Indicators | Core 02 REQ-02-075 through REQ-02-078, REQ-02-260, origin registry | Three focused origin rows, Store/unit tests, Revisions child rollback, Incident Bundle round trip, and migration drift | `IND-ORIGIN-001` through `IND-ORIGIN-005` and `AC-ORIGIN-001` through `AC-ORIGIN-006` | critical | SL-06 is complete: six ordinary producer capabilities and owner-internal trusted system construction project the exact seven-token registry. |
| Indicator lifecycle append | Indicators | Core 02 REQ-02-079/080/260 | Canonical lifecycle/unit and Revisions child rollback tests | Append-only ordering/coherence, lifecycle/observation time separation, rollback tombstone, projection selection | high | No public target-specific route was found. |
| Projection refresh/query/rebuild | Indicators source provider; Projections storage/query | Core 01 REQ-01-342 through REQ-01-363 and REQ-01-621/622 | Route rebuild equality, workbook query, projection catalog/rebuild tests | Same-transaction refresh, query/load row equality, generic keyset paging, deterministic incident/restore rebuild | critical | Provider capability and authored manifest must stay aligned. |
| Record revisions and change sets | Revisions with Indicator source contribution | Core 02 history; Revisions appender and provider catalog | Indicator attribution test; Revisions integration and child rollback tests | Create/import/observation/lifecycle revision count and exact before/after rows | critical | Preserve actor, timestamp, source, client transaction, and request identity. |
| `record_changed` WebSocket semantics | Collaboration/Revisions | Core 01 REQ-01-267 and REQ-01-271A; Revisions appender | Revisions rollback event tests; no Indicator create assertion in focused owner tests | Exactly one create intent per record revision, canonical field keys/view, rollback behavior, no intent after transaction rollback | critical | Target has no direct WebSocket transport code. |
| Delete, restore, row rollback, observation rollback, interval rollback | Revisions routes; Indicators providers | Core 01 record routes; Core 02 REQ-02-260 | Revisions delete/restore, rollback, and indicator-child tests | Provider-catalog wiring, locks, row versions, tombstones, projections, ordinary events, exact replay | critical | Provider extraction must not change protected sets. |
| Indicator Imports facade | Imports coordinator; Indicators source facade | Import target/index contracts and owner registry | Imports characterization/registry and cross-owner tests | Create/dedupe, transaction rollback, projection/revision result, normalized errors | high | No CSV/XLSX parsing belongs in Indicators. |
| Incident Bundle three-file family | Incident Bundles coordinator; Indicators source port | Core 01 REQ-01-639/640 and source catalog | Dedicated characterization and invariant rows plus Incident Bundle and Revision atomicity evidence | `IND-PORT-001` through `IND-PORT-006` and `AC-PORT-001` through `AC-PORT-007` | critical | SL-02 owns identity semantics, SL-07 owns all ten strict invariants, and SL-08 separates portability claims from route integration. |
| Recovery ownership | Recovery coordinator; Indicators contribution | Recovery state catalog | Recovery catalog and restore rebuild tests | All three source tables restored, projection excluded and rebuilt | high | Projection is derived and must not enter authoritative recovery state. |
| Authorization and incident lifecycle | Auth/Workbook/Incidents | Core 04 incident roles; Workbook routes; root incident-open guard | Generic route scenario tests and Indicator route test | Membership re-derivation, editor minimum for create, member query, closed-incident mutation rejection, replay ordering | critical | Do not move route authorization into Indicator domain code. |
| Generated protocol/view contracts | Contract owners and generators | Authored view schema, OpenAPI source, generated-artifact policy | Generation drift, JSON shape, protocol/view-contract tests | Zero generated drift after any authored input change | high | Generated roots are never hand-edited. |
| Generic frontend/grid/selectors | Workbook, View Contracts, UI Contracts, grid adapter | View-contract and selector source; browser scenarios | View-contract tests, UI selector tests, Workbook unit/browser tests | Same shell selection, read-only existing rows, create draft, saved-view continuity, stable selectors | medium | No Indicator-specific frontend or vendor layer is proposed. |
| Harness/test accounting | Testing Harness and `module.indicators` owner | Owner verification contract and test-family manifest | Three mapped service-backed rows | Map newly added/moved owner tests without treating rows as runtime architecture | high | IP, paging, rollback, boundary, participant, and cross-owner tests currently rely on broader suites. |

### 4.1 Observation-origin implementation contract

The following requirements translate the existing Core 02 closed vocabulary into SL-06. The direction and implementation are authorized as an intentional implementation-conformance correction.

| Requirement ID | Requirement |
| --- | --- |
| `IND-ORIGIN-001` | `indicator_observation.origin_kind` MUST accept and persist exactly `manual_entry`, `clipboard_paste`, `csv_import`, `xlsx_import`, `api_import`, `extraction`, or `system`. It MUST reject every other value before mutation. |
| `IND-ORIGIN-002` | Every live producer MUST emit the token assigned by the producer mapping below. HTTP transport alone MUST NOT classify an operation as `api_import`. |
| `IND-ORIGIN-003` | Indicators MUST own one transport-neutral parser and semantic error. All ordinary create, import, extraction, rollback restoration, and portability preparation paths MUST use that parser. Transport owners MUST map the semantic error to their existing public error contracts. |
| `IND-ORIGIN-004` | Before rejection is enabled, the implementation task MUST complete and record the persisted-data preflight below. No runtime alias, repair-on-read, fallback, or permissive compatibility path is authorized. |
| `IND-ORIGIN-005` | Invalid origin input MUST fail before the first database write and MUST leave every owner and collaborator state named in the acceptance matrix unchanged. Exact valid tokens and provenance MUST survive history, rollback, and portability round trips. |

The exhaustive producer mapping is:

| Producer or action | Required token |
| --- | --- |
| Direct analyst entry through the workbook, inspector, or ordinary interactive API operation | `manual_entry` |
| Workbook clipboard paste | `clipboard_paste` |
| CSV file import | `csv_import` |
| XLSX file import | `xlsx_import` |
| Structured import submitted through an API import contract | `api_import` |
| Parser, extraction, or machine-assisted source-text extraction | `extraction` |
| Explicit trusted internal system-process operation | `system` |

An ordinary human-originated mutation transported over HTTP defaults to `manual_entry`. The `system` token has no caller-selectable default: it MUST require an explicit trusted system-operation context, and an ordinary caller MUST NOT self-classify as `system`.

The implementation boundary is conceptually equivalent to:

```go
type ObservationOrigin string

func ParseObservationOrigin(raw string) (ObservationOrigin, error)
```

The concrete name and file placement are intentionally unspecified. The behavior is not: comparison MUST be byte-exact and MUST NOT trim whitespace, fold case, expand aliases, accept extension prefixes, or substitute a default. A database constraint MAY mirror the seven-token set as defense in depth, but it MUST NOT be the sole validation boundary. The Indicator-owned error MUST contain semantic classification sufficient for existing adapters and MUST NOT import HTTP, job, or archive-transport types.

The persisted-data preflight MUST inspect current fixtures, migrations and seed data, retained supported Incident Bundles, upgrade fixtures, and authoritative `indicator_observation` rows in every supported deployment context. It MUST select exactly one outcome:

| Observed state | Required action | Authorization consequence |
| --- | --- | --- |
| No non-Core value exists. | Enable exact validation without data migration. | SL-06 may proceed. |
| Non-Core values exist only in disposable test fixtures. | Replace each fixture with the token for its actual producer. | SL-06 may proceed after fixture review. |
| Persisted `interactive_cell` rows have provable direct-user-entry provenance. | Use an explicit forward migration to `manual_entry` and record the migration evidence. | A separately scoped migration task is required before enablement. |
| Persisted provenance cannot be proven. | Do not guess or rewrite. Require operator remediation or quarantine/fail-closed handling. | A separately authorized remediation plan is required; SL-06 enablement remains blocked. |

#### IND-015 implementation preflight result

Outcome two applied: repository-controlled non-Core Indicator origins existed only in disposable tests. SL-00 changed direct-entry Indicator fixtures from `interactive_cell` to `manual_entry`; SL-06 changed the Incident Bundle extraction fixture from `auto_extract` to `extraction`. Uses of `interactive_cell` under Timeline and Entities are different source schemas and remain separate-owner follow-up.

No local persistent development deployment was running, and this repository task has no authority or credentials for external deployments. No data rewrite is authorized. The SL-06 migration therefore must fail closed when an upgrade database contains a non-Core value, leaving the operator to classify and remediate provenance before retrying. The read-only deployment query is:

```sql
SELECT origin_kind, count(*) AS row_count,
       min(created_at) AS first_seen_at, max(created_at) AS last_seen_at
  FROM indicator_observations
 WHERE origin_kind NOT IN (
       'manual_entry', 'clipboard_paste', 'csv_import', 'xlsx_import',
       'api_import', 'extraction', 'system'
 )
 GROUP BY origin_kind
 ORDER BY origin_kind;
```

An empty result permits the constraint migration. Any result blocks that migration; it must not be rewritten automatically.

Known `interactive_cell` fixtures in `indicators_test.go`, `unit_test.go`, and `resolution_integration_test.go` were changed to `manual_entry`; the correction preserves source binding, raw observed text or span, deterministic source location, and separate rows for repeated observations.

#### Observation-origin acceptance matrix

| Acceptance ID | Scenario | Required result |
| --- | --- | --- |
| `AC-ORIGIN-001` | Parse each of the seven exact tokens. | Each token is accepted unchanged; no eighth value is accepted. |
| `AC-ORIGIN-002` | Parse `interactive_cell`, an empty or missing required value, surrounding whitespace, `Manual_Entry`, an unknown value, and an extension-prefixed value. | Every case returns the typed Indicator semantic error before mutation. |
| `AC-ORIGIN-003` | Exercise each live producer class. | The stored token equals the producer mapping; ordinary HTTP analyst entry stores `manual_entry`. |
| `AC-ORIGIN-004` | Reject an origin at the latest reachable pre-write boundary. | Observation rows, source and Indicator versions, change sets, revisions, projections, collaboration intents, and idempotency-success state remain unchanged. |
| `AC-ORIGIN-005` | Preserve a valid token through history, rollback, and Incident Bundle export/import. | The exact token round trips without normalization or aliasing. |
| `AC-ORIGIN-006` | Submit repeated observations with identical origin, text, and normalized candidate but distinct stable identities. | The observations remain separate and retain independent provenance. |

SL-06 authorization recorded by the user for this tracker is:

> **SL-06 is authorized as an intentional implementation-conformance correction.** The Indicators owner shall accept and persist `indicator_observation.origin_kind` only as one of `manual_entry`, `clipboard_paste`, `csv_import`, `xlsx_import`, `api_import`, `extraction`, or `system`. `interactive_cell`, unknown tokens, aliases, case variants, and whitespace-normalized variants shall be rejected before mutation. Direct analyst-entry fixtures shall use `manual_entry`; fixtures representing another producer shall use that producer's exact Core token. No runtime compatibility alias, fallback token, or permissive read/write path is authorized. Any existing persisted non-Core value requires a separately reviewed data-remediation decision.

### 4.2 Indicator Incident Bundle owner-closure contract

| Requirement ID | Requirement |
| --- | --- |
| `IND-PORT-001` | Before SL-07, Core 01 MUST adopt exact portable row contracts and deterministic export ordering, and Core 04 MUST adopt complete binary acceptance criteria. |
| `IND-PORT-002` | Core 01 MUST adopt an exclusive rule for all ten declared invariants plus deterministic multi-defect precedence and tie-breaking before code emits a public exact `invariant_id`. |
| `IND-PORT-003` | After adoption, the Indicators port MUST keep Descriptor, Export, Prepare, Apply, and Validate responsibilities within the source-port boundaries defined below. |
| `IND-PORT-004` | After adoption, every semantic failure MUST select one deterministic exact invariant and map to the safe public error contract without leaking hostile or internal content. |
| `IND-PORT-005` | Apply, final-state validation, repair/rebuild coordination, publication, and terminal success MUST remain atomic in the Incident Bundles coordinator's final transaction. |
| `IND-PORT-006` | SL-07 completion MUST provide every acceptance case in `AC-PORT-001` through `AC-PORT-007` and current authored harness accounting. |

The Indicators descriptor declares the following ten Core 01 invariant IDs. SL-02 now proves the first three during prepared-input admission; SL-07 must complete the remaining rules and deterministic multi-defect selection:

1. `indicators.representation_legal`
2. `indicators.normalization_exact`
3. `indicators.identity_unique`
4. `indicators.observation_same_incident`
5. `indicators.observation_ordered`
6. `indicators.observation_coherent`
7. `indicators.interval_same_incident`
8. `indicators.interval_ordered`
9. `indicators.interval_coherent`
10. `indicators.repeated_observations_preserved`

IND-016 adopted the exact members, types, required presence, nullability, bounds, canonical UTC `+00:00` forms, stable-identity ordering, exclusive ten-invariant partition, deterministic failure selection, and Prepare-versus-Validate allocation in Core 01 REQ-01-640. Core 04 AC-530 and AC-531 own binary provenance and portability acceptance. Authored schemas, source-catalog IDs, traceability, verification ownership, and generated topology now project those owners.

SL-00 characterized the current exporter surface before adoption. Core 01 preserves its UTC `+00:00` timestamp compatibility and adopts ascending Indicator `record_id`, observation ID, and interval ID ordering. `SELECT *`, physical relation order, `to_jsonb(table_row)`, database record-population functions, and illustrative DDL are explicitly non-authoritative.

#### Adopted Core 01 invariant partition

Core 01 REQ-01-640 is authoritative; this table is a concise implementation index.

| Precedence | Invariant | Exclusive rule proposed for adoption | Minimum negative fixture |
| ---: | --- | --- | --- |
| 1 | `indicators.representation_legal` | Indicator rows have the exact admitted shape and types; incident identity matches the import context; type, value kind, display, normalized value, hash pair, defanged/STIX value, and dedupe-basis fields form a legal Core 02 representation. IP family/value-kind and hash-pair rules belong here. | `ipv4_addr` with non-`atomic`; a half-populated hash pair; unknown indicator type. |
| 2 | `indicators.normalization_exact` | Imported canonical display, normalized value, hash value, and stored or recomputed dedupe basis already equal the owner canonicalization result. Import rejects rather than repairs noncanonical values. | Noncanonical IPv6 text; normalized value differs from the owner result; dedupe key differs from recomputation. |
| 3 | `indicators.identity_unique` | Active imported Indicator identities are unique under the incident-scoped, type-specific dedupe key. Apply does not silently reuse, merge, or ignore a duplicate. | Two different Indicator record IDs recompute to the same active canonical identity. |
| 4 | `indicators.observation_same_incident` | Every observation, source record, optional resolved Indicator, and incident-scoped reference belongs to the import incident. A non-record extension resource is not a source record. | Foreign-incident source record or resolved Indicator. |
| 5 | `indicators.observation_ordered` | Creation, resolution, deletion/tombstone, and row-version values obey the adopted chronology; export order is stable observation identity ascending. | Resolution before creation, deletion before creation/resolution, or nonpositive row version. |
| 6 | `indicators.observation_coherent` | Source field, exact origin, locator, raw text/span, parse result, resolution metadata, attribution, and tombstone members form one legal tuple. | `interactive_cell`; resolved observation without target or attribution; half-populated tombstone tuple. |
| 7 | `indicators.interval_same_incident` | Every interval, Indicator, and supporting record belongs to the required incident and resolves exactly once. | Foreign-incident Indicator or support. |
| 8 | `indicators.interval_ordered` | `valid_to` is null or not earlier than `valid_from`; deletion is not earlier than creation; export order is stable interval identity ascending. | `valid_to < valid_from`, deletion before creation, or nonpositive row version. |
| 9 | `indicators.interval_coherent` | State, confidence, rationale, support, assessor timestamps, attribution, and tombstone members form a legal append-only tuple. Observation time is not substituted for lifecycle-validity time. | Out-of-bounds confidence, invalid state, invalid support, or half-populated tombstone tuple. |
| 10 | `indicators.repeated_observations_preserved` | Final transaction state contains exactly one row per admitted stable observation identity. Distinct IDs remain distinct regardless of identical content, source, origin, or resolved Indicator; required active and tombstoned rows remain present. | Two identical-content observations with distinct IDs; fail if either is coalesced, omitted, or overwritten. |

The adopted deterministic failure rule selects the lowest precedence number among all defects. Within that invariant, it orders by logical file path, then valid stable owner identity ascending, then—only when stable identity is missing or invalid—an internal SHA-256 digest of the bounded raw logical row. The digest never appears in public errors, logs, telemetry, readiness, administrative summaries, or operator output.

#### Adopted source-port interface allocation

Core 01 REQ-01-639 and REQ-01-640 make this allocation binding.

| Operation | Indicators responsibility |
| --- | --- |
| `Descriptor` | Declare the three paths, family ID, dependency, owner relations, contract major, stable identities, and all ten invariant IDs. |
| `Export` | Read only Indicator-owned source state and emit deterministic canonical files. |
| `PrepareImport` | Strictly decode the adopted row shapes, enforce bounds, verify canonical input and row-local invariants, and return an opaque prepared value without mutation. |
| `ApplyImportTx` | Use fixed owner-controlled SQL or SQLC in the supplied transaction and require exact affected-row counts. |
| `ValidateImportTx` | Compare admitted input with final transaction state and prove aggregate, cross-row, and cross-family invariants before publication. |

The authorized implementation uses an unexported prepared-Indicators type, one closed Indicator bundle-invariant type representing exactly the ten IDs, and a typed invariant-error constructor fixed to family `indicators`. It reuses the Indicator identity component from SL-02 and narrow Records/actor lookup capabilities. It MUST NOT contain authorization, HTTP mapping, projection publication, job coordination, generic metadata-derived SQL, independent commits, generic conflict-ignore behavior, or prepared-value reuse across ports. Neither Prepare nor Validate repairs, skips, merges, defaults, or canonicalizes input.

An Indicator invariant failure must map through Incident Bundles to exactly:

```text
error.code = incident_bundle_import_rejected
reason_code = source_family_invalid
retryable = false
source_family_id = indicators
invariant_id = <one exact adopted Indicator invariant>
```

The public error, logs, telemetry, and job summary MUST NOT disclose imported values, raw NDJSON, SQL or database errors, relation or column names, object keys or staging paths, actor/provider identifiers, credentials, or cryptographic material. The port MUST classify semantic defects explicitly and MUST NOT parse database error text or map every database failure to `indicators.representation_legal`.

All source Apply operations, all Validate operations, revision repair, attribution flush, projection rebuild, imported-incident administration, audit, publication, and terminal success MUST share the coordinator's final database transaction. Only its commit may expose the incident or final object references. SL-07 does not authorize a new bundle version, source contract major, route, public error code, compatibility importer, Indicator-specific job, or Indicator-specific transaction coordinator.

#### Portability acceptance matrix

| Acceptance ID | Scenario | Required result |
| --- | --- | --- |
| `AC-PORT-001` | One valid-JSON fixture violates exactly one proposed invariant. | Each of the ten fixtures returns family `indicators`, the exact adopted invariant ID, `retryable=false`, and no visible state. |
| `AC-PORT-002` | At least three fixtures violate multiple invariants; input row order varies. | The adopted precedence and tie-break choose the same exact invariant ID. |
| `AC-PORT-003` | Export valid v2, import into an empty target, and re-export. | All three files are authoritatively equivalent under the adopted row and order contract. |
| `AC-PORT-004` | Import a retained valid v1 bundle and export v2. | Supported v1 semantics are preserved; no new version or source major is required. |
| `AC-PORT-005` | Import repeated identical-content observations with distinct IDs and active/tombstoned observation and interval history. | Distinct provenance and tombstones survive; active reads and projections exclude tombstones as owned; re-export preserves history. |
| `AC-PORT-006` | Inject failure after Indicator Apply, during Indicator Validate, and after validation but before commit. | No incident, membership, workbook preference, audit success, projection, final object reference, idempotency success, or terminal-success result becomes visible. |
| `AC-PORT-007` | Supply hostile values, SQL-like text, paths, and secrets. | Public errors, logs, telemetry, and job summaries contain none of the forbidden content. |

### 4.3 Requirement traceability

| Requirement | Authoritative or required owner | Slice | Acceptance evidence | Entry gate | Current status |
| --- | --- | --- | --- | --- | --- |
| `IND-ORIGIN-001` through `IND-ORIGIN-003` | Adopted Core 02; authorized SL-06 translation | SL-02, SL-06 | `AC-ORIGIN-001` through `AC-ORIGIN-003` | Exact parser, opaque producer capability, three focused origin rows, and cross-owner producer fixtures | DONE |
| `IND-ORIGIN-004` | Deployment/data-remediation authority | SL-06 | Recorded preflight outcome and fail-closed upgrade query | Preflight completed before enablement | DONE — outcome two |
| `IND-ORIGIN-005` | Adopted Core 01/Core 02 transaction and history owners | SL-06 | `AC-ORIGIN-004` through `AC-ORIGIN-006` | Pre-transaction validation, migration 00055, rollback/portable revalidation, repeated-observation evidence | DONE |
| `IND-PORT-001` | Core 01 REQ-01-639/640 and Core 04 AC-531 | Owner-document task before SL-07 | Exact schemas, row ordering, and binary criteria | Owner changes adopted | DONE |
| `IND-PORT-002` | Core 01 REQ-01-640 | Owner-document task before SL-07 | `AC-PORT-001`, `AC-PORT-002` | Exclusive partition and precedence adopted | DONE |
| `IND-PORT-003` | Core 01 REQ-01-639/640 source-port allocation | SL-05, SL-07 | Port boundary tests and `AC-PORT-003` through `AC-PORT-005` | Internal provider plus typed prepared model | DONE |
| `IND-PORT-004` | Core 01 error owner and Core 04 AC-531 | SL-07 | `AC-PORT-001`, `AC-PORT-002`, `AC-PORT-007` | Closed rank and deterministic candidate selection | DONE |
| `IND-PORT-005` | Core 01 REQ-01-641 transaction/publication owner | SL-07 | `AC-PORT-006` | Caller-owned apply/validate transaction and coordinator atomicity rows | DONE |
| `IND-PORT-006` | Testing Harness evidence routing only | SL-08 | Focused rows, retained run roots, generated drift gates | Product requirements implemented | DONE |

## 5. Coupling and Boundary Findings

| Finding | Evidence | Risk | Classification | Proposed owner | Required planning action |
| --- | --- | --- | --- | --- | --- |
| Indicators is a valid permanent source-owner boundary. | Core 01 required modules; Core 02 Indicator and observation requirements; schema ownership manifest. | low | `intentional/no_action` | Indicators | Retain the module and refactor within its adopted responsibility. |
| The root `Store` mixed transaction/idempotency coordination, source persistence, revision append, identity rules, and projection mutation. | SL-03 repositories and SL-04 projection port. | critical | `resolved` | Indicators façade plus source repositories; Projections coordination port | Store now coordinates workflows only; repositories own fixed caller-transaction SQL. |
| HTTP and view-schema decoding leaked into the Indicator root. | SL-01 Workbook admission adapter and Indicator semantic command. | high | `resolved` | Workbook adapter with Indicator semantic command | Workbook exclusively owns decoding/error/hash adaptation; Indicator production imports are guarded. |
| Target-local query duplicated the assembled generic production query. | SL-04 deletion plus generic keyset/query evidence. | high | `resolved` | Projections query service with Indicator descriptor | The unused local API is removed without a compatibility wrapper. |
| Root source mutations directly wrote Projections-owned storage. | SL-04 required port, provider row refresh, and SQL boundary. | critical | `resolved` | Indicators projection source/provider behind Projections port | Transactional refresh/load delegates to Projections; only the provider owns derivation SQL. |
| Live create and rollback duplicated Indicator validation/dedupe behavior. | SL-02 owner-internal identity service and parity/concurrency rows. | critical | `resolved` | Indicators internal identity component | All five consumers delegate to one pure semantic implementation. |
| Portability declared ten invariants but lacked seven complete implementations plus deterministic multi-defect selection. | Core 01 REQ-01-640; source catalog; `IND-PORT-001` through `IND-PORT-006`. | critical | `resolved` | Indicators source port | SL-07 now proves all `AC-PORT-001` through `AC-PORT-007` without repair behavior. |
| Indicator tests persisted `interactive_cell`, outside the closed origin vocabulary. | SL-06 corrected fixtures plus Core 02 §18 exact token registry evidence. | high | `resolved` | Indicators observation owner | Ordinary producers use exact capabilities, invalid aliases are negative fixtures only, portable and rollback reads revalidate, and migration 00055 enforces the same seven-token registry. |
| Focused Indicator evidence originally covered only three service-backed tests. | SL-08 verification contract, fourteen explicit rows, and generated topology. | high | `resolved` | Testing Harness authored owner inputs | Characterization, identity parity/concurrency, origin, projection, boundaries, atomicity, routes, and portability are independently attributable. |
| The generic frontend infers Indicator timestamp filters from raw field keys. | `apps/web/src/workbook/models/workbookQuery.ts`. | medium | `defer` | Workbook/View Contracts | Future metadata-driven cleanup; do not create backend-to-frontend coupling in this refactor. |
| Reference Pack draft suggests a possible future normalization registry. | Draft NLSpec only; current Core assigns canonical identity to Indicators. | medium | `defer` | Indicators until an adopted owner changes it | Do not move normalization based on draft material. |
| No direct saved-view, object-store, grid-vendor, or WebSocket transport implementation exists in the target. | Target import/source scan and live caller inspection. | low | `intentional/no_action` | Existing Saved Views, platform, grid adapter, Collaboration/Revisions owners | Freeze the affected contracts; add no Indicator-specific substitute. |
| Generic projection composition is exposed through historically Timeline-named runtime state. | `server/runtime.go` and Indicator rebuild integration path. | medium | `defer` | Application/projection assembly | Treat as composition naming debt, not evidence that Timeline owns Indicators. |
| Existing boundary guard did not prove the transport/projection/provider seams. | SL-01, SL-04, and SL-05 guards plus the final boundary run. | medium | `resolved` | Indicators and backend boundary policy | Production import and SQL scans now enforce every introduced seam. |

## 6. Refactor Workstreams

| Workflow ID | Name | Class: root/chain/parallel | Required previous workflows | Required subsequent workflows | Goal | Files likely involved | Validation | Handoff checkpoint |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| WF-00 | Session/source bootstrap and tracker initialization | root | none | WF-01, WF-02, WF-04 | Fix the repository baseline, authority order, allowed write, and handoff state. | This tracker only. | `make lint-markdown` for the planning artifact. | Baseline and source posture recorded; planning task makes no implementation change. |
| WF-01 | Target inventory | chain | WF-00 | WF-02, WF-03, WF-04 | Account for every target file, caller, dependency, and test surface. | `internal/modules/indicators/**` plus live callers. | Re-run file count/search before implementation. | All 50 final files have one Section 2 row. |
| WF-02 | Contract-owner mapping | parallel | WF-01 | WF-03, WF-05 | Bind each affected behavior to its adopted owner and current contract projection; route `IND-PORT-001` and `IND-PORT-002` to Core 01/Core 04 rather than this tracker. | Core/adopted specs, view/import/projection/portability/recovery contracts. | `make generate-drift`; `make json-shape-check` when implementation changes authored inputs. | Every contract in Section 4 has an owner and test posture; missing portability authority remains an explicit owner gate. |
| WF-03 | Characterization test gap analysis | parallel | WF-01, WF-02 | WF-05, WF-06 | Distinguish conformant baseline behavior from current owner mismatches and missing evidence. | Indicator tests, Workbook scenarios, Revisions and Network Flow tests, harness owner inputs. | Focused service-backed rows and later added characterization rows. | SL-00 covers the freeze map without blessing `interactive_cell` or the proposed portability partition as current behavior. |
| WF-04 | Boundary/coupling scan | parallel | WF-01 | WF-05 | Locate transport, persistence, projection, frontend, generated, and harness coupling. | Indicator root, provider subpackages, assemblies, boundary manifests, generic frontend consumers. | `make backend-module-boundary-check`; conditional frontend boundary check. | Findings classified exactly as Section 5. |
| WF-05 | Facade and ownership redesign plan | chain | WF-02, WF-03, WF-04 | WF-06 | Define a stable Indicator facade, internal identity/source seams, and owner contribution boundaries. | Indicators root/internal packages, Workbook contribution, projection assembly. | Focused owner rows plus boundary checks. | No public route/view/participant change and no undecided ownership remains. |
| WF-06 | Slice sequencing plan | chain | WF-05 | WF-07, WF-08 | Order the smallest reversible slices, isolate behavior corrections, and enforce the preflight and owner-adoption gates for SL-06 and SL-07. | Packages named in Section 7. | Per-slice commands in Section 7. | Every slice has dependency, rollback, binary completion criteria, and an authorization posture. |
| WF-07 | Harness/test/accounting update plan | parallel | WF-06 | WF-08 | Keep owner evidence aligned when tests or package seams move. | Authored verification/test-family inputs and affected tests. | `make agent-finalize`, generation/policy checks, focused owner slice. | All new/moved tests are accounted for without using the harness as architecture. |
| WF-08 | Validation and final handoff | chain | WF-06, WF-07 | none | Run narrow-to-broad verification, record artifacts/failures, and hand off only a slice whose entry gates are satisfied. | Tracker plus implementation files authorized in the later task. | Section 8 sequence. | Clean scoped diff, completed checks recorded, `IND-ORIGIN-*` and `IND-PORT-*` evidence traceable, remaining blockers explicit. |

WF-00 through WF-08 and every authorized implementation slice are complete. No dependent workstream remains open.

## 7. Proposed Refactor Slice Plan

| Slice ID | Depends on | Intended change | Files/packages likely involved | Contract risks | Tests to add or preserve | Validation command | Rollback note | Completion criterion |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| SL-00 | none | Add owner-mapped baseline characterization for create/replay/conflict/auth, collaboration intent, import, participant rollback, projection query/rebuild parity, portability, and rollback. Do not characterize `interactive_cell` or the proposed portability partition as current valid behavior. | Indicator tests; Workbook scenario tests; Revisions/Network Flow collaborator tests; authored test-family inputs. | Tests could accidentally bless current owner drift or assert implementation-private SQL. | Preserve all current focused tests; add public/facade assertions and one create `record_changed` assertion. | `make service-backed-test-slice OWNER=module.indicators`; `make test-fast` | Revert the characterization commit; no production state is involved. | Required conformant behavior fails before intentional regressions, owner gaps remain explicit, and all added rows are owner-accounted. |
| SL-01 | SL-00 | **DONE:** Workbook owns exact Indicator JSON/view-schema admission and legacy replay hashing, validates the Indicator-owned semantic command before owner execution, and maps owner errors to the frozen wire contract. | Indicator `api.go`/Store/import/participant callers; Workbook Indicator admission and create contribution; focused tests and owner accounting. | Request shape, error details, normalized request hash, replay status, and row envelope. | Exact legacy hash bytes and member-order equivalence; pre-owner malformed rejection; Indicator route/replay/query and Workbook create/route coverage. | Focused Workbook unit row, six Indicator service rows, five selected Workbook service units, boundary, 62 browser units, 346 fast units, and drift/policy/shape gates pass at Section 10 run roots. | Revert the adapter checkpoint as one unit; no compatibility wrapper remains in Indicators. | Met: Indicator admission/API imports no HTTP or view-schema adapters, the command is semantic rather than field-key shaped, and all frozen public behavior passes. |
| SL-02 | SL-00 | **DONE:** centralize canonicalization, type/value/hash validation, observation candidates, and dedupe in one Indicator-internal component used by live create, import, Network Flow, portability validation, and rollback. | Indicator root/internal identity package; rollback provider; source-port preparation; focused identity tests. | Canonical values, historical rollback acceptance, duplicate identity, IP exactness, concurrent reuse. | All IP and registry cases; portable normalization/identity rejection; existing import, participant, rollback, and concurrent service behavior. | Focused identity row, all six Indicator service-backed units, boundary check, `make test-fast`, and generation drift all pass at the run roots recorded in Section 10. | Revert the identity-component checkpoint; no schema migration was added. | Met: one pure semantic implementation remains; all five consumers delegate to it and retain characterized behavior. |
| SL-03 | SL-01, SL-02 | **DONE:** retain the `Store` façade while separating transaction/idempotency/revision coordination from fixed Indicator, observation, and lifecycle repositories. | Indicator Store/facade, owner source repositories, and application construction. | Transaction boundaries, lock order, idempotency, revisions, incident-open checks, partial commits. | Fault-boundary rollback, exact replay, observation resolution, lifecycle append, and collaboration intent counts. | Focused structure/transaction rows, full Indicator service slice, boundary, fast, and drift gates pass at Section 10 roots. | Revert the façade/repository checkpoint as one unit. | Met: Store remains the workflow façade, repository methods never own commits, and focused/broad tests pass. |
| SL-04 | SL-00, SL-03 | **DONE:** route row refresh/load through the injected Projections coordinator, advertise row refresh, and remove the local query path after generic keyset coverage. | Indicator projection provider; Projections/provider assembly; Indicator façade; authored provider contract. | Same-transaction projection refresh, query sorting/filtering/cursors, row shape, rebuild parity, restore ordering. | Generic keyset, delegation, query/load parity, incident rebuild, and restore rebuild tests. | Indicator/Projections/Workbook slices, boundary, generation, drift, shape, and fast gates pass at Section 10 roots. | Revert the projection/query checkpoint with its authored/generated inputs. | Met: no production caller relies on target-local query code; provider/catalog drift is zero. |
| SL-05 | SL-02, SL-03 | **DONE:** expose only root projection, revision, and Incident Bundle contributions; move projection, portability, rollback, and delete/restore implementation leaves under `internal/providers`; strengthen import and SQL boundaries. | Indicator contribution/provider packages; projection/revision/portability assemblies; Projections neutral source interface; backend and provider-manifest inputs. | Provider catalog completeness, delete/restore, child rollback, projection source injection, and bundle ordering. | Revisions delete/restore and child rollback; Projection and Incident Bundle catalogs; contribution completeness and forbidden-import guard. | Indicator unit/service, focused Projection/Revision/Incident Bundle rows, boundary, fast, generation, drift, policy, and shape gates pass at Section 10 roots. | Revert the provider-encapsulation checkpoint and matching authored/generated inputs together. | Met: assemblies import only root contributions; generic coordinators cannot import Indicator implementation leaves; provider IDs and runtime registrations are stable. |
| SL-06 | SL-00, SL-02, IND-015; authorization recorded in Section 4.1 | **DONE:** exact owner registry and producer capabilities reject non-Core origins before transaction start; rollback and portability revalidate stored input; corrected fixtures identify their real producer; reversible migration 00055 applies the same seven-token check. | Indicator-owned origin boundary; observation repository; rollback/portability providers; Indicator, Revisions, and Incident Bundle fixtures/tests; migration and harness inputs. | Accepted behavior changes for invalid callers; upgrade databases with unclassified provenance fail closed by design. | `AC-ORIGIN-001` through `AC-ORIGIN-006`; preserve source binding, raw text/location, history, and repeated provenance. | Focused origin rows; affected owner service slices; `make migration-drift`; boundary, fast, generation, policy, and shape checks | Revert the complete behavior-correction commit and use migration 00055 Down to remove only the check; do not introduce a compatibility alias or data rewrite. | Complete: exact acceptance/rejection and producer mapping pass; `system` has no ordinary constructor; valid history/portable paths preserve tokens; affected owner slices and required gates pass. |
| SL-07 | SL-00, SL-02, SL-05, IND-016 | **DONE:** exact source-major-1 export, strict typed preparation, fixed-column apply, and final-state validation enforce `IND-PORT-003` through `IND-PORT-006` before publication. | Owner-internal Indicator portability provider, Incident Bundle fixture, boundary/test-family inputs, generated topology. | Valid v1/v2 remains supported; malformed or inconsistent archives now fail with one closed deterministic invariant. | All ten invariants, three multi-defect permutations, strict malformed forms, context binding, envelope/attribution equality, repeated observations, hostile-value redaction, valid round trips, and coordinator atomicity. | Focused Indicator rows; full Indicator and Incident Bundle slices; focused Revision portability; boundary, lint, fast, generation drift, artifact policy, and JSON shape checks. | Revert the SL-07 checkpoint as one unit; no migration, fallback importer, repair, skip, merge, or warning-only path exists. | Complete: exact safe failures are deterministic, final transaction state is revalidated, valid v1/v2 imports pass, and all focused/broad/drift gates are green. |
| SL-08 | SL-01 through SL-07 | **DONE:** verification ownership separately accounts for characterization, identity parity/concurrency, route integration, origin, projection delegation, provider boundaries, transaction atomicity, and portability; final narrow-to-broad validation and handoff are complete. | Indicator verification contract/test family, one dedicated concurrency test, Make-generated topology, and this tracker. | Missing accounting or a broad suite masking an uncovered claim. | Fourteen focused rows, including two-transaction find-or-create convergence; route integration has no portability verification ID. | Affected owner unit/service slices; boundary, migration, generation, policy, shape, Markdown, fast, finalize, and full check roots below. | Revert the SL-08 checkpoint as one unit; it changes no public contract or migration and the prior implementation slices remain independently revertible. | Complete: generated drift is zero, all 708 `make check` units pass, retained-run maintenance is explicitly skipped because `RESULTS_DIR` was unset, and no finding remains unclassified. |

Every slice MUST be one reviewable, revertible commit unless an authorized data migration requires its own commit and rollback path. Public contracts named in Section 4 MUST remain unchanged unless the active remediation plan explicitly corrects them. A slice that exposes an unlisted product behavior change MUST stop and be reclassified `requires later authorization` before implementation.

## 8. Validation Plan

The commands below were discovered from the live Make task surface and `make task-guide ROLE=module-author OWNER=module.indicators`. The implementation baseline in Section 1 records the product validation already executed for this authorized run.

| Validation layer | Command | Scope | Required before implementation? | Notes |
| --- | --- | --- | --- | --- |
| unit | `make service-backed-test-slice OWNER=module.indicators ROWS=module.indicators.store.indicator_storage_keeps_source_bound_observation_07c064324e,module.indicators.store.indicators_persist_as_canonical_indicator_record_3998750e91` | Two mapped Indicator store rows using Postgres fixtures. | yes | Despite `_Unit` test names, the harness classifies them as service-backed integration evidence. |
| integration | `make service-backed-test-slice OWNER=module.indicators ROWS=module.indicators.integration.indicator_create_and_query_routes_persist_canoni_e3a29b7aaf` | Real Indicator HTTP create/query and projection rebuild row. | yes | Run the whole owner with `make service-backed-test-slice OWNER=module.indicators` after each cross-cutting slice. |
| e2e/browser | `make browser-e2e-webserver-backed` | Generic workbook system-view selection, Indicator create/query, saved-view continuity, and keyboard/grid anchors. | no | Required after Workbook/public wiring changes, not for an isolated backend-only move. |
| generated drift | `make generate-drift && make generated-artifact-policy-check && make json-shape-check` | Generated view/protocol artifacts, policy, and authored JSON contracts/manifests. | yes | Run before to establish baseline and after any authored contract/harness input change. Never hand-edit generated roots. |
| import-boundary/static | `make backend-module-boundary-check` | Backend module import/SQL boundary policy. | yes | Add `make frontend-import-boundary-check` only if a later authorized slice changes frontend ownership files. |
| full check | `make agent-finalize` followed by `make check` | Harness maintenance and full developer verification gate. | no | Run at final implementation handoff; use `make test-fast` as the intermediate broad loop. |
| documentation | `make lint-markdown` | Authored Markdown, including this tracker. | yes | The only executable validation required for this planning-only change. |

## 9. Top-Level Work Tracker

| ID | Work item | Workstream | Status | Depends on | Evidence or artifact | Exit condition |
| --- | --- | --- | --- | --- | --- | --- |
| IND-001 | Establish source posture and repository baseline | WF-00 | DONE | none | Section 1; branch/commit/time and authority list | Baseline and one-file write scope are explicit. |
| IND-002 | Inventory all target files and live callers | WF-01 | DONE | IND-001 | Section 2 with 50 rows | Every final target file is accounted for. |
| IND-003 | Map public contracts and owner boundaries | WF-02 | DONE | IND-002 | Sections 3 and 4 | Every discovered contract has an owner and test posture. |
| IND-004 | Identify characterization gaps without blessing owner drift | WF-03 | DONE | IND-003 | SL-00 and Sections 4/5 | Required baseline tests and invalid fixtures are distinguished. |
| IND-005 | Classify coupling and target owners | WF-04 | DONE | IND-002 | Section 5 | Each finding has one allowed classification and planning action. |
| IND-006 | Define the facade/repository and transport seams | WF-05 | DONE | IND-004, IND-005 | SL-01 through SL-03; typed Store dependencies; caller-transaction repositories; shared server owner | Store remains the workflow facade, fixed source persistence is isolated, and Workbook/Imports consume the constructed owner without wire drift. |
| IND-007 | Consolidate projection/query ownership | WF-05 | DONE | IND-004, IND-006 | SL-04; required projection port; provider refresh capability; generic keyset/query coverage; projection-table boundary rule | Generic query and provider refresh/load are the only production paths, and mutation/rebuild/query parity coverage passes. |
| IND-008 | Encapsulate source-owner provider contributions | WF-05 | DONE | IND-006 | SL-05; root contribution façades, Go-internal implementation leaves, neutral Projection source, boundary guard | Catalogs and boundary guards pass with narrower exported surfaces. |
| IND-009 | Correct observation origin vocabulary | WF-06 | DONE | IND-004, IND-015, SL-02 | SL-06; closed origin registry; opaque producer capability; migration 00055; exact focused rows and affected-owner evidence | Exact Core 02 tokens are enforced before mutation and at storage, public adapters remain compatible, history/portable paths revalidate, and all acceptance cases pass. |
| IND-010 | Close all declared portability invariants | WF-06 | DONE | IND-008 and SL-05; IND-016 is complete | SL-07; typed portable model; strict prepare/apply/validate; two focused rows; `AC-PORT-*` | All ten invariants, deterministic safe failure, retained v1/v2 behavior, and final-transaction atomicity pass. |
| IND-011 | Replace frontend raw Indicator timestamp inference with metadata | WF-04 | DEFERRED | Later Workbook/View Contracts owner task | Section 5 finding | Adopted frontend owner chooses and verifies a metadata-driven design. |
| IND-012 | Move normalization to a shared Reference Data registry | WF-04 | DEFERRED | Later adopted owner specification | Draft Reference Pack NLSpec evidence | An adopted owner explicitly changes current Core ownership. |
| IND-013 | Update harness accounting for new/moved tests | WF-07 | DONE | IND-006 through IND-010 | Ten explicit verification claims, fourteen focused rows, and Make-generated topology | Focused owner routing covers every required claim, route integration is distinct from portability, and generation drift is clean. |
| IND-014 | Run final validation and append implementation handoff | WF-08 | DONE | IND-007, IND-008, IND-013 | Section 10 final session rows and run roots | All required focused/policy/broad/final checks pass and the remaining owner handoffs are explicit. |
| IND-015 | Complete SL-06 persisted-data preflight | WF-06 | DONE | SL-00 fixture characterization and deployment availability inspection | `IND-ORIGIN-004`; Section 4.1 outcome two and fail-closed deployment query | Repository violations are disposable fixtures; no data rewrite is authorized; upgrades with unknown invalid rows fail closed. |
| IND-016 | Adopt the Indicator portability owner closure | WF-02 | DONE | SL-00 characterization | Core 01 REQ-01-640, Core 04 AC-530/531, three row schemas, source catalog, traceability, verification ownership, generated topology | Exact rows/order, exclusive invariants, deterministic precedence, phase allocation, and binary acceptance criteria are adopted. |
| IND-017 | Bootstrap the authorized implementation ledger | WF-00 | DONE | User implementation authorization | Section 1 active execution protocol and baseline run roots | Authorization, starting state, sequence, checkpoint rule, and baseline evidence are explicit. |
| IND-018 | Complete SL-00 characterization and owner accounting | WF-03 | DONE | IND-017 | Two new focused rows, corrected test origins, generated topology, and recorded run roots | Identity and valid portability surfaces are executable regression locks; focused, broad, and drift gates pass. |
| IND-019 | Complete SL-02 canonical identity consolidation | WF-05 | DONE | IND-018 | Owner-internal identity service, five delegated consumer paths, portable identity evidence, generated topology, and recorded run roots | Live create/import/Network Flow, rollback, observation candidates, and portability use one pure semantic implementation; focused, service-backed, boundary, broad, and drift gates pass. |
| IND-020 | Complete SL-01 transport-neutral Indicator admission | WF-05 | DONE | IND-018, IND-019 | Semantic `CreateCommand`, Workbook-owned decoder/hash adapter, admission/boundary evidence, generated topology, and recorded run roots | Indicator no longer exposes transport decoder/hash APIs; malformed input fails before owner execution; route, replay, browser, broad, and drift gates pass. |
| IND-021 | Complete SL-03 façade and repository extraction | WF-05 | DONE | IND-019, IND-020 | `StoreDependencies`; source/observation/lifecycle repositories; shared application owner; composition and transaction rows; SQL boundary update | Repository methods remain caller-transaction scoped, incomplete composition fails, Imports consumes the constructed façade, rollback evidence passes, and the direct projection dependency is isolated for SL-04. |
| IND-022 | Complete SL-04 projection and query consolidation | WF-05 | DONE | IND-021 | Required `ProjectionPort`; provider `refresh_row=true`; shared refresh/rebuild derivation; generic mutation loads and Indicator keyset coverage; deleted local query | No production Indicator code outside the source provider/query descriptor references projection storage; focused owner, Workbook, boundary, broad, and drift gates pass. |
| IND-023 | Complete SL-05 provider encapsulation | WF-05 | DONE | IND-019, IND-021, IND-022 | `NewProjectionContribution`, `NewRevisionContribution`, `NewIncidentBundleContribution`; `internal/providers`; neutral Projection source interface; provider import guard | Projections, Revisions, and Incident Bundles coordinate only generic contracts; provider catalogs, rollback, boundary, broad, and drift evidence pass. |
| IND-024 | Complete SL-06 exact observation provenance | WF-06 | DONE | IND-009, IND-015, IND-019, IND-023 | Closed origin registry and six ordinary producer capabilities; no public system capability; migration 00055; corrected Indicator/Revision/Incident Bundle fixtures; three focused origin rows | Invalid aliases fail before transaction start, the database accepts only seven exact tokens, stored `system` remains readable/importable, and migration/owner/broad/drift evidence passes. |
| IND-025 | Complete SL-07 strict schema-bound portability | WF-06 | DONE | IND-010, IND-016, IND-019, IND-023 | Explicit exporters; typed bounded preparation; fixed-column apply; final-state validation; two focused portability rows; boundary and generated topology updates | Physical schema no longer defines portable bytes; valid v1/v2 archives pass; malformed and inconsistent archives fail atomically with one safe deterministic invariant. |
| IND-026 | Complete SL-08 verification and handoff | WF-07, WF-08 | DONE | IND-013, IND-014, IND-025 | Explicit verification ownership, concurrency evidence, generated topology, owner slices, repository-wide gates, and final tracker rows | No unclassified finding, stale generated artifact, failed required check, or unnamed residual owner work remains. |

## 10. Session Handoff Log

### Scope and authority

| Time | Agent/session | Current state | Files inspected or touched | Commands run | Result | Blockers | Next action |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 2026-08-03T08:32:42-04:00 | Codex / tracker-authoring session | Authority and planning-only scope fixed at the requested repository baseline. | Inspected planning framework, domain, Core 00-04, adopted NLSpecs, and live repository; touched only this tracker. | Read-only `sed`, `rg`, `find`, `jq`, and Git inspection; `make task-guide`; `make help`; `make help-all`; `make lint-markdown`. | No owner contradiction; Core 05 not applicable; tracker Markdown validation passed. An initial `sed` used a misnamed Core 01 path, failed without mutation, and was corrected to `01_architecture_storage_and_view_contracts.md`. | None for planning. | Begin SL-00 only in a later authorized implementation task. |
| 2026-08-03T09:28:27-04:00 | Codex / NLSpec tracker-revision session | The tracker distinguishes repository facts, owner requirements, authorized implementation requirements, and non-authoritative owner proposals. | Inspected `temp/analysis-notes.md`, `docs/research/nlspec-spec.md`, this tracker, and repository status; touched only this tracker. | Read-only `wc`, `sed`, `rg`, `find`, date, and Git inspection; `apply_patch`; `make lint-markdown`. | SL-06 direction recorded as authorized; SL-07 remains owner-blocked; Markdown validation passed at `.cartulary/test-results/20260803T133511Z-p3857129`; no owner or product file changed. | RB-002; RB-001 retains a data-preflight gate. | In a later implementation task, run SL-00/SL-02 and IND-015 before SL-06. |
| 2026-08-03T10:04:36-04:00 | Codex / implementation session | Complete remediation authorized; tracker converted to the active execution ledger. | Updated this tracker only and preserved the clean production baseline. | Git inspection, baseline evidence review, `apply_patch`, and `make lint-markdown`. | Starting commit, dirty state, execution order, per-workstream commit gate, and four passing baseline run roots recorded; Markdown passed at `.cartulary/test-results/20260803T140517Z-p3878050`. | None for SL-00. | Commit tracker bootstrap, then begin SL-00 characterization. |
| 2026-08-03T11:21:11-04:00 | Codex / SL-03 implementation | One typed Indicator Store façade now coordinates workflows over three caller-transaction repositories and is shared by server consumers. | Split source, observation, and lifecycle SQL; changed Store, Workbook, Imports, Network Flow, application/test composition, boundary policy, focused tests, generated topology, and this tracker. | `make task-guide ROLE=module-author OWNER=module.indicators`; `make format`; focused and full Indicator slices; `make backend-module-boundary-check`; `make test-fast`; `make generate`; drift/policy/shape checks; `make lint-markdown`. | Transaction row passed at `.cartulary/test-results/20260803T151618Z-p49088`; seven service-backed units passed at `.cartulary/test-results/20260803T151639Z-p51222`; boundary passed at `.cartulary/test-results/20260803T151739Z-p54095`; 346 fast units passed at `.cartulary/test-results/20260803T151802Z-p56812`; drift, artifact policy, and shape passed at `.cartulary/test-results/20260803T152022Z-p117716`, `.cartulary/test-results/20260803T152037Z-p120313`, and `.cartulary/test-results/20260803T152037Z-p120323`. The first owner task-guide invocation used a non-owner slug and was corrected; the first transaction run exposed a test-only import cycle and the first boundary run exposed stale SQL access paths, both fixed before the recorded passing reruns. | `StoreDependencies.Projections` and direct projection removal intentionally enter together in SL-04 because the current provider does not yet advertise or implement row refresh. No route, database schema, or public contract changed. | Run Markdown validation, commit SL-03, record its SHA at SL-04 entry, then add the projection coordinator dependency and retire the local query path. |
| 2026-08-03T11:42:50-04:00 | Codex / SL-04 implementation | The Indicator Store requires a narrow Projections port; mutation refresh/load and generic queries are the only production projection paths. | Added provider row refresh and shared derivation, injected the coordinator everywhere, deleted local query/paging code, moved keyset coverage, removed direct test-support SQL, updated provider/boundary/test manifests, generated topology, and this tracker. | Indicator and Projections task guides/slices; focused Workbook projection row; `make format`; `make backend-module-boundary-check`; `make generate`; drift/policy/shape checks; `make test-fast`; `make lint-markdown`. | Projection delegation passed at `.cartulary/test-results/20260803T153205Z-p139308`; final Indicator service evidence passed at `.cartulary/test-results/20260803T153735Z-p159682`; Projections unit/service evidence passed at `.cartulary/test-results/20260803T153235Z-p142288` and `.cartulary/test-results/20260803T153252Z-p148581`; Workbook projection evidence passed at `.cartulary/test-results/20260803T153855Z-p167742`; boundary passed at `.cartulary/test-results/20260803T153645Z-p154409`; drift/policy/shape passed at `.cartulary/test-results/20260803T153829Z-p164110`, `p164145`, and `p164126`; 346 fast units passed at `.cartulary/test-results/20260803T153922Z-p170208`. The first boundary run exposed a direct projection read in Indicator test support, and one subsequent owner run exposed its now-unused import; both were removed before final passing reruns. | No public route, row shape, database schema, provider ID, query semantics, or migration changed. Test-only direct projection writes remain solely as rebuild/rollback fault fixtures; production access is policy-confined. | Run Markdown validation, commit SL-04, record its SHA at SL-05 entry, then encapsulate provider implementation packages. |

| 2026-08-03T12:00:48-04:00 | Codex / SL-05 implementation | Projection, revision, and Incident Bundle coordination now consumes only root Indicator contributions and generic contracts. | Moved four provider families under `internal/providers`; added three root contributions and two boundary/completeness tests; updated generic Projection source injection, three assemblies, provider/boundary/test manifests, generated topology, and this tracker. | Owner task guides; Indicator unit/service; focused Projection, Revision, and Incident Bundle rows; `make format`; boundary; fast; generate/drift/policy/shape checks; Markdown validation. | Indicator unit/service passed at `.cartulary/test-results/20260803T155209Z-p248294` and `.cartulary/test-results/20260803T155526Z-p278368`; Projection catalog at `.cartulary/test-results/20260803T155451Z-p274441`; Revision adapters/Indicator child rollback at `.cartulary/test-results/20260803T155505Z-p276493`; Incident Bundle source catalog at `.cartulary/test-results/20260803T155520Z-p278043`; boundary at `.cartulary/test-results/20260803T155109Z-p239992`; 346 fast units at `.cartulary/test-results/20260803T155545Z-p280313`; drift/policy/shape at `.cartulary/test-results/20260803T155827Z-p343642`, `p343643`, and `p343649`; Markdown at `.cartulary/test-results/20260803T160247Z-p348343`. | No runtime ID, route, schema, database, provider registration, or public payload changed. The full Incident Bundle integration attempt at `.cartulary/test-results/20260803T155236Z-p252662` reached the already-recorded invalid `domain`/`auto_extract` fixture; its authorized correction is the first SL-06 action, while the focused source-catalog gate passes. | Commit SL-05, record its SHA in the ledger-only gate, then begin SL-06 exact origin enforcement. |
| 2026-08-03T12:20:35-04:00 | Codex / SL-06 implementation | Exact observation provenance is enforced at the owner API, history/portable read boundaries, and database storage. | Added the origin registry/capability and migration 00055; changed observation parameters/records/repository; hardened rollback and source-port preparation; corrected Indicator, Revisions, and Incident Bundle fixtures; added three focused origin rows; regenerated topology; updated this tracker. | `make format`; focused and service-backed Indicator rows; affected Revisions and Incident Bundle rows; `make migration-drift`; boundary, fast, generate/drift/policy/shape, and Markdown checks. | Final roots are recorded in the tests row below; Markdown passed at `.cartulary/test-results/20260803T162421Z-p457169`. No route, envelope, status, view key, or valid portable row changed; invalid origin aliases now fail closed. | No product blocker. The first standalone migration run could not bind port 5432 because another Cartulary worktree owned it; the same Make target passed against that existing Cartulary compose service using isolated scratch databases and automatic cleanup. | Commit SL-06, record its SHA in the ledger-only gate, then begin SL-07 strict portability. |
| 2026-08-03T13:07:59-04:00 | Codex / SL-07 implementation | Strict source-major-1 Indicator portability is complete: bytes are schema-bound, preparation is typed and context-bound, apply is fixed-column, and validation owns the exact final-state invariants. | Replaced the physical-row provider with five focused portable files; added strict invariant/final-state tests; corrected one Incident Bundle envelope fixture; updated boundary/test manifests, generated topology, and this tracker. | `make format`; `make generate`; focused and full Indicator/Incident Bundle/Revision slices; boundary, lint, fast, drift/policy/shape, and Markdown checks. | Indicator unit/service passed at `.cartulary/test-results/20260803T170100Z-p601755` and `p604295`; Incident Bundle service/unit passed at `.cartulary/test-results/20260803T165851Z-p588827` and `.cartulary/test-results/20260803T170526Z-p670745`; four focused Revision portability units passed at `.cartulary/test-results/20260803T170621Z-p678126`; fast and lint passed at `.cartulary/test-results/20260803T170136Z-p605817` and `.cartulary/test-results/20260803T170716Z-p699013`; Markdown passed at `.cartulary/test-results/20260803T171324Z-p716704`. | No product blocker. The broad Revision run at `.cartulary/test-results/20260803T170543Z-p674348` failed only seven browser-fixture startup rows; the four affected portability rows pass in isolation. | Commit SL-07, record its SHA, then begin SL-08 accounting and final handoff. |
| 2026-08-03T13:32:39-04:00 | Codex / SL-08 completion | Every required claim has explicit owner routing, all affected owner slices pass, and repository-wide final validation is green. | Added one Indicator concurrency test; updated the Indicator verification owner/test family, Make-generated topology, and this tracker. | Six owner task guides; affected unit/service slices; `make generate`; boundary, migration, drift, policy, shape, Markdown, and fast gates; `make agent-finalize`; `make check`. | Indicator unit/service passed at `.cartulary/test-results/20260803T172054Z-p738354` and `p740919`; final policy roots are recorded below; 346 fast units passed at `.cartulary/test-results/20260803T172444Z-p777632`; finalize passed at `.cartulary/test-results/20260803T172659Z-p833279`; all 708 check units passed at `.cartulary/test-results/20260803T172723Z-p835892`; final Markdown passed at `.cartulary/test-results/20260803T173444Z-p961005`. | None. Retained-run maintenance was skipped because `RESULTS_DIR` was unset. | Commit SL-08, record its SHA in the final ledger, and hand off the completed effort. |

### Backend module boundary

| Time | Agent/session | Current state | Files inspected or touched | Commands run | Result | Blockers | Next action |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 2026-08-03T08:32:42-04:00 | Codex / tracker-authoring session | Indicators confirmed as a legitimate source owner with a mixed root Store, duplicate query path, and provider seams. | Inspected all 26 target files, assemblies, callers, schema ownership, and backend boundary manifest; touched only this tracker. | `find internal/modules/indicators -type f`; targeted `rg`; direct `sed`; `make explain-target` for relevant targets. | Every target file inventoried; structural slices SL-01 through SL-05 are sequenced. | Behavior corrections remain separately blocked by RB-001/RB-002. | Add conformant characterization before moving code. |
| 2026-08-03T09:28:27-04:00 | Codex / NLSpec tracker-revision session | The structural diagnosis is unchanged; SL-02 is now an explicit prerequisite for both conformance corrections. | Rechecked the 26-file target count and revised only this tracker. | `find internal/modules/indicators -type f`; `rg`; Git inspection; `apply_patch`; `make lint-markdown`. | Origin validation and portability interfaces are specified as transport-neutral source-owner boundaries without moving code. | SL-07 cannot proceed from tracker language; IND-016 is required. | Preserve SL-00 through SL-05 order; complete IND-015 before SL-06. |
| 2026-08-03T11:21:11-04:00 | Codex / SL-03 implementation | Fixed Indicator persistence is isolated behind source, observation, and lifecycle repositories; the root owns transaction, idempotency, revision, and workflow ordering. | Added four repository files and two focused boundary/atomicity tests; updated server, Import, Workbook, Network Flow, test composition, and `tools/backend_module_boundaries.json`. | Focused structure and transaction rows; full Indicator service-backed slice; `make backend-module-boundary-check`; `make test-fast`. | Repository files contain no transaction begin/commit, revision append, projection, or idempotency behavior. Injected revision failure leaves no Indicator source, projection, history, idempotency, observation, or lifecycle state. Final boundary and broad runs pass at the roots above. | Direct projection SQL remains deliberately confined to `store.go` until SL-04 introduces the required Projections port. | Commit this boundary as SL-03 before beginning SL-04. |
| 2026-08-03T11:42:50-04:00 | Codex / SL-04 implementation | Projection storage access is policy-confined to the Indicator provider and generic Projections deletion; Store and test support contain no production projection SQL. | Updated Indicator provider, Projections factory/core, Store port, all composition sites, generic query tests, and the SQL access boundary; removed `query.go` and its target-private test. | `make backend-module-boundary-check`; Indicator/Projections/Workbook owner slices; `make test-fast`. | The final boundary run passed at `.cartulary/test-results/20260803T153645Z-p154409`; injected projection failure rolls back the source and idempotency transaction, and generic refresh/load/rebuild/query parity passes. | Test files may delete or inspect projection rows to simulate rebuild/failure; the production scan rule excludes those fixtures and rejects any new unauthorized source path. | Commit SL-04 before changing provider visibility in SL-05. |

| 2026-08-03T12:00:48-04:00 | Codex / SL-05 implementation | Provider semantics are Go-internal and explicit boundary rules permit only root owner contributions to import them. | Moved delete/restore, rollback, projection, and Incident Bundle leaves; updated SQL/import allowlists; added a production-import scan across generic coordinators. | `make backend-module-boundary-check`; focused owner slices; `make test-fast`. | Initial boundary evidence found two test-only source-port imports and the first Projection run found the missing authored import-policy mirror; both were corrected. Final boundary and catalog roots pass as recorded above. | None; Go `internal` and the authored manifest now enforce the same direction. | Commit the provider boundary before origin work. |
| 2026-08-03T12:20:35-04:00 | Codex / SL-06 implementation | Origin authority is split cleanly between an owner-internal closed registry and a root façade exposing only ordinary producer capabilities. | Added `internal/origin`, the public producer façade, repository enforcement, and provider read revalidation. | Focused origin/rollback rows; `make backend-module-boundary-check`; `make test-fast`. | Rollback rejection passed at `.cartulary/test-results/20260803T161710Z-p389924`; boundary passed at `.cartulary/test-results/20260803T161719Z-p390386`; 346 fast units passed at `.cartulary/test-results/20260803T161804Z-p394856`. | None; callers cannot construct `system` and cannot provide a raw origin string. | Preserve this capability boundary while implementing SL-07 portable preparation. |
| 2026-08-03T13:07:59-04:00 | Codex / SL-07 implementation | The owner-internal Incident Bundle provider exclusively owns Indicator Records reads, canonical row semantics, and fixed source-table SQL. | Split export, model, prepare, apply, and validate responsibilities; authorized only the internal portability provider to import source-port and Records readers; removed physical row population. | `make backend-module-boundary-check`; focused and full Indicator/Incident Bundle slices; `make test-fast`. | Boundary passed at `.cartulary/test-results/20260803T170512Z-p669945`; Indicator and Incident Bundle evidence passes at the roots above. The first boundary run exposed the obsolete single-file allowlist and passed after the authored policy named the exact internal files. | None; generic Incident Bundle coordination owns transactions and publication, but no Indicator-specific SQL or invariant policy. | Commit the source-owner boundary before final accounting. |
| 2026-08-03T13:32:39-04:00 | Codex / SL-08 completion | Final accounting changes no production boundary; the new dedicated test proves overlapping owner transactions converge without introducing another lock or façade. | Inspected Store incident-open locking, unique identity storage, boundary policy, and the new concurrency evidence. | Indicator identity concurrency row; `make backend-module-boundary-check`; affected owner slices; `make check`. | Concurrency passed at `.cartulary/test-results/20260803T172001Z-p732733`; boundary at `.cartulary/test-results/20260803T172326Z-p766739`; full check at `.cartulary/test-results/20260803T172723Z-p835892`. The test's first draft incorrectly expected an advisory lock; inspection showed the required incident-open row lock already supplies owner serialization, so the redundant production lock was removed before the passing run. | None; production code is unchanged in SL-08. | Preserve explicit claim ownership and hand off the completed module. |

### Frontend module boundary

| Time | Agent/session | Current state | Files inspected or touched | Commands run | Result | Blockers | Next action |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 2026-08-03T08:32:42-04:00 | Codex / tracker-authoring session | No Indicator-specific frontend controller or grid-vendor layer exists; generic Workbook/View Contracts own the surface. | Inspected generic view-contract, selector, query-model, Workbook unit, and browser Indicator cases; touched only this tracker. | Targeted `rg` and direct `sed`. | Public selector/view identities are frozen; raw timestamp-field inference is deferred to its owner. | No backend blocker; frontend cleanup is intentionally deferred. | Run frontend boundary/browser checks only if a later slice touches frontend ownership or public wiring. |
| 2026-08-03T09:28:27-04:00 | Codex / NLSpec tracker-revision session | Frontend ownership and frozen selector/view behavior remain unchanged. | Reused the prior inspected frontend evidence; touched only this tracker. | Tracker reads, `apply_patch`, and `make lint-markdown`; no frontend command ran. | No Indicator-specific controller, saved-view owner, or grid-vendor layer is proposed. | None for this tracker revision. | Run frontend boundary/browser checks only when a later slice changes frontend ownership or visible Workbook wiring. |

| 2026-08-03T12:00:48-04:00 | Codex / SL-05 implementation | Frontend ownership, routes, view IDs, selectors, and payloads are unchanged by backend provider encapsulation. | No frontend file changed. | `make test-fast`; no browser suite was required for an internal provider-path-only change. | Fast coverage passed; public application assembly still registers the same generic provider/source IDs. | None. | Run browser coverage only if SL-06 changes an externally reachable producer mapping. |
| 2026-08-03T12:20:35-04:00 | Codex / SL-06 implementation | Public Workbook Indicator create/query behavior is unchanged; observation producer selection remains an owner-internal backend surface. | No frontend file changed. | Affected backend owner slices and `make test-fast`. | Fast coverage passed at `.cartulary/test-results/20260803T161804Z-p394856`; no frontend selector, route, field key, or payload changed. | None. | No frontend action in SL-07 unless an adopted portable contract consumer requires it. |
| 2026-08-03T13:07:59-04:00 | Codex / SL-07 implementation | Portable source internals changed without altering any frontend route, selector, field key, view, or payload. | No frontend file changed. | `make test-fast`; `make lint`; backend owner and Incident Bundle validation. | Fast and lint pass at `.cartulary/test-results/20260803T170136Z-p605817` and `.cartulary/test-results/20260803T170716Z-p699013`; no browser suite was required for an owner-internal portable-source replacement. | None; the unrelated Revision browser-fixture startup failure does not exercise this backend source port. | Keep frontend timestamp-inference debt assigned to its existing owner during SL-08 handoff. |
| 2026-08-03T13:32:39-04:00 | Codex / SL-08 completion | No frontend implementation or contract changed; full-check frontend units remain green. | No frontend file changed. | Affected backend owner slices; `make test-fast`; `make check`. | Fast and full check pass at `.cartulary/test-results/20260803T172444Z-p777632` and `.cartulary/test-results/20260803T172723Z-p835892`. | None. Raw Indicator timestamp inference remains a separately owned Workbook/View Contracts follow-up, not an Indicators blocker. | Hand off that named debt without expanding this completed module scope. |

### Contract and codegen

| Time | Agent/session | Current state | Files inspected or touched | Commands run | Result | Blockers | Next action |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 2026-08-03T08:32:42-04:00 | Codex / tracker-authoring session | View, import, projection, portability, recovery, and generated-consumer risks mapped. | Inspected authored contracts/manifests listed in Section 1; touched only this tracker. | `jq`, `rg`, direct reads, and `make explain-target` for drift targets. | Generated roots identified as downstream-only; provider/source ownership is explicit. | Full portability validation requires RB-002 authorization. | Change authored inputs only when a later slice requires it, then regenerate through Make. |
| 2026-08-03T09:28:27-04:00 | Codex / NLSpec tracker-revision session | The ten portability IDs are mapped, but the exact portable shape, partition, precedence, and Core 04 criteria remain missing owner authority. | Inspected analysis recommendations and current tracker evidence; touched only this tracker, not Core or authored contracts. | `sed`, `rg`, Git inspection, `apply_patch`, and `make lint-markdown`; no generation ran. | Proposed owner language is quarantined from implementation requirements; generated consumers remain downstream-only. | `BLOCKED: owner definition incomplete` under RB-002/IND-016. | Adopt Core 01/Core 04 and authored traceability before authorizing SL-07. |
| 2026-08-03T10:24:47-04:00 | Codex / IND-016 owner closure | Indicator source-major-1 shape, stable order, invariant partition, failure selection, and phase allocation are adopted. | Updated Core 01/Core 04, added three authored row schemas and schema IDs, updated source catalog/port descriptor, traceability, verification ownership, generated topology, and this tracker. | `make format`; `make generate`; `make json-shape-check`; `make generated-artifact-policy-check`; `make test-catalog-check`; focused Incident Bundle and Indicator slices; `make lint-markdown`. | Shape and artifact policy passed at `.cartulary/test-results/20260803T142213Z-p3957246` and `p3957244`; 26 Incident Bundle units passed at `.cartulary/test-results/20260803T142227Z-p3958348`; six Indicator service-backed units passed at `.cartulary/test-results/20260803T142250Z-p3964464`; final Markdown, shape, and generation drift passed at `.cartulary/test-results/20260803T142504Z-p3968039`, `p3967971`, and `p3967967`. The first shape check correctly failed on stale generated topology and passed after `make generate`. | None; RB-002 resolved. | Commit IND-016, then implement SL-02 canonical identity. |
| 2026-08-03T11:42:50-04:00 | Codex / SL-04 implementation | The authored Indicator projection descriptor now truthfully declares transactional row refresh and generated harness topology includes its delegation evidence. | Changed `contracts/projection-providers/index.json`, projection assembly capability, Indicator test-family input, generated topology index, and this tracker. | `make generate`; `make test-catalog-check`; `make generate-drift`; `make generated-artifact-policy-check`; `make json-shape-check`. | Generation passed at `.cartulary/test-results/20260803T153808Z-p161724`; final drift/policy/shape passed at `.cartulary/test-results/20260803T153829Z-p164110`, `p164145`, and `p164126`; catalog validation passed. | None; no generated root was hand-edited. | Commit SL-04 and proceed to provider encapsulation. |

| 2026-08-03T12:00:48-04:00 | Codex / SL-05 implementation | The authored Projection import policy includes the new Indicator root contribution and focused structure accounting includes provider encapsulation. | Updated `contracts/projection-providers/index.json`, `tools/test_families/module.indicators.json`, generated `tools/execution_topology_render_index.json`, and boundary input. | `make generate`; `make generate-drift`; `make generated-artifact-policy-check`; `make json-shape-check`. | Generation passed at `.cartulary/test-results/20260803T155813Z-p341270`; final drift/policy/shape passed at `.cartulary/test-results/20260803T155827Z-p343642`, `p343643`, and `p343649`. Initial drift/shape correctly reported stale topology before Make regeneration. | None; the generated topology file was produced only through `make generate`. | Commit SL-05 and proceed to origin enforcement. |
| 2026-08-03T12:20:35-04:00 | Codex / SL-06 implementation | Migration history and focused origin verification now project the exact seven-token owner registry. | Added migration 00055 and its authored history entry; added three Indicator test-family rows; regenerated only the derived topology index. | `make generate`; `make migration-drift`; `make generate-drift`; `make generated-artifact-policy-check`; `make json-shape-check`. | Generation passed at `.cartulary/test-results/20260803T161700Z-p387711`; migration drift passed at `.cartulary/test-results/20260803T162129Z-p453602`; generation drift, artifact policy, and JSON shape passed at `.cartulary/test-results/20260803T161728Z-p390813`, `p390826`, and `.cartulary/test-results/20260803T161758Z-p394339`. | None; the initial JSON shape run exposed migration exception text that resembled DDL to the schema scanner and passed after the text was made unambiguous. | Commit authored inputs and their Make-generated topology together. |
| 2026-08-03T13:07:59-04:00 | Codex / SL-07 implementation | The adopted row schemas now have direct strict-decoding, invariant, and final-state execution rows; no generated contract root was edited by hand. | Updated the authored Indicator test family and backend boundary input; regenerated the execution-topology index through Make. | `make generate`; `make generate-drift`; `make generated-artifact-policy-check`; `make json-shape-check`. | Generation passed at `.cartulary/test-results/20260803T170021Z-p598552`; drift, artifact policy, and JSON shape passed at `.cartulary/test-results/20260803T170356Z-p665377`, `p665402`, and `.cartulary/test-results/20260803T170514Z-p670267`. Two initial generation attempts exposed authored row-order/schema errors and passed after correcting the authored manifest. | None; source major 1 and valid bundle v1/v2 behavior remain supported. | Commit authored inputs with their Make-generated projection, then refine final verification ownership in SL-08. |
| 2026-08-03T13:32:39-04:00 | Codex / SL-08 completion | The Indicator owner declares ten distinct verification IDs and fourteen rows; generated topology is current and route integration no longer claims portability. | Updated `contracts/verification/owners/module.indicators.json` and the authored test family; regenerated only the topology projection through Make. | `make generate`; test catalog; generation drift; artifact policy; JSON shape; full check. | Generation passed at `.cartulary/test-results/20260803T172014Z-p734768`; drift, policy, and shape passed at `.cartulary/test-results/20260803T172432Z-p772771`, `.cartulary/test-results/20260803T172439Z-p775285`, and `.cartulary/test-results/20260803T172440Z-p775683`. | None; no generated root was edited by hand. | Commit authored and generated accounting together. |

### Tests and harness

| Time | Agent/session | Current state | Files inspected or touched | Commands run | Result | Blockers | Next action |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 2026-08-03T08:32:42-04:00 | Codex / tracker-authoring session | Focused owner has three service-backed rows; broader tests cover additional behavior without focused Indicator mapping. | Inspected Indicator tests, cross-owner tests, owner verification contract, and test-family manifest; touched only this tracker. | `make task-guide ROLE=module-author OWNER=module.indicators`; `make explain-test-owner OWNER=module.indicators`; `jq`; targeted searches; `make lint-markdown`. | Exact focused commands and row IDs recorded in Section 8. Tracker Markdown validation passed; no product tests, generation, or product validation ran. | New executable characterization remains future work. | Author SL-00 tests and rows before structural implementation. |
| 2026-08-03T09:28:27-04:00 | Codex / NLSpec tracker-revision session | Binary `AC-ORIGIN-*` and `AC-PORT-*` matrices now define future evidence without changing harness routing. | Inspected analysis test recommendations and existing tracker test posture; touched only this tracker. | Read-only document inspection, `apply_patch`, and `make lint-markdown`. | Markdown validation passed at `.cartulary/test-results/20260803T133511Z-p3857129`; no product test, harness generation, drift check, or retained product run executed. | Executable tests remain future work; portability tests await IND-016. | Add owner-mapped SL-00 evidence, then implement only slices whose gates are satisfied. |
| 2026-08-03T10:13:53-04:00 | Codex / SL-00 implementation | Identity and portable-row characterization are owner-accounted and invalid Indicator fixtures no longer bless `interactive_cell`. | Added identity and portability characterization tests; updated three existing Indicator fixture files, the Indicator test-family manifest, generated topology, and this tracker. | `make format`; `make test-catalog-check`; focused `make test-slice`; `make service-backed-test-slice OWNER=module.indicators`; `make test-fast`; `make generate`; drift/policy/shape checks; `make lint-markdown`. | Identity row passed at `.cartulary/test-results/20260803T141034Z-p3887120`; six service-backed units passed at `.cartulary/test-results/20260803T141040Z-p3887800`; 346 fast units passed at `.cartulary/test-results/20260803T141054Z-p3889600`; final drift/policy/shape checks passed at `.cartulary/test-results/20260803T141339Z-p3942258`, `p3942260`, and `p3942262`; Markdown passed at `.cartulary/test-results/20260803T141444Z-p3945638`. The first identity run failed because the test guessed the current missing-hash field attribution; the observed behavior was characterized and the rerun passed. The first drift run correctly reported the new harness-row digest and passed after `make generate`. | None. | Commit SL-00, then run IND-015 persisted-origin preflight. |
| 2026-08-03T10:39:42-04:00 | Codex / SL-02 implementation | Canonical Indicator identity has one pure owner-internal implementation, and the SL-02 checkpoint follows commits `23f756f1` (bootstrap), `4aee70a2` (SL-00), `b32ee3c6` (IND-015), and `f894d9ca` (IND-016). | Added `internal/identity`, routed root admission/observations, imports, Network Flow, rollback, and portability preparation through it; removed duplicate Store and rollback algorithms; added portable identity evidence and updated its focused owner selector and generated topology. | `make format`; focused `make test-slice`; `make service-backed-test-slice OWNER=module.indicators`; `make backend-module-boundary-check`; `make test-fast`; `make generate`; `make generate-drift`; `make lint-markdown`. | Final identity row passed at `.cartulary/test-results/20260803T143537Z-p3998959`; six service-backed units passed at `.cartulary/test-results/20260803T143445Z-p3993093`; boundary check passed at `.cartulary/test-results/20260803T143532Z-p3998587`; 346 fast units passed at `.cartulary/test-results/20260803T143541Z-p3999922`; generation drift passed at `.cartulary/test-results/20260803T143802Z-p4060635`; Markdown passed at `.cartulary/test-results/20260803T144006Z-p4063946`. An initial focused run exposed two compile errors in the rollback adapter and an initial boundary run exposed a test-only owner-port import; both were corrected and the recorded reruns pass. | None; no migration or public contract changed. The SL-02 commit is the checkpoint containing this row and is resolved from Git before SL-01 begins. | Commit SL-02, record its SHA at SL-01 entry, then begin transport-neutral admission. |
| 2026-08-03T10:59:26-04:00 | Codex / SL-01 implementation | Workbook now owns Indicator transport admission and replay hashing; Indicators exposes only a semantic command and owner validation. | Removed Indicator decoder/hash/HTTP/view-schema dependencies, added Workbook `indicator_admission.go`, converted all owner callers to semantic command fields, added pre-owner rejection/hash compatibility and admission boundary tests, updated the Workbook test-family manifest, and regenerated topology. | `make format`; `make generate`; focused Workbook unit row; Indicator and selected Workbook service-backed slices; `make backend-module-boundary-check`; `make browser-e2e-webserver-backed`; `make test-fast`; drift/policy/shape checks; `make lint-markdown`. | Workbook admission passed at `.cartulary/test-results/20260803T145126Z-p4088478`; six Indicator service units passed at `.cartulary/test-results/20260803T145210Z-p4096265`; five selected Workbook service units passed at `.cartulary/test-results/20260803T145223Z-p4098174`; boundary passed at `.cartulary/test-results/20260803T145241Z-p4099850`; 62 browser units passed at `.cartulary/test-results/20260803T145242Z-p4100267`; 346 fast units passed at `.cartulary/test-results/20260803T145617Z-p4152450`; drift, artifact policy, and shape passed at `.cartulary/test-results/20260803T145831Z-p16256`, `p18774`, and `p19165`. Three initial generation attempts failed only while the new authored row was being ordered and owner-scoped; the final generated topology and all recorded gates pass. | The unused local Indicator query still imports view-schema types and remains intentionally isolated for SL-04 deletion; the admission/API/Store seam is transport-neutral now. No wire, route, status, replay, schema, or migration changed. | Run Markdown validation, commit SL-01, record its SHA at SL-03 entry, then extract caller-transaction repositories and typed dependencies. |
| 2026-08-03T11:21:11-04:00 | Codex / SL-03 implementation | Focused Indicator accounting now has explicit structure and transaction-atomicity rows in addition to preserved create, route, portability, observation, and lifecycle evidence. | Added two authored Indicator rows, regenerated the execution-topology index, and updated this tracker. | Focused structure row via `make test-slice`; focused transaction row; full service-backed owner slice; `make test-fast`; generation drift, artifact policy, and JSON shape. | Structure coverage passed within `.cartulary/test-results/20260803T151243Z-p37005`; transaction coverage passed at `.cartulary/test-results/20260803T151618Z-p49088`; full service-backed and broad evidence pass at the roots recorded above. | Projection-specific fault injection belongs to SL-04 after the port exists; no current repository can inject that boundary without coupling tests to physical projection SQL. | Commit SL-03 and begin only SL-04. |
| 2026-08-03T11:42:50-04:00 | Codex / SL-04 implementation | Focused accounting now includes projection delegation; the existing transaction row also injects projection failure, and generic Projections evidence owns Indicator keyset/parity assertions. | Added the Indicator projection row, expanded atomicity, updated the generic query test, provider descriptor, Indicator manifest, and generated topology. | Focused Indicator projection row; full Indicator and Projections slices; selected Workbook integration row; test catalog, drift, policy, shape, boundary, and fast suites. | All final roots listed in the SL-04 session row pass; mutation rows load through the generic service and the removed local paging test is replaced by Indicator-specific coverage inside `TestGenericProjectionPageSQLIsKeysetBounded`. | None for SL-04. | Commit and enter SL-05 provider encapsulation. |

| 2026-08-03T12:00:48-04:00 | Codex / SL-05 implementation | The existing structure row now owns explicit provider-import and contribution-completeness evidence; local rollback tests moved with their internal packages. | Added `provider_encapsulation_test.go` and `projection_contribution_test.go`; updated the Indicator test-family selector and generated topology. | Indicator unit/service, focused cross-owner rows, boundary, and fast suites. | All SL-05-focused rows pass at the roots above. A broad Revision attempt at `.cartulary/test-results/20260803T155236Z-p252652` exposed a harness browser-session `OWNER` propagation failure unrelated to these files; the exact delete/restore and Indicator child rollback rows pass at `.cartulary/test-results/20260803T155505Z-p276493`. | The known Incident Bundle invalid-origin fixture is intentionally not blessed and is carried directly into SL-06. | Commit SL-05; add exact origin rows in SL-06 rather than overloading this structural row. |
| 2026-08-03T12:20:35-04:00 | Codex / SL-06 implementation | Three explicit origin rows cover parser/capability/pre-write behavior, database storage, and rollback history; existing identity/portable and service rows cover round trips and repeated observations. | Added two root origin tests and one rollback-provider test; strengthened portable and repeated-observation assertions; corrected affected cross-owner fixtures. | Focused origin rows; Indicator identity row; full Indicator service slice; focused Revisions and Incident Bundle service rows; `make test-fast`. | Origin unit/storage passed at `.cartulary/test-results/20260803T161444Z-p376221`; rollback at `.cartulary/test-results/20260803T161710Z-p389924`; Indicator service at `.cartulary/test-results/20260803T161537Z-p380950`; Revisions at `.cartulary/test-results/20260803T161623Z-p383477`; Incident Bundle at `.cartulary/test-results/20260803T161636Z-p385567`; fast at `.cartulary/test-results/20260803T161804Z-p394856`. | None. The first origin service test needed a savepoint after intentionally violating the check; the passing rerun proves the expected rejection without aborting its surrounding fixture transaction. | Commit SL-06 and keep route integration distinct from SL-07 portability invariant claims. |
| 2026-08-03T13:07:59-04:00 | Codex / SL-07 implementation | Two explicit Indicator portability rows cover strict partition/decoding and all ten final-state invariants; route integration remains separately selected. | Added strict malformed-input, hostile-value, multi-defect ordering, context-binding, final-state, repeated-observation, v1/v2, and atomicity evidence. | Focused partition and final-state rows; full Indicator and Incident Bundle unit/service slices; focused Revision portability rows; `make test-fast`. | Partition passed at `.cartulary/test-results/20260803T170028Z-p600721`; final state at `.cartulary/test-results/20260803T165654Z-p574640`; full owner and cross-owner roots are recorded above. The first fast run exposed an obsolete minimal portability fixture, and the first Incident Bundle run exposed mismatched Records/subtype timestamps; both fixtures were made exact before the final passes. | No product blocker. The broad Revision browser-fixture attempt is retained as unrelated failure evidence; exact affected rollback/portability rows pass. | Commit SL-07; SL-08 will make every claim independently attributable in verification ownership. |
| 2026-08-03T13:32:39-04:00 | Codex / SL-08 completion | Explicit rows independently cover characterization, identity parity/concurrency, origin, projection delegation, provider boundaries, transaction atomicity, routes, and all portability invariants. | Added the concurrency test/row; split verification IDs without duplicating test execution; retained the exact existing selectors. | Full Indicator and Projection unit/service; focused Revision, Network Flow, and Workbook rows; full Incident Bundle unit/service; fast and check. | Projection passed at `.cartulary/test-results/20260803T172110Z-p742201` and `p748086`; Revision at `.cartulary/test-results/20260803T172142Z-p749429` and `p752278`; Network Flow at `.cartulary/test-results/20260803T172209Z-p753938` and `p754823`; Workbook at `.cartulary/test-results/20260803T172227Z-p756251` and `p756982`; Incident Bundle at `.cartulary/test-results/20260803T172243Z-p758515` and `p765087`. | None; the first concurrency-test run at `.cartulary/test-results/20260803T171839Z-p726695` failed only its overly specific lock-kind assertion and passed after asserting the actual owner transaction boundary. | Commit complete accounting and preserve every run root. |

### Security and authorization

| Time | Agent/session | Current state | Files inspected or touched | Commands run | Result | Blockers | Next action |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 2026-08-03T08:32:42-04:00 | Codex / tracker-authoring session | Generic Workbook route re-derives membership/role; Indicator Store enforces incident-open and route idempotency; Revisions appends collaboration intent. | Inspected Core 04 authorization, Workbook routes, Indicator Store, Revisions appender, and generic route scenario inventory; touched only this tracker. | Direct reads and targeted `rg`. | Create/query authorization, CSRF, replay ordering, attribution, and event semantics are in the freeze map. | None for structural planning. | Add focused create auth/replay/event characterization in SL-00. |
| 2026-08-03T09:28:27-04:00 | Codex / NLSpec tracker-revision session | SL-06 now requires exact pre-write origin rejection and trusted context for `system`; proposed SL-07 requires safe deterministic errors and final-transaction atomicity. | Inspected analysis security/atomicity recommendations and existing owner posture; touched only this tracker. | `sed`, `rg`, `apply_patch`, and `make lint-markdown`; no security or product test ran. | Authorization ownership and public envelopes remain frozen; hostile data and internal details are explicitly excluded from proposed portability errors. | SL-06 needs IND-015; SL-07 needs IND-016 and later authorization. | Prove no partial mutation/publication in the applicable future acceptance matrices. |
| 2026-08-03T10:16:00-04:00 | Codex / IND-015 preflight | Repository origin fixtures classified; no persistent local development deployment was running and no external deployment was in task scope. | Inspected all non-document origin tokens, migrations, configuration, and local Compose state; updated this tracker only. | `rg`; configuration reads; read-only `docker compose ps`; `make lint-markdown`. | Outcome two selected: only the disposable Incident Bundle fixture remains invalid for the Indicator schema. No data rewrite is authorized; the recorded deployment query and fail-closed migration gate prevent provenance guessing. Markdown passed at `.cartulary/test-results/20260803T141630Z-p3948014`. | None for repository SL-06; an operator must remediate any rows returned in an upgrade deployment. | Commit IND-015, then adopt IND-016 owner and contract changes. |

| 2026-08-03T12:00:48-04:00 | Codex / SL-05 implementation | Provider encapsulation changes no authorization or provenance behavior. | Moved owner implementation leaves and contribution wiring only. | Indicator service-backed, Revision rollback, boundary, and fast checks. | Existing authorization/rollback behavior passes; no producer gained access to the reserved `system` origin. | Exact origin parsing, trusted producer context, fixture correction, and the database constraint remain SL-06. | Begin SL-06 only after committing this structural checkpoint. |
| 2026-08-03T12:20:35-04:00 | Codex / SL-06 implementation | Provenance is a closed audit contract: callers select one of six explicit producer capabilities, while `system` is reserved to owner-internal trusted construction. | Added exact parser/capability validation before `BeginTx`, the seven-token database constraint, and strict rollback/portable read validation. | Focused origin and rollback rows; affected service-backed owners; migration drift. | Whitespace, case variants, aliases, empty, and extension-shaped values reject exactly; the public AST surface has no system constructor; raw invalid storage rejects while stored `system` remains legal. | Upgrade deployments with pre-existing invalid rows fail closed and require operator classification; no automatic data rewrite is authorized. | Preserve safe error projection and final-transaction atomicity in SL-07. |
| 2026-08-03T13:07:59-04:00 | Codex / SL-07 implementation | Portable failures expose only a closed invariant identifier plus safe row attribution; database text, hostile values, internal digests, and physical paths are not public. | Hardened strict preparation, context binding, fixed apply, and final validation; added hostile-value redaction and coordinator-failure evidence. | Focused partition/final-state rows; Incident Bundle and Revision portability/atomicity rows. | All ten invariants select deterministically by precedence, path, stable ID, then an internal-only digest; apply/validate/precommit failures leave no visible state in the existing coordinator transaction evidence. | None; malformed archives are intentionally rejected without repair, skip, conflict-ignore, or database-detail fallback. | Retain these security claims as distinct final verification rows. |
| 2026-08-03T13:32:39-04:00 | Codex / SL-08 completion | Security-origin, transaction-atomicity, and portability-invariant claims are distinct from generic behavior and route evidence. | Updated verification ownership only; no authorization, producer capability, error projection, or migration changed. | Origin/atomicity/portability rows; migration drift; full check. | Migration drift passed at `.cartulary/test-results/20260803T172423Z-p770217`; all focused security evidence and 708 full-check units pass. The first migration attempt at `.cartulary/test-results/20260803T172327Z-p767062` reached a different Postgres on occupied port 5432; the canonical target passed against the already-running Cartulary compose service with isolated scratch databases and cleanup. | None; `system` remains owner-internal and portable failures remain redacted. | Follow migration 00055's documented Down path only if rolling back provenance enforcement. |

### Open risks and next session

| Time | Agent/session | Current state | Files inspected or touched | Commands run | Result | Blockers | Next action |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 2026-08-03T08:32:42-04:00 | Codex / tracker-authoring session | Decision-complete slice order recorded; no production refactor performed. | Touched only this tracker. | Read-only discovery commands listed above; `make lint-markdown`. | Markdown validation passed; structural work can begin at SL-00 without rediscovery. | RB-001 and RB-002 require later behavior-change authorization. | In a later authorized task, re-check baseline, run Section 8 pre-implementation commands, and implement SL-00 only. |
| 2026-08-03T09:28:27-04:00 | Codex / NLSpec tracker-revision session | The tracker is decision-complete for SL-06 entry/acceptance and for the owner work that must precede SL-07; no production refactor occurred. | Touched only this tracker. | Read-only repository/document inspection, `apply_patch`, and `make lint-markdown`. | SL-06 direction is authorized but unimplemented; RB-001 is READY for preflight; RB-002 remains BLOCKED; Markdown validation passed at `.cartulary/test-results/20260803T133511Z-p3857129`. | IND-015 may expose a separate migration/remediation dependency; IND-016 is mandatory before SL-07. | Next authorized session starts with SL-00/SL-02 and IND-015, not SL-06 enablement or SL-07 code. |

| 2026-08-03T12:00:48-04:00 | Codex / SL-05 implementation | All structural ownership slices are complete; SL-06 is admitted. | Tracker, provider packages, assemblies, neutral contracts, tests, and authored/generated manifests. | Narrow-to-broad SL-05 validation recorded above. | No unresolved SL-05 finding. The invalid Incident Bundle fixture remains visible as planned evidence for SL-06 rather than being normalized by compatibility code. | No structural blocker. | Commit SL-05, record its SHA, then enforce exact origins and add the forward check-constraint migration. |
| 2026-08-03T12:20:35-04:00 | Codex / SL-06 implementation | Exact origin enforcement is complete at checkpoint `c1facd10`; SL-07 dependencies are satisfied. | Origin façade/internal registry, repository/providers, migration 00055, corrected cross-owner fixtures, tests, harness inputs, generated topology, and this tracker. | Narrow-to-broad validation recorded above. | No unclassified SL-06 finding. Migration rollback drops only the new check; no data was rewritten. Timeline/Entities `interactive_cell` uses remain a separate-owner follow-up. | No SL-06 blocker. | Commit this SHA ledger, then implement strict schema-bound portability in SL-07. |
| 2026-08-03T13:07:59-04:00 | Codex / SL-07 implementation | Strict schema-bound portability is implementation-complete and ready for its checkpoint commit. | Owner-internal provider, tests, Incident Bundle fixture, authored/generated verification inputs, boundary policy, and this tracker. | Narrow-to-broad SL-07 validation recorded above. | No unclassified SL-07 finding. No database migration is required; valid bundle v1/v2 support remains, while malformed or semantically inconsistent archives now fail closed. | No product blocker. The retained broad Revision browser-fixture failure is unrelated and its exact affected rows pass. | Commit SL-07, record its SHA in a ledger-only gate, then begin SL-08 final verification and handoff. |
| 2026-08-03T13:15:00-04:00 | Codex / SL-07 ledger gate | The strict portability checkpoint is committed as `d0b71fbe`; no SL-08 work began before this ledger update. | Updated this tracker only. | `git commit`; `make lint-markdown`; Git status inspection. | The SL-07 commit contains the full implementation, tests, authored/generated inputs, validation evidence, and tracker checkpoint. | None. | Commit this ledger-only gate, then begin SL-08 verification accounting and completion. |
| 2026-08-03T13:32:39-04:00 | Codex / SL-08 completion | The Indicators remediation is complete with no unclassified finding or product blocker. | Final verification contract/test family, concurrency evidence, generated topology, and this tracker. | All final commands and roots recorded in the six rows above. | No runtime migration beyond reversible 00055; no data rewrite; valid bundle v1/v2 remains supported. Residual owner handoffs are: Workbook/View Contracts raw timestamp inference, a future adopted Reference Pack normalization decision, the Timeline-named runtime projection catalog, and Timeline/Entities `interactive_cell` vocabulary. | None. Retained-run maintenance was skipped because `RESULTS_DIR` was unset. | Commit SL-08, record the checkpoint SHA in the final ledger-only commit, and hand off. |
| 2026-08-03T13:35:30-04:00 | Codex / SL-08 ledger gate | The final validation and handoff checkpoint is committed as `eae355dc`; the worktree was clean before this ledger-only update. | Updated this tracker only. | `git status --short`; `git rev-parse --short HEAD`; `make lint-markdown`. | All implementation slices and the final verification/handoff content are committed. The ledger commit itself is resolved from Git because it cannot self-record its own SHA. | None. | No Indicators remediation work remains; use the four explicitly named owner handoffs for future scope. |

## 11. Open Questions and Blockers

| ID | Question or blocker | Why it matters | Needed authority or evidence | Current status |
| --- | --- | --- | --- | --- |
| RB-001 | SL-06 product direction and implementation are authorized; deployment upgrades must fail closed on any unclassified persisted origin. | Exact rejection must not silently reinterpret historical provenance. | Run the Section 4.1 query before the constraint; remediate any returned rows separately, then pass `AC-ORIGIN-*`. | RESOLVED for repository implementation — outcome two recorded; no rewrite authorized |
| RB-002 | Indicator Incident Bundle portable row contract, exclusive invariant partition, precedence, phase allocation, and complete acceptance criteria. | The source port must emit one exact deterministic public `invariant_id`. | Implement the adopted IND-016 owner and contract projections, then pass `AC-PORT-*`. | RESOLVED — owner definition and authorization complete |

No `BLOCKED: owner contradiction` entry is present because no conflict between adopted owners was found.

## 12. Binary Completion Criteria

### 12.1 Tracker-revision completion

- [x] Every file in `internal/modules/indicators` is inventoried; all 50 final files have an individual Section 2 row and none is silently excluded.
- [x] Every discovered public contract risk has a current owner, evidence reference, existing-test posture, and required characterization posture in Section 4.
- [x] Every workflow has previous/subsequent dependencies, a goal, validation, and a handoff checkpoint.
- [x] Current-state findings, adopted-owner requirements, authorized implementation requirements, proposed owner language, defaults, and intentional implementation freedom are unambiguously distinguished.
- [x] `IND-ORIGIN-001` through `IND-ORIGIN-005` define the exact vocabulary, producer mapping, interface boundary, compatibility posture, preflight, atomicity, and closure evidence; SL-06 authorization is recorded without claiming implementation.
- [x] `IND-PORT-001` through `IND-PORT-006` are closed by adopted Core 01/Core 04 owners and authored schema, source-catalog, traceability, and verification projections.
- [x] Every implementation slice is behavior-preserving unless an authorized correction is explicit; SL-06 and SL-07 are authorized and their owner/preflight gates are resolved.
- [x] Canonical Make-owned validation commands are discovered and recorded; no command is claimed to have passed unless it was actually executed successfully.
- [x] No owner contradiction was found; future contradictions must be recorded as `BLOCKED: owner contradiction` without choosing a side.
- [x] Repository/framework mismatches are recorded: SL-04 removed the redundant target-local query, while the historically Timeline-named runtime projection bundle remains a separate-owner handoff.
- [x] The seven handoff areas contain a current session row with files, commands, result, blockers, and next action.
- [x] The planning revision was completed before implementation authorization; the active ledger now records each production checkpoint separately.

### 12.2 Future implementation closure

- [x] SL-00 owner-conformant characterization is complete and does not bless `interactive_cell` or proposed portability language as current behavior.
- [x] SL-02 provides one Indicator identity implementation shared by live create, import, Network Flow, rollback, observation candidate normalization, and portability consumers.
- [x] SL-01 makes Workbook the exclusive Indicator HTTP/view-schema decoder and replay-hash adapter while Indicators accepts a semantic `CreateCommand` and retains the frozen route contract.
- [x] SL-03 retains one workflow façade, isolates fixed source/observation/lifecycle SQL behind caller-transaction repositories, shares the constructed owner across server consumers, and proves rollback on revision failure.
- [x] SL-04 makes provider refresh plus generic row loading/querying the only production projection paths, removes the local Indicator query layer, and enforces projection storage access through the boundary manifest.
- [x] SL-05 exposes only root owner contributions to Projections, Revisions, and Incident Bundles and confines provider implementations under the Indicator Go-internal boundary.
- [x] IND-015 records outcome two, provides the deployment query, and authorizes no automatic migration or provenance rewrite.
- [x] SL-06 enforces the exact seven-token registry before mutation and at storage, exposes no ordinary `system` capability, preserves exact history/portable provenance, and passes all `AC-ORIGIN-*` cases with current harness evidence.
- [x] IND-016 is adopted by Core 01/Core 04 and its authored schemas, source catalog, traceability, verification ownership, and generated topology.
- [x] SL-07 is implemented and all `AC-PORT-*` cases pass with deterministic safe errors, retained v1/v2 compatibility, and final-transaction atomicity.
- [x] Every affected authored contract or harness input is regenerated through Make; generated roots contain no hand edits and all required drift gates pass.
- [x] The applicable focused, boundary, broad, finalize, and full checks pass and their run roots are recorded in the final implementation handoff.

## 13. Iteration 2 — Production Readiness and Legacy Retirement

### 13.1 Authorization, baseline, and execution protocol

- **Authorization:** the user authorized the complete Indicators Production-Readiness and Legacy Retirement Iteration on `2026-08-03`.
- **Starting branch and HEAD:** clean `main` at `15fb90cc48c6877dda5d84239927ec2136087822`.
- **Baseline observed:** `2026-08-03T14:07:08-04:00` with no tracked or untracked worktree changes.
- **Iteration status:** `COMPLETE — production handoff recorded in Section 13.15`.
- **Execution order:** `tracker bootstrap -> SL-09 -> IND-029 -> SL-10 -> SL-11 -> SL-12 -> SL-13 -> SL-14`.
- **Checkpoint gate:** every named workstream is one separately reviewable commit. Its validation evidence, migration notes, run roots, commit SHA, and next action must be recorded here before dependent work begins.
- **Blocker rule:** unknown lifecycle values, duplicate active identities, owner-contract drift, unsafe migration data, or a failed owner acceptance gate blocks dependent work. No compatibility alias or guessed data rewrite may clear a blocker.
- **Generation rule:** authored contracts and harness inputs are changed first; Make-owned generators produce derived artifacts. Generated roots and lockfiles are never hand-edited.
- **Retained-run rule:** retained-run maintenance is recorded only when a successful `RESULTS_DIR` is supplied; otherwise SL-14 records that it was skipped.

Sections 1 through 12 are the immutable Iteration 1 evidence ledger. Iteration 2 adds the work below without reclassifying completed findings, acceptance, or checkpoint history.

### 13.2 Target state and deliberate compatibility posture

The target architecture for this iteration is:

- `records` is the sole authority for Indicator envelope version, timestamps, attribution, and deletion state.
- `indicator_active_identities` is Indicator-owned, transactional, rebuildable coordination state keyed by incident, type, and dedupe key. It is not portable domain state and does not mirror deletion state.
- Indicator subtype storage contains only Indicator-owned fields after the expand, cutover, and contract sequence.
- Portable Indicator source-major-1 rows retain their current schemas and bytes by joining subtype data to the authoritative Records envelope.
- The exact lifecycle vocabulary is `active`, `benign`, `false_positive`, and `retired`; unknown deployed values block contraction rather than receiving aliases.
- Observation provenance is derived from a verified source field and UTF-8 byte span. Ordinary callers cannot select provenance or the reserved `system` origin.
- The retained `Store` is a thin owner facade over focused create, observation, lifecycle, and coordination services.
- Cross-owner consumers receive an immutable Indicator reference containing only record ID, incident ID, type, value kind, display value, normalized value, and dedupe key.

Compatibility retained because it has continuing value:

- existing public Indicator create/query routes, replay behavior, authorization, errors, and valid portable bundle v1/v2 behavior;
- Incident Bundle v1 until its adopted retirement gates are satisfied;
- canonical observations and lifecycle intervals as current-profile domain state;
- `Store`, `StoreDependencies`, `NewStore`, `CreateCommand`, `ValidateCreateCommand`, owner contributions, and the narrow Network Flow transaction participant.

Compatibility deliberately rejected because it adds burden without future value:

- duplicated Indicator envelope state and deletion-dependent identity enforcement;
- speculative producer constructors and caller-selectable audit provenance;
- transport-shaped domain results and mutation payload helpers;
- broad exported consumer DTOs and internal Go compatibility shims;
- redundant characterization wrappers, misleading service-backed test names, and cross-owner physical SQL fixtures;
- Inspector affordances without a registered production handler.

### 13.3 Bootstrap reachability findings

These findings establish the starting classification and are inputs to the exhaustive SL-09 ledger; they do not replace SL-09 call-site and data preflight evidence.

| Finding | Starting evidence | Classification | Iteration action |
| --- | --- | --- | --- |
| `Store` owner facade and typed construction | Workbook, Imports, Network Flow, Revisions, and application assembly use the constructed owner. | Retained contract | Keep one public facade and split internal services in SL-11. |
| Observation and lifecycle write methods | No non-test production caller was found at bootstrap, while adopted Core behavior requires the child domain state. | Required production path | Add secure production routes and real Inspector handlers in SL-12. |
| Public observation origin parser, token constants, and producer constructors | Repository production callers do not require the broad public surface; fixtures and tests dominate use. | Internal-only or removable | Retain only manual ingress and owner-internal stored-data parsing in SL-11. |
| `BuildMutationPayload`, `ImportCreateCommand`, and `CreateImportRowTx` | These expose transport or redundant import shapes rather than an independent owner contract. | Removable dead surface | Move response construction to Workbook and migrate repository callers atomically in SL-11. |
| `IndicatorRecord` | Network Flow consumes a narrow immutable subset while the exported type exposes unrelated source state. | Over-broad retained need | Replace it with the minimal reference in SL-11. |
| Indicator envelope columns | The subtype table mirrors Records version, timestamps, actors, and deletion state; active uniqueness uses the mirrored deletion column. | Duplicated authoritative state | Expand claims in SL-10 and remove mirrors only after the SL-13 writer-drain gate. |
| Incident Bundle v1 and child rows | Adopted contracts and current portable schemas still require valid v1/v2 archives, observations, and intervals. | Retained contract | Lock in SL-09 and preserve through both migrations. |
| Inspector observation and lifecycle metadata | Current bindings point at generic projection/patch surfaces and may render without a real handler. | Inert or misbound UI surface | Bind to production child routes and omit unavailable actions in SL-12. |

### 13.4 Workstream control table

| Order | Workstream | Tracker finding | Scope | Entry gate | Status | Exit evidence | Next action |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 0 | Tracker bootstrap | IND-027 | Append this control plan, baseline, matrices, deployment gates, and completion checklist. | Clean authorized baseline. | COMPLETE | Final `make lint-markdown` passed at `.cartulary/test-results/20260803T180851Z-p977913`; bootstrap checkpoint SHA resolves in the ledger gate. | Record the checkpoint SHA, then begin SL-09. |
| 1 | SL-09 reachability locks and migration preflight | IND-028 | Exported-symbol callers, behavior locks, read-only data classification, and removal ledger. | Bootstrap committed. | COMPLETE | All 58 exports classified; local preflight has no unsafe row; focused route, replay, portability, and v1 evidence plus fast/drift gates pass. | Record the checkpoint SHA, then adopt IND-029. |
| 2 | IND-029 normative production closure | IND-029 | Core owners, staged OpenAPI owner unit, view contracts, acceptance, and traceability. | SL-09 committed with safe dispositions. | COMPLETE | Core requirements and AC-532/533 adopted; Indicator, OpenAPI, View Schema, and frontend view-contract slices plus generation, compatibility, shape, policy, Markdown, and fast gates pass. | SL-10 admitted. |
| 3 | SL-10 expand storage and identity claims | IND-030 | Expand migration, backfill, dual writes, Records envelope reads, rebuild/recovery contract. | IND-029 adopted at `4f009366`; preflight conditions clear. | COMPLETE | Migration 00056, claim lifecycle/rebuild test, concurrency lock, retained portability, recovery classification, generated recovery catalog, and fast suite pass. | SL-11 admitted. |
| 4 | SL-11 semantic facade and dead API retirement | IND-031 | Internal services, typed outcomes, exported-surface allowlist, narrow consumers, explicit database failures. | SL-10 content committed at `60329298`; claim maintenance available. | COMPLETE | Root AST allowlist, Indicator unit/service-backed owners, fast suite, focused Revisions child rollback, Projections owner, and backend boundary pass; retained nested-browser harness failures are classified below. | SL-12 admitted. |
| 5 | SL-12 production observation and lifecycle workflows | IND-032 | Six route families/eight HTTP operations, source-span verification, closed transitions, keyset reads, Inspector handlers, and OpenAPI activation. | IND-029 adopted and SL-11 content committed at `5ce05c8e`. | COMPLETE | Indicator unit/service-backed routes, exact source spans, replay, transitions, history, projection, canonical collaboration, frontend unit/typecheck, Inspector bindings, browser, OpenAPI, generation, boundaries, and fast tests pass. | SL-13 admitted. |
| 6 | SL-13 contract migration and physical dead-state removal | IND-033 | Constraint validation, mirror-column removal, fixed Records joins, reversible reconstruction. | SL-10 through SL-12 content is complete; production application remains gated on an operator-confirmed old-writer drain. | COMPLETE | Dedicated empty/upgrade/Down/Up migration evidence, source-SQL boundary, Indicator and Incident Bundle owners, focused Revisions, affected owner non-browser units, generation/shape/policy/boundary gates, and fast tests pass. | SL-14 admitted; retain the deployment drain gate. |
| 7 | SL-14 test retirement, verification, and handoff | IND-034 | Focused current-contract suite, explicit verification rows, final gates, deployment handoff. | All prior slices committed. | COMPLETE | Pure identity tests, owner fixtures, 23 explicit Indicator rows, affected owner evidence, frontend/browser gates, fast suite, finalize, and full check are recorded in Section 13.15. | Apply the operator-gated deployment sequence; route residual harness debt to the Testing Harness owner. |

### 13.5 Validation and ownership matrix

For every affected owner, run `make task-guide ROLE=module-author OWNER=<owner>` before choosing focused rows. Commands recorded below are requirements, not passing claims, until a checkpoint ledger row supplies an actual successful run root.

| Concern | Primary owner or gate | Required validation |
| --- | --- | --- |
| Indicator identity, child workflows, facade, and exported surface | `module.indicators` | Focused unit and service-backed rows for the changed contract. |
| HTTP admission, replay projection, and mutation envelopes | Workbook | Focused Workbook owner rows plus route integration. |
| Derived row refresh/load/query | Projections | Focused Projection owner rows and storage boundary check. |
| History, rollback, collaboration, and affected record versions | Revisions | Focused rollback/history rows and transaction atomicity. |
| Narrow Indicator consumer reference | Network Flow | Participant contract and service-backed convergence rows. |
| Valid bundle v1/v2 and nonportable claims | Incident Bundles | Focused source-port, round-trip, and atomic import rows. |
| Rebuildable claim state and restore | Recovery | Recovery catalog, rebuild, restore, and validation rows. |
| Inspector bindings and feature discovery | View Schemas | Authored contract validation, frontend unit, and browser handler coverage. |
| Six new route families/eight HTTP operations and public schemas | OpenAPI | Staged owner-unit validation in IND-029; manifest activation, assembly, generated API artifacts, and route conformance atomically with SL-12 handlers. |
| Database expand/contract safety | Migration system | Empty install, upgrade, Down/Up reconstruction, `make migration-drift`. |
| Module ownership and dead API prevention | Boundary policy | Backend/frontend import boundaries and AST exported allowlist. |
| Final repository state | Repository harness | Drift/policy/shape, fast tests, affected service slices, frontend checks, `make agent-finalize`, then `make check`. |

### 13.6 Checkpoint ledger

| Workstream | Status | Commit SHA | Validation evidence | Migration and compatibility note | Next action |
| --- | --- | --- | --- | --- | --- |
| Tracker bootstrap | COMPLETE | `6b505b4c` | Final `make lint-markdown` passed at `.cartulary/test-results/20260803T180851Z-p977913` | Documentation/process only; no product or migration change. | SL-09 admitted. |
| SL-09 | COMPLETE | `a5216501` | Surface `.cartulary/test-results/20260803T181434Z-p993931`; Indicator service `.cartulary/test-results/20260803T181441Z-p994313`; v1 `.cartulary/test-results/20260803T181457Z-p996057`; fast `.cartulary/test-results/20260803T181657Z-p1002795`; final drift/policy/shape/Markdown roots in Section 13.9. | Local database returned zero unsafe rows; every deployment must rerun the recorded queries; no rewrite or migration occurred. | IND-029 admitted. |
| IND-029 | COMPLETE | `4f009366` | Indicator `.cartulary/test-results/20260803T183724Z-p1081186`; OpenAPI `.cartulary/test-results/20260803T183724Z-p1081196`; View Schema `.cartulary/test-results/20260803T183724Z-p1081210`; frontend view contracts `.cartulary/test-results/20260803T184340Z-p1175719`; fast `.cartulary/test-results/20260803T184347Z-p1176589`; final drift/policy/shape/Markdown roots in Section 13.10. | No migration. The complete Indicator OpenAPI unit is staged and must be activated atomically with handlers in SL-12 so the production route-parity contract remains truthful. | SL-10 admitted. |
| SL-10 | COMPLETE | `60329298` | Indicator test `.cartulary/test-results/20260803T185824Z-p1257688`; Indicator service-backed `.cartulary/test-results/20260803T190500Z-p1394816`; Incident Bundle test/service-backed `.cartulary/test-results/20260803T185953Z-p1307484` and `.cartulary/test-results/20260803T190014Z-p1315764`; fast `.cartulary/test-results/20260803T190229Z-p1334968`; final drift/policy/shape roots in Section 13.11. | Additive migration 00056 backfills claims, installs Records-aware `ENABLE ALWAYS` compatibility triggers, and has a Down path that removes only the derived table and bridge functions. No authoritative data is rewritten. | SL-11 admitted. |
| SL-11 | COMPLETE | `5ce05c8e` | Indicator test/service-backed `.cartulary/test-results/20260803T192140Z-p1431035` and `.cartulary/test-results/20260803T192803Z-p1528395`; fast `.cartulary/test-results/20260803T192232Z-p1435684`; Projections `.cartulary/test-results/20260803T192643Z-p1519389`; focused Revisions child rollback `.cartulary/test-results/20260803T192746Z-p1526566`; boundary and Markdown `.cartulary/test-results/20260803T192854Z-p1537499` and `.cartulary/test-results/20260803T192856Z-p1537883`. | No migration or wire-format change. Repository Go callers moved atomically; no compatibility wrappers remain. Existing Indicator idempotency response bytes are preserved internally while Workbook owns HTTP projection. | SL-12 admitted. |
| SL-12 | COMPLETE | `1b4eda62` | Indicator final test/service-backed `.cartulary/test-results/20260803T203930Z-p1948272` and `.cartulary/test-results/20260803T203913Z-p1946271`; focused production routes `.cartulary/test-results/20260803T203854Z-p1944763`; frontend unit/typecheck `.cartulary/test-results/20260803T202210Z-p1808392` and `.cartulary/test-results/20260803T201213Z-p1709530`; browser `.cartulary/test-results/20260803T202420Z-p1846683`; final fast `.cartulary/test-results/20260803T203939Z-p1950284`; drift, shape, policy, boundary, and lint roots in Section 13.13. | Additive route and OpenAPI activation only; no database migration. Exact manual provenance is derived from transaction-visible source bytes; no origin aliases or caller-selected `system`. | SL-13 admitted subject to the documented old-writer drain deployment gate. |
| SL-13 | COMPLETE | `86ad647f` | Indicator test/service-backed `.cartulary/test-results/20260803T210650Z-p2190061` and `.cartulary/test-results/20260803T211311Z-p2271032`; migration Down/Up `.cartulary/test-results/20260803T211254Z-p2269530`; Incident Bundle test/service `.cartulary/test-results/20260803T210735Z-p2195912` and `.cartulary/test-results/20260803T205614Z-p2061670`; focused Revisions `.cartulary/test-results/20260803T205739Z-p2077771`; final fast `.cartulary/test-results/20260803T210904Z-p2210650`; final drift/policy/shape/boundary roots in Section 13.14. | Contract migration 00057 requires old-writer drain. Down reconstructs all mirrors from Records before old-binary restoration. Valid portable bytes remain unchanged. | SL-14 admitted. |
| SL-14 | COMPLETE | `509ee738` | Indicator test/service `.cartulary/test-results/20260803T212527Z-p2303652` and `.cartulary/test-results/20260803T212545Z-p2307211`; Revisions and Incident Bundle fixture rows `.cartulary/test-results/20260803T212644Z-p2309421` and `.cartulary/test-results/20260803T212656Z-p2311284`; frontend unit/typecheck `.cartulary/test-results/20260803T213222Z-p2416147` and `.cartulary/test-results/20260803T213412Z-p2451543`; browser `.cartulary/test-results/20260803T213427Z-p2452089`; fast `.cartulary/test-results/20260803T213839Z-p2507038`; final completion roots in Section 13.15. | Runtime-neutral test and verification retirement. Portable rows and bundle v1/v2 behavior remain unchanged. Contract migration 00057 retains its drain and Down-before-old-binary gates. | Iteration 2 complete; hand off deployment and the separately owned harness residuals. |

### 13.7 Deployment, migration, and rollback gates

1. SL-09 runs read-only preflight against every target environment and records exact counts and dispositions.
2. Unknown lifecycle values, malformed child tuples, ambiguous envelope drift, duplicate active identities, or incompatible idempotency payloads block the expand or contract step that depends on them.
3. SL-10 is an additive expand migration. It backfills and validates claims before the application treats them as ordinary identity coordination state.
4. During the compatibility window, the new binary maintains claims and legacy mirrors transactionally so a rollback to the prior binary remains possible.
5. Recovery rebuilds claims deterministically from Records-authoritative active Indicator identities; backup and Incident Bundle data never treat claims as domain state.
6. SL-13 is a contract migration, not an ordinary rolling upgrade. Operators drain incompatible old writers, confirm the new binary is ready, apply the migration, and start only compatible writers.
7. The SL-13 Down path reconstructs mirror columns from Records before an old binary is restored. Forward repair remains preferred after contract deployment.
8. Valid Indicator portable source-major-1 and bundle v1/v2 bytes remain unchanged across expand, cutover, contract, rebuild, and rollback validation.

### 13.8 Iteration 2 completion checklist

- [x] Tracker bootstrap is committed from the exact clean baseline and records passing Markdown validation.
- [x] SL-09 classifies every exported symbol and every migration preflight condition without guessed repair.
- [x] IND-029 adopts storage authority, identity claims, lifecycle vocabulary, provenance, transition, route, cursor, replay, authorization, error, and response contracts.
- [x] SL-10 establishes transactional active identity claims, Records-based envelope reads, and deterministic recovery rebuild while preserving old-writer compatibility.
- [x] SL-11 removes the approved dead/broad API surface, retains a semantic owner facade, and passes its exported allowlist.
- [x] SL-12 exposes secure production observation and lifecycle workflows with real Inspector handlers and no inert feature controls.
- [x] SL-13 provides the writer-drain-gated physical envelope contraction and proves its reversible reconstruction path.
- [x] SL-14 removes redundant historical tests, publishes explicit current-contract verification rows, and closes every finding.
- [x] Backend and frontend boundaries, generation, artifact policy, JSON shape, Markdown, fast, focused service, frontend, browser, finalize, and full-check gates pass with recorded roots; the public migration target's external PostgreSQL routing failure is classified in Section 13.15 alongside independently passing migration evidence.
- [x] The final tracker records all slice SHAs, deployment and rollback instructions, residual risks, next-owner handoffs, final HEAD, and no unclassified finding.

### 13.9 SL-09 reachability and migration preflight

#### Exported-symbol caller ledger

`internal/modules/indicators/exported_surface_test.go` is the executable exhaustive ledger. It parses every non-test Go file in the root package, includes public methods on exported receiver types, and fails if a symbol is unclassified or a stale classification remains. The following caller ledger covers every symbol in that test; symbols with identical reachability and disposition are grouped without omitting them.

| Exported symbol or exact group | Production callers at the SL-09 baseline | Test callers at the SL-09 baseline | Disposition |
| --- | --- | --- | --- |
| `ViewSchemaID` | Projection, Revision, Workbook, and Import application assembly plus owner providers. | Indicator composition, projection, route, and atomicity tests. | Retained contract. |
| `IndicatorFindOrCreateParticipantV1` | Indicator participant result construction. | Indicator participant and concurrency tests. | Retained narrow participant schema ID. |
| `ErrInvalidCreateRequest` | Workbook admission/error projection and Indicator repositories. | Workbook and Indicator validation tests. | Retained validation contract. |
| `Store`, `StoreDependencies`, `ProjectionPort`, `NewStore` | Server, Workbook, and Import composition; Projections is injected through the narrow port. | Indicator plus affected cross-owner composition/service tests. | Retained owner facade and typed composition. |
| `CreateCommand`, `ValidateCreateCommand` | Workbook maps decoded input to the semantic command and validates before owner transaction work. | Indicator identity/atomicity and Workbook admission tests. | Retained domain admission contract. |
| `IndicatorFindOrCreateParticipantCommand`, `IndicatorFindOrCreateParticipantResult`, `Store.FindOrCreateIndicatorParticipantTx` | Network Flow participant port and transaction coordinator. | Indicator convergence/rollback and Network Flow tests. | Retained narrow transaction participant; result is narrowed in SL-11. |
| `Store.GetActiveIndicatorParticipant`, `Store.GetActiveIndicatorParticipantTx`, `ErrIndicatorNotFound` | Network Flow binding lookup and transaction participant. | Network Flow store tests. | Retained participant lookup; return type is narrowed in SL-11. |
| `IndicatorRecord` | Indicator source persistence plus Network Flow ports/binding. | Indicator and Network Flow tests. | Remove broad export; replace cross-owner use with the immutable minimal reference. |
| `MutationResult` | Indicator create and Workbook mutation adapter. | Indicator, Workbook, Projection, and composition tests. | Remove transport-shaped result; replace with semantic create outcome. |
| `BuildMutationPayload` | Indicator create only. | Workbook adapter tests indirectly cover the payload. | Remove; Workbook owns HTTP/view mutation envelopes. |
| `ImportCreateCommand`, `Store.CreateImportRowTx` | Only the Indicator import facade method value and its owner-internal implementation. | Cross-owner import/projection tests exercise the registered facade. | Remove public alias and method; retain no compatibility wrapper. |
| `NewImportCreateFacade` | Import application assembly. | Import owner-registry tests. | Retained owner contribution factory with internal apply function. |
| `ErrIndicatorObservationNotFound` | Indicator observation repository and workflow only. | Revisions child workflow tests. | Required production-path error for SL-12. |
| `IndicatorCreateValidationError`, `IndicatorCreateValidationError.Error` | Workbook and Network Flow error projection. | Identity/admission tests. | Retained typed domain validation. |
| `IndicatorObservationCreateParams`, `IndicatorObservationResolveParams`, `IndicatorObservationRecord` | No non-Indicator production caller. | Indicator and Revisions child tests. | Required production path; replace caller-controlled fields with route-safe commands in SL-11/SL-12. |
| `Store.CreateIndicatorObservation`, `Store.ResolveIndicatorObservation` | No non-Indicator production caller. | Indicator and Revisions child tests. | Required production path; wire secure routes in SL-12. |
| `IndicatorLifecycleAppendParams`, `IndicatorLifecycleIntervalRecord`, `Store.AppendIndicatorLifecycleInterval` | No non-Indicator production caller. | Indicator and Revisions child tests. | Required production path; adopt enum/route policy before wiring in SL-12. |
| `ObservationOrigin`, `ErrInvalidObservationOrigin`, `ParseObservationOrigin` | Root owner validation/repository only; portability uses the owner-internal registry directly. | Origin registry and repository tests. | Move completely behind the owner boundary in SL-11. |
| `ManualEntryObservationOrigin`, `ClipboardPasteObservationOrigin`, `CSVImportObservationOrigin`, `XLSXImportObservationOrigin`, `APIImportObservationOrigin`, `ExtractionObservationOrigin`, `SystemObservationOrigin` | No external production caller. | Only `manual_entry` has domain-fixture callers; the others are origin-surface tests. | Remove all public token constants; storage parsing remains internal. |
| `ObservationProducerContext` | Root owner method parameter only. | Indicator origin/child tests. | Internal-only candidate; route command derives manual provenance. |
| `ManualEntryObservationProducer` | No live production caller. | Indicator and Revisions child fixtures. | Carry forward only as the temporary manual ingress until SL-12 replaces it with verified source-span admission. |
| `ClipboardPasteObservationProducer`, `CSVImportObservationProducer`, `XLSXImportObservationProducer`, `APIImportObservationProducer`, `ExtractionObservationProducer` | No production caller. | Origin-surface tests only. | Remove speculative APIs in SL-11. |
| `ProjectionContribution`, `NewProjectionContribution`, `ProjectionContribution.Source`, `ProjectionContribution.QuerySurfaces` | Projection application assembly and generic provider catalogs. | Provider encapsulation and query-surface tests. | Retained owner contribution. |
| `NewRevisionContribution` | Revision application assembly. | Provider encapsulation and rollback tests. | Retained owner contribution. |
| `RecoveryStateContribution` | Recovery application catalog. | Recovery catalog and restore tests. | Retained owner contribution; claims are added as rebuildable state in SL-10. |
| `IncidentBundleContribution`, `NewIncidentBundleContribution` | Incident portability application assembly. | Indicator portability and Incident Bundle tests. | Retained owner contribution and valid v1/v2 support. |

The executable classification contains 58 exact symbol entries: 27 retained contracts, 10 required production-path entries, 4 internal-only candidates, and 17 removable dead-surface entries. The focused row passed at `.cartulary/test-results/20260803T181434Z-p993931`.

#### Behavior locks

- The Indicator public create/query route test now asserts `201` for first create, `200` with the byte-equivalent committed data projection for exact replay, and `409 client_txn_conflict` for a divergent request using the same transaction identity.
- The same route test retains projection readback and rebuild parity.
- The portable-row characterization retains exact fields, explicit nulls, ordering, timestamps, deterministic bytes, and descriptor support for bundle versions 1 and 2.
- The focused Indicator route and portability rows passed together at `.cartulary/test-results/20260803T181441Z-p994313`.
- The retained Incident Bundle v1 lossless translation/import row passed at `.cartulary/test-results/20260803T181457Z-p996057`.

#### Read-only preflight queries and disposition

Environment: the local development PostgreSQL service from `docker-compose.dev.yml`, database `cartulary`, observed healthy on `2026-08-03`. It contained no Indicator, observation, lifecycle, or Indicator route-idempotency rows. The following queries are the exact reusable deployment gates; operators must execute them against every target database before SL-10 backfill and again before SL-13 contraction.

Lifecycle vocabulary:

```sql
SELECT lifecycle_state, count(*) AS row_count
FROM indicator_state_intervals
GROUP BY lifecycle_state
ORDER BY lifecycle_state;
```

Records/subtype envelope drift:

```sql
SELECT
  count(*) AS indicator_rows,
  count(*) FILTER (WHERE r.record_id IS NULL) AS missing_envelopes,
  count(*) FILTER (WHERE r.record_type IS DISTINCT FROM 'indicator') AS wrong_record_type,
  count(*) FILTER (WHERE i.incident_id IS DISTINCT FROM r.incident_id) AS incident_drift,
  count(*) FILTER (WHERE i.row_version IS DISTINCT FROM r.row_version) AS version_drift,
  count(*) FILTER (
    WHERE i.created_at IS DISTINCT FROM r.created_at
       OR i.updated_at IS DISTINCT FROM r.updated_at
  ) AS timestamp_drift,
  count(*) FILTER (
    WHERE i.created_by_user_id IS DISTINCT FROM r.created_by_user_id
       OR i.updated_by_user_id IS DISTINCT FROM r.updated_by_user_id
  ) AS actor_drift,
  count(*) FILTER (
    WHERE i.deleted_at IS DISTINCT FROM r.deleted_at
       OR i.deleted_by_user_id IS DISTINCT FROM r.deleted_by_user_id
  ) AS deletion_drift
FROM indicators i
LEFT JOIN records r ON r.record_id = i.record_id;
```

Records-authoritative active identity duplicates:

```sql
SELECT incident_id, indicator_type, dedupe_key, count(*) AS active_count
FROM indicators i
JOIN records r ON r.record_id = i.record_id
WHERE r.deleted_at IS NULL
GROUP BY incident_id, indicator_type, dedupe_key
HAVING count(*) > 1
ORDER BY incident_id, indicator_type, dedupe_key;
```

Observation tuple, origin, and reference classification:

```sql
SELECT
  resolution_status,
  resolved_indicator_record_id IS NOT NULL AS has_target,
  resolved_by_user_id IS NOT NULL AS has_actor,
  resolved_at IS NOT NULL AS has_time,
  resolution_method IS NOT NULL AS has_method,
  count(*) AS row_count
FROM indicator_observations
GROUP BY resolution_status, has_target, has_actor, has_time, has_method
ORDER BY resolution_status, has_target, has_actor, has_time, has_method;

SELECT origin_kind, count(*) AS row_count
FROM indicator_observations
GROUP BY origin_kind
ORDER BY origin_kind;

SELECT
  count(*) FILTER (
    WHERE o.row_version <= 0
       OR o.source_field_key = ''
       OR o.origin_locator = ''
       OR o.observed_text = ''
  ) AS malformed_observations,
  count(*) FILTER (
    WHERE source_record.record_id IS NULL
       OR (
         o.resolved_indicator_record_id IS NOT NULL
         AND (
           resolved_record.record_id IS NULL
           OR resolved_record.incident_id IS DISTINCT FROM o.incident_id
         )
       )
  ) AS cross_incident_or_missing_refs
FROM indicator_observations o
LEFT JOIN records source_record
  ON source_record.record_id = o.source_record_id
 AND source_record.incident_id = o.incident_id
LEFT JOIN records resolved_record
  ON resolved_record.record_id = o.resolved_indicator_record_id;
```

Lifecycle interval classification:

```sql
SELECT count(*) AS malformed_intervals
FROM indicator_state_intervals interval
LEFT JOIN records indicator_record
  ON indicator_record.record_id = interval.indicator_record_id
WHERE interval.row_version <= 0
   OR interval.valid_to < interval.valid_from
   OR interval.confidence < 0
   OR interval.confidence > 100
   OR jsonb_typeof(interval.support_refs) IS DISTINCT FROM 'array'
   OR indicator_record.record_id IS NULL
   OR indicator_record.incident_id IS DISTINCT FROM interval.incident_id;
```

Indicator create idempotency payload classification:

```sql
SELECT
  count(*) AS indicator_idempotency_rows,
  count(*) FILTER (
    WHERE jsonb_typeof(response_json) IS DISTINCT FROM 'object'
       OR response_json->>'view_schema_id'
          IS DISTINCT FROM 'cartulary.view.indicators.v1'
       OR jsonb_typeof(response_json->'row') IS DISTINCT FROM 'object'
       OR coalesce(response_json->'row'->>'record_id', '') = ''
       OR coalesce(response_json->>'change_set_id', '') = ''
       OR status_code NOT IN (200, 201)
  ) AS malformed_payloads
FROM route_idempotency
WHERE route_key = 'indicators.rows.create';
```

All returned counts were zero and both vocabulary classifications returned no rows. PostgreSQL text cannot store NUL bytes, so NUL input remains an admission/portable-decoding concern rather than a persisted-data classification. No disposable fixture required correction in this slice. No production database was in task scope, so the identical operator query gate remains mandatory for deployment and is not represented as already passed.

Disposition rules are fail closed:

- only `active`, `benign`, `false_positive`, and `retired` may proceed to contraction; any other lifecycle value requires an explicit operator-authored mapping;
- Records wins every envelope disagreement, but any disagreement must be reported before a repair writes data;
- any Records-authoritative duplicate active identity blocks claim backfill until an operator resolves which record remains active;
- malformed observation/lifecycle tuples and idempotency payloads block their dependent migration or replay cutover; no alias, field synthesis, conflict-ignore, or guessed rewrite is authorized.

#### SL-09 validation checkpoint

- `make generate` passed at `.cartulary/test-results/20260803T181321Z-p987028` after adding the authored verification row; only the Make-generated topology projection changed.
- The exported-surface row passed at `.cartulary/test-results/20260803T181434Z-p993931`.
- Indicator route/replay and portable-row service evidence passed at `.cartulary/test-results/20260803T181441Z-p994313`.
- Retained bundle v1 translation/import passed at `.cartulary/test-results/20260803T181457Z-p996057`.
- `make generate-drift` passed at `.cartulary/test-results/20260803T181637Z-p997824`.
- `make generated-artifact-policy-check` passed at `.cartulary/test-results/20260803T181643Z-p1000344`.
- `make json-shape-check` passed at `.cartulary/test-results/20260803T181644Z-p1000742`.
- Final `make lint-markdown` passed at `.cartulary/test-results/20260803T181924Z-p1051148`.
- `make test-fast` passed 346 of 346 units at `.cartulary/test-results/20260803T181657Z-p1002795`.
- No migration ran and no data changed. The sole local preflight query error was the first diagnostic attempt to construct a PostgreSQL NUL character; PostgreSQL rejected the character before scanning data, the corrected NUL-free read-only query set ran successfully, and text storage itself cannot contain NUL.
- SL-09 has no unclassified repository or local-data condition. Production deployment remains guarded by the exact recorded operator queries rather than an unsupported passing claim.

### 13.10 IND-029 normative production closure

#### Adopted owner language and projections

IND-029 adopted one closed policy across the normative owners rather than allowing the later implementation slices to invent route or storage behavior:

- Core 01 now owns `REQ-01-652` through `REQ-01-654`: exact Indicator child-route request/replay/result rules, Records-only envelope authority, rebuildable active identity claims, and actor/record/route/limit-bound keyset pagination.
- Core 02 now owns `REQ-02-263` and `REQ-02-264`: the exact `active | benign | false_positive | retired` lifecycle vocabulary, interval semantics, source-span admission, server-derived manual provenance, and closed resolve/dismiss/restore transitions.
- Core 03 now owns `REQ-03-306`: Indicator and Timeline Inspector discovery binds to the real owner route families, adds `indicator.lifecycle.manage`, preserves selected-row behavior, and omits actions without registered handlers.
- Core 04 now owns `REQ-04-150`, `AC-532`, and `AC-533`: authorization and safe-failure precedence, atomic effects, six route families/eight HTTP operations, active-claim expand/contract behavior, and migration/recovery proof.
- The forward and reverse traceability tables cover every new requirement and both acceptance criteria.
- The error projection adds exactly `indicator_source_record_not_found`, `indicator_not_found`, `indicator_observation_not_found`, and `resolved_indicator_not_found`; generated Go and TypeScript error artifacts were regenerated through Make.
- Indicator verification declares focused production-child-workflow and storage-contraction claims. SL-14 remains responsible for assigning final explicit execution rows once the implementations exist.

The Indicator and Timeline view contracts now use the closed route kinds `indicator_observations` and `indicator_lifecycle` with owner tokens `indicator_observations_route` and `indicator_lifecycle_route`. Go validation, OpenAPI view-schema enums, generated protocol types, the TypeScript view-contract owner, exact feature ledgers, and their tests carry the same vocabulary. This is discovery policy only; SL-12 must still register real handlers and omit any control whose handler is unavailable.

#### OpenAPI activation boundary

The complete `module.indicators` OpenAPI owner unit is staged at `contracts/openapi-source/planned/module.indicators/openapi.json`. It contains six path families, eight HTTP operations, fifteen closed owner schemas, exact mutation status/replay shapes, the two list orderings, and no caller-selectable provenance. The unit carries `x-cartulary-activation='SL-12'` and is intentionally absent from the assembly manifest until the runtime handlers exist.

This staging is required by the repository's production route-parity contract. The first assembled attempt correctly failed because the eight declared operations had no runtime handlers. Registering placeholder or `501` handlers would publish a false production capability, while weakening parity would reduce long-term contract safety. SL-12 must atomically move the unit into the owner root, remove the staging marker, add it to the manifest and release change set, regenerate the public contract, register all handlers, and pass runtime/OpenAPI parity in one commit. Storage work in SL-10 and facade work in SL-11 do not depend on route publication.

#### Validation and failure accounting

Passing evidence:

- `make test-slice OWNER=module.indicators`: 17 of 17 at `.cartulary/test-results/20260803T183724Z-p1081186`.
- `make test-slice OWNER=platform.openapi`: 5 of 5 at `.cartulary/test-results/20260803T183724Z-p1081196`.
- `make test-slice OWNER=platform.viewschema`: 3 of 3 at `.cartulary/test-results/20260803T183724Z-p1081210`.
- `make test-slice OWNER=package.view_contracts`: 5 of 5 at `.cartulary/test-results/20260803T184340Z-p1175719`.
- `make generate`: passed at `.cartulary/test-results/20260803T183712Z-p1078881`.
- `make generate-drift`: passed at `.cartulary/test-results/20260803T183744Z-p1089539`.
- `make generated-artifact-policy-check`: passed at `.cartulary/test-results/20260803T183744Z-p1089560`.
- `make json-shape-check`: passed at `.cartulary/test-results/20260803T183744Z-p1089537`.
- `make openapi-compatibility-check`: passed at `.cartulary/test-results/20260803T183744Z-p1089619`.
- `make lint-markdown`: passed at `.cartulary/test-results/20260803T184732Z-p1225154` after the completed checkpoint update.
- Final `make generate-drift`, `make generated-artifact-policy-check`, and `make json-shape-check` passed at `.cartulary/test-results/20260803T184732Z-p1224868`, `.cartulary/test-results/20260803T184732Z-p1224892`, and `.cartulary/test-results/20260803T184732Z-p1224916`.
- `make test-fast`: 346 of 346 at `.cartulary/test-results/20260803T184347Z-p1176589`.

Resolved failure evidence is retained rather than discarded:

- Initial generation at `.cartulary/test-results/20260803T183033Z-p1057836` failed because the OpenAPI release change set did not yet classify the new semantic changes; the reviewed view-schema enum changes are now exact and compatibility passes.
- The initially assembled route contract caused Indicator and OpenAPI focused failures at `.cartulary/test-results/20260803T183419Z-p1068761` and `.cartulary/test-results/20260803T183419Z-p1068769`: route parity found all eight missing handlers, and a completeness fixture still expected the prior shared-parameter count. This exposed the unsafe publication order and led to the explicit SL-12 activation gate instead of placeholder runtime behavior.
- Generation at `.cartulary/test-results/20260803T183637Z-p1077964` rejected an orphan owner unit after manifest removal. Moving the unit into the explicit planned area resolved the orphan without weakening assembly closure.
- Fast runs at `.cartulary/test-results/20260803T183813Z-p1095060` and `.cartulary/test-results/20260803T184054Z-p1152142` reported frontend `missing_selector_result` preflight failures. The retained underlying Vitest output identified stale TypeScript route-kind/owner allowlists, not nondeterministic product behavior. The allowlists and exact Indicator feature ledger were repaired; the first focused frontend retry at `.cartulary/test-results/20260803T184314Z-p1174755` then exposed and localized the missing lifecycle feature count, and the final focused and fast runs pass.

IND-029 changes no database schema or persisted data. Existing create/query routes and valid bundle v1/v2 behavior remain active and unchanged. Its content checkpoint is `4f009366`; this ledger gate admits SL-10.

### 13.11 SL-10 expand storage and active identity claims

#### Storage cutover design

Migration `00056_indicator_active_identities_expand.sql` adds the Indicator-owned `indicator_active_identities` claim table with canonical identity as its primary key and exactly one claimed identity per Indicator record. The table contains no deletion or envelope mirrors. Its backfill joins `indicators` to `records`, admits only Records envelopes whose type is `indicator` and whose `deleted_at` is null, and fails rather than choosing a winner when active identities are duplicated.

Two owner-defined `ENABLE ALWAYS` triggers provide the expand-window compatibility bridge:

- the Indicator trigger rekeys or removes a claim whenever subtype identity changes or a subtype row is removed;
- the Records trigger creates or removes a claim from the authoritative record type and deletion state;
- both triggers recompute from a Records/Indicator join, so an old writer that still updates both envelope copies remains compatible while new reads no longer trust the Indicator deletion mirror;
- `ENABLE ALWAYS` permits recovery to load `indicators` and `records` in either order while ordinary foreign-key triggers are disabled.

The ordinary dedupe lookup now begins at `indicator_active_identities` and locks the claim, subtype row, and Records envelope. Create, Import, Network Flow find-or-create, delete/restore, row rollback, and Incident Bundle apply already mutate either the Records envelope or Indicator identity in one caller-owned transaction, so the owner triggers make each path claim-consistent without a second application-level identity implementation.

`rebuild_indicator_active_identities()` takes stable source locks, replaces the derived rows in deterministic identity order, and returns the rebuilt count. `indicator_active_identities_are_valid()` performs a symmetric-difference comparison against Records-authoritative expected state. Recovery classifies the claim table as `excluded_rebuildable` under `indicators.restore_active_identities.v1`; it is absent from authoritative snapshots and Incident Bundles. The recovery catalog now classifies 110 authored tables while retaining 82 required authoritative tables.

Indicator portable export now obtains row version, timestamps, actor IDs, and deletion state exclusively from `records`. Portable attribution lookup likewise resolves the emitted envelope actors from Records. The source-major-1 row shape and valid bundle v1/v2 bytes remain unchanged, and apply continues dual-writing the temporary mirrors until SL-13.

#### Migration and rollback notes

- The Up migration is additive. It creates and backfills derived state, installs unvalidated ownership FKs and text hardening checks, and does not rewrite an authoritative row.
- The old `indicators_incident_dedupe_unique_idx` and all mirror columns remain during this compatibility window. They are removed only by the SL-13 contract migration after the old-writer drain gate.
- The Down migration removes the validation/rebuild functions, compatibility triggers, and claim table. It leaves Indicators, Records, and every authoritative child row unchanged, so the prior binary can resume using its existing partial unique index.
- Deployment must rerun the Section 13.9 duplicate/drift preflight before Up. Duplicate Records-active identities remain a hard stop.

#### Validation and failure accounting

Passing evidence:

- `make test-slice OWNER=module.indicators`: 17 of 17 at `.cartulary/test-results/20260803T185824Z-p1257688`.
- `make service-backed-test-slice OWNER=module.indicators`: 10 of 10 at `.cartulary/test-results/20260803T190500Z-p1394816`. This includes empty-head migration, claim creation, Records-authoritative deletion, identity reuse, restore conflict, deterministic validation/rebuild, recovery trigger mode, transaction rollback, and concurrent convergence.
- `make test-slice OWNER=module.incidentbundles`: 26 of 26 at `.cartulary/test-results/20260803T185953Z-p1307484`.
- `make service-backed-test-slice OWNER=module.incidentbundles`: 15 of 15 at `.cartulary/test-results/20260803T190014Z-p1315764`; retained v1/v2 apply, validation, and round trips pass with Records-owned envelope reads.
- `make generate`: passed at `.cartulary/test-results/20260803T185724Z-p1242017` and regenerated only Make-owned SQL and recovery projections.
- `make generate-drift`: passed at `.cartulary/test-results/20260803T190510Z-p1396353`.
- `make generated-artifact-policy-check`: passed at `.cartulary/test-results/20260803T190517Z-p1398876`.
- `make json-shape-check`: passed at `.cartulary/test-results/20260803T190518Z-p1399268`.
- `make lint-markdown`: passed at `.cartulary/test-results/20260803T190630Z-p1400158` after the completed checkpoint update.
- `make test-fast`: 346 of 346 at `.cartulary/test-results/20260803T190229Z-p1334968`.

Retained failure evidence and disposition:

- The first `make migration-drift` run at `.cartulary/test-results/20260803T185617Z-p1234986` correctly rejected the new migration until its authored history-manifest entry was added.
- The retry at `.cartulary/test-results/20260803T185650Z-p1238264` passed the 56-file history and input checks, then could not bind local port 5432 because the unrelated Compose project `repo` from `/home/jochi/code/cartulary-wf01.kD7A0s/repo` owns that port. No container was stopped or modified. Current-head service-backed tests independently replayed all 56 migrations successfully in isolated PostgreSQL containers. The final SL-14 migration gate must rerun `make migration-drift` when the external port owner is absent.
- Recovery owner test/service-backed runs at `.cartulary/test-results/20260803T185832Z-p1259612` and `.cartulary/test-results/20260803T185926Z-p1288935`, and Revisions owner runs at `.cartulary/test-results/20260803T190038Z-p1317545` and `.cartulary/test-results/20260803T190112Z-p1329215`, failed only in nested browser rows because `start-web-e2e.sh` received no `OWNER` from the slice harness. All non-browser units in those runs passed. This is retained harness-routing evidence, not a product failure; final owner/browser gates remain open.
- The first generation run at `.cartulary/test-results/20260803T185700Z-p1240540` found the recovery generator's explicit 109-table cardinality. The authored cardinality was advanced to 110 while the required-table count remained 82, and the final generation/drift gates pass.
- The first shape run at `.cartulary/test-results/20260803T190141Z-p1333703` correctly required ownership for the new objects and exposed `UPDATE OF` as a false table token in the SQL scanner. The Indicator ownership pattern now covers every claim object, and the triggers use semantically equivalent all-update admission so the authored scanner and database agree.

SL-10 has no unclassified data or implementation finding. Its content checkpoint is `60329298`; this ledger gate admits SL-11.

### 13.12 SL-11 semantic facade and dead API retirement

#### Owner boundary and service structure

The public `Store` remains the single Indicator owner facade, but its workflow implementation is now separated into create, observation, and lifecycle services. Fixed SQL remains confined to source-specific repositories, and the facade retains transaction, revision, idempotency, and projection coordination only. No second public owner facade or compatibility wrapper was introduced.

Indicator create now returns a typed `CreateOutcome` and semantic `CreateResult`. Workbook maps those outcomes to HTTP status and constructs the public mutation envelope. The Indicator owner still writes the exact existing status and response payload to route idempotency storage so valid replay bytes and wire behavior remain stable. `BuildMutationPayload`, the exported import command alias, and `Store.CreateImportRowTx` were removed; the owner-created Imports facade binds its transaction callback without exporting the storage operation.

The former full `IndicatorRecord` consumer DTO was replaced by `IndicatorReference`, which contains only immutable identity fields needed by Network Flow: record and incident IDs, type, value kind, display and normalized values, and dedupe key. Network Flow validation and binding storage now depend on this reference and cannot inspect Indicator envelope, deletion, representation, or attribution state. Active-state admission remains the Indicator owner's responsibility.

Observation-origin tokens and parsing now exist only in the owner-internal registry. All speculative clipboard, CSV, XLSX, API, extraction, and trusted-system producer constructors were deleted. The only retained owner ingress is manual observation creation; it assigns `manual_entry` internally and uses server-owned time and fixed mutation sources. Resolution and lifecycle mutation sources and clocks are likewise server-owned. SL-12 replaces the remaining manual text/locator parameters with verified source-span commands at the HTTP boundary.

`exported_surface_test.go` is now a strict AST allowlist rather than a descriptive inventory. A new root export fails the owner test until a contract decision explicitly admits it. The allowlist preserves the typed store construction, create command/validation, owner contributions, production child workflow types, and narrow Network Flow participant contracts.

#### Explicit failure hardening

- Required PostgreSQL UUID values are checked for null and converted without panic; optional UUIDs use their fixed-width representation without `uuid.Must`.
- Indicator subtype updates and row rollback require exactly one affected row and return explicit stale/missing failures otherwise.
- Lifecycle support references return a JSON encoding error instead of discarding it.
- Projection-row equality uses semantic Go equality and no longer discards JSON marshal failures.
- Server-owned child timestamps are normalized to PostgreSQL microsecond precision before both persistence and revision capture. This keeps rollback snapshots byte-coherent with transaction-visible storage.

#### Validation and failure accounting

Passing evidence:

- `make test-slice OWNER=module.indicators`: 17 of 17 at `.cartulary/test-results/20260803T192140Z-p1431035`.
- `make service-backed-test-slice OWNER=module.indicators`: 10 of 10 at `.cartulary/test-results/20260803T192803Z-p1528395`.
- `make test-fast`: 346 of 346 at `.cartulary/test-results/20260803T192232Z-p1435684`.
- `make test-slice OWNER=module.projections`: 10 of 10 at `.cartulary/test-results/20260803T192643Z-p1519389`.
- The focused Revisions Indicator-child rollback row passed three of three units at `.cartulary/test-results/20260803T192746Z-p1526566` after timestamp precision was made storage-coherent.
- `make backend-module-boundary-check` passed at `.cartulary/test-results/20260803T192854Z-p1537499`.
- `make lint-markdown` passed before and after this ledger update at `.cartulary/test-results/20260803T192856Z-p1537883` and `.cartulary/test-results/20260803T193014Z-p1539906`.
- Module-author task guidance was consulted for Indicators, Workbook, Imports, Network Flow (`module.networkflow`), Revisions, and Projections before their focused runs.

Retained failure evidence and disposition:

- Initial Indicator runs at `.cartulary/test-results/20260803T191528Z-p1409181`, `.cartulary/test-results/20260803T191658Z-p1412710`, and `.cartulary/test-results/20260803T192013Z-p1419268` exposed stale type references and test imports after intentional API removal. Runs at `.cartulary/test-results/20260803T192041Z-p1424565` and `.cartulary/test-results/20260803T192117Z-p1427906` then exposed tests that still expected caller-supplied observation clocks and nanosecond equality across PostgreSQL. The tests now assert server-owned persisted instants and the final owner slice passes.
- Workbook, Imports, Network Flow, and Revisions owner runs at `.cartulary/test-results/20260803T192452Z-p1497383`, `.cartulary/test-results/20260803T192530Z-p1504301`, `.cartulary/test-results/20260803T192555Z-p1508167`, and `.cartulary/test-results/20260803T192621Z-p1514617` reached their non-browser units but failed nested browser rows because `start-web-e2e.sh` received no `OWNER` from the slice harness. Network Flow service-backed evidence at `.cartulary/test-results/20260803T192828Z-p1532902` has the same classified harness failure. This is the existing owner-routing defect already recorded in SL-10; no harness policy was weakened.
- The Revisions run also exposed real stale-target failures caused by nanosecond server timestamps differing from PostgreSQL microsecond storage. The implementation now normalizes once before persistence and revision capture, and the exact failed owner row passes at `.cartulary/test-results/20260803T192746Z-p1526566`.

SL-11 changes no schema, persisted identity, public HTTP route, authorization rule, or portable bytes. Internal repository callers move with the defining commit and no shim remains. Its content checkpoint is `5ce05c8e`; this ledger gate admits SL-12.

### 13.13 SL-12 production observation and lifecycle workflows

#### Production owner workflows

The Indicator owner now publishes all six adopted child-route families and eight HTTP operations. The application runtime registers the owner router, and the previously staged `module.indicators` OpenAPI unit is now an assembled owner contract with generated Go and TypeScript projections. Route parity therefore describes live behavior rather than a future capability.

Manual observation creation accepts a source field and UTF-8 byte span. The owner refreshes and reads the transaction-visible source record through a narrow source-text port, verifies the source record, view schema, field, base row version, UTF-8 boundaries, and selected range, and derives the exact `observed_text`, locator, and `manual_entry` origin. A final audit found that the repository insert path still applied line normalization after verification; that normalization was removed and the route test now proves preservation of the exact selected bytes, including surrounding spaces and multibyte text. No route accepts an origin token or trusted-system capability.

Observation resolution is a closed state machine: resolve admits unresolved or a different resolved target; dismiss admits unresolved or resolved; restore admits only dismissed. Same-state and other illegal transitions return the adopted `409 illegal_transition` response. The lifecycle append path admits exactly `active`, `benign`, `false_positive`, and `retired`, validates interval bounds and typed support references, and assigns actor and timestamp inside the owner.

Mutation replay is checked before base-version concurrency. First create and append responses return `201`; transition actions and exact replay return `200`. Each result contains the child resource, change-set ID, replay state, and deterministically sorted affected record IDs and versions. Affected first-class records are advanced, revised, and projection-refreshed in stable ID order. The existing transactional Revisions appender already emits the canonical Collaboration intent for each affected record; an attempted second Indicator-specific publication path produced a duplicate intent-key failure and was removed rather than creating competing ownership.

Observation and lifecycle list repositories use record-bound and actor-bound keyset cursors with the adopted descending created/valid-from and stable-ID tie breakers. Ordinary reads exclude tombstones; revision history and portability retain them. Indicator and Timeline Inspector actions now call these owner routes through a narrow frontend workflow port. Controls without a registered handler are omitted, so the shell no longer advertises inert observation or lifecycle behavior.

#### Compatibility and migration notes

- The six route families and their Inspector bindings are additive. Existing Indicator create/query routes, idempotency response bytes, authorization, valid portability, observations, and lifecycle rows remain compatible.
- OpenAPI activation moved the authored Indicator unit from its planned staging root into the production owner manifest and release change set. Generated projections were produced through Make.
- SL-12 adds no database migration and does not alter portable bytes. It introduces no origin alias, caller-selected `system` path, speculative producer API, or placeholder handler.
- The frontend Indicator API client test exists in the content checkpoint, but the preexisting verification catalog does not yet select it explicitly. The production child-route helper also executes under the existing Indicator route integration test. SL-14 must assign both current-contract tests explicit verification rows rather than relying on transitive coverage.

#### Validation and failure accounting

Passing evidence:

- Final `make test-slice OWNER=module.indicators`: 17 of 17 at `.cartulary/test-results/20260803T203930Z-p1948272`.
- Final `make service-backed-test-slice OWNER=module.indicators`: 10 of 10 at `.cartulary/test-results/20260803T203913Z-p1946271`.
- Focused production child-route service-backed evidence: three of three at `.cartulary/test-results/20260803T203854Z-p1944763`.
- `make frontend-typecheck` passed at `.cartulary/test-results/20260803T201213Z-p1709530`.
- `make frontend-unit` passed 357 of 357 at `.cartulary/test-results/20260803T202210Z-p1808392`.
- Focused Inspector and source-ownership rows passed at `.cartulary/test-results/20260803T201715Z-p1752972` and `.cartulary/test-results/20260803T201830Z-p1757448`.
- `make browser-e2e-webserver-backed` passed 62 of 62 at `.cartulary/test-results/20260803T202420Z-p1846683`.
- `make backend-module-boundary-check` and `make frontend-import-boundary-check` passed at `.cartulary/test-results/20260803T202802Z-p1900514` and `.cartulary/test-results/20260803T202804Z-p1900895`.
- `make generate-drift`, `make json-shape-check`, and `make generated-artifact-policy-check` passed at `.cartulary/test-results/20260803T202806Z-p1901207`, `.cartulary/test-results/20260803T202813Z-p1903733`, and `.cartulary/test-results/20260803T202815Z-p1904130`.
- Final `make lint-biome` passed at `.cartulary/test-results/20260803T204225Z-p2012538`.
- `make lint-markdown` passed after the completed checkpoint update at `.cartulary/test-results/20260803T204444Z-p2013648`.
- Final `make test-fast` passed 346 of 346 at `.cartulary/test-results/20260803T203939Z-p1950284`.
- The final server build after the provenance and collaboration audit passed at `.cartulary/test-results/20260803T203555Z-p1926207`.

Retained failure evidence and disposition:

- The first fast run at `.cartulary/test-results/20260803T200123Z-p1638373` passed 345 of 346 and exposed a stale OpenAPI assembly assertion that expected eight shared path parameters. The activated owner unit has the exact twelve-parameter inventory, and the final fast run passes.
- Frontend typecheck at `.cartulary/test-results/20260803T201142Z-p1708676` exposed a nullable Timeline row version. The workflow is now mounted only for a committed source row with a concrete base version.
- Frontend unit evidence at `.cartulary/test-results/20260803T201228Z-p1710011` exposed an obsolete test expecting an inert mark-reviewed button and incomplete ownership for the new client. The owner manifest and test now require inert controls to be absent and real observation actions to be visible. The first focused ownership retry at `.cartulary/test-results/20260803T201722Z-p1753457` then found manifest ordering; the authored entry is sorted and the final ownership row passes.
- Route attempts at `.cartulary/test-results/20260803T203433Z-p1920542` and `.cartulary/test-results/20260803T203613Z-p1936856` tested an explicit Indicator Collaboration port. The first lacked a view schema and the second proved that Revisions already emitted the same canonical intent. The redundant port and adapter were removed completely. A subsequent count failure at `.cartulary/test-results/20260803T203814Z-p1942536` included the ordinary Indicator-create intent; the assertion now scopes its evidence to child-workflow revision sources and passes.

SL-12 has no unclassified runtime, compatibility, or migration finding. Its content checkpoint is `1b4eda62`; this ledger gate admits SL-13 only under the old-writer drain and preflight requirements in Sections 13.7 and 13.9.

### 13.14 SL-13 contract migration and physical dead-state removal

#### Records-only storage contract

Migration `00057_indicator_envelope_contract.sql` is the explicit contract half of the Indicator storage cutover. Its Up path takes stable locks and refuses to discard the legacy mirrors when any Indicator lacks an exact `record_type='indicator'` Records envelope, when row version, timestamps, actors, or deletion tuples drift, or when active identity claims do not match Records-authoritative state. It validates the expand migration's previously unvalidated claim constraints before contraction.

The migration drops the Indicator subtype's row version, creation/update timestamps, creation/update actors, and deletion tuple together with the three actor foreign keys and the deletion-dependent dedupe and normalized-value indexes. The active claim primary key remains the sole active canonical identity exclusion. The normalized-value index is rebuilt over subtype fields without pretending to encode activeness; callers join Records for deletion state. Generated SQL models now expose only the eleven Indicator-owned subtype columns.

Ordinary create, enrichment, Imports, Network Flow find-or-create, rollback, delete/restore, and Incident Bundle apply no longer write an Indicator envelope mirror. Delete/restore's source contribution is intentionally a no-op because generic Revisions coordination updates the Records envelope. Rollback updates only canonical subtype fields while generic coordination owns version and deletion restoration. Portable import inserts only subtype fields, while export and validation continue joining Records. A production AST boundary test rejects future Indicator SQL that reads or writes a removed mirror.

The claim triggers remain Indicator-owned coordination. They now avoid delete/reinsert churn for unrelated Records version advances and source enrichment, but still create, release, and rekey claims on source identity or Records activeness changes. The deterministic validation and rebuild functions remain available and recovery continues to classify the claim table as excluded, rebuildable state.

#### Storage hardening and reversibility

The contract migration validates exact Indicator types, exact value kinds, the IP/atomic relation, canonical lowercase SHA-256 dedupe keys, nonempty subtype fields, hash pairing/format, positive child row versions, the seven observation origins, exact observation candidate and resolution tuples, the four lifecycle tokens, time/confidence bounds, tombstone pairs, canonical UUID-array support references, and same-incident Indicator child references. A normal owner trigger enforces support-record incident membership on live interval writes; recovery may load authoritative tables with ordinary triggers disabled and then uses its owner validation path without acquiring a fragile table-order dependency. PostgreSQL text storage itself rejects NUL bytes; the added length checks exclude empty admitted text without incorrectly banning supported multivalue observation text.

The Down path first recreates all seven mirror columns, copies their values exclusively from Records, refuses incomplete reconstruction, restores defaults, nullability, actor foreign keys, and legacy partial indexes, and only then returns the schema to an old binary. It removes contract-only child constraints and restores the prior single-column child foreign keys. A dedicated migration-scratch test starts at version 56 with valid data, applies 57, verifies every mirror is absent and every selected constraint is validated, migrates Down to 56, proves exact Records reconstruction, reapplies 57, and attributes hostile type, lifecycle, resolution, support-shape, and cross-incident support rows to their intended constraints.

This migration MUST NOT be applied during an ordinary rolling deployment. Operators rerun Section 13.9 preflight, drain every incompatible writer, apply 57, and start only compatible binaries. Forward repair is preferred after cutover. An old binary may be restored only after the Down migration completes and its mirror reconstruction is verified.

#### Validation and failure accounting

Passing evidence:

- `make test-slice OWNER=module.indicators`: 18 of 18 at `.cartulary/test-results/20260803T210650Z-p2190061`.
- Final `make service-backed-test-slice OWNER=module.indicators`: 11 of 11 at `.cartulary/test-results/20260803T211311Z-p2271032`.
- The dedicated storage contraction migration row passed three of three at `.cartulary/test-results/20260803T211254Z-p2269530`.
- `make test-slice OWNER=module.incidentbundles`: 26 of 26 at `.cartulary/test-results/20260803T210735Z-p2195912`.
- `make service-backed-test-slice OWNER=module.incidentbundles`: 15 of 15 at `.cartulary/test-results/20260803T205614Z-p2061670`.
- The two affected Revisions delete/restore and Indicator child-rollback rows passed four of four at `.cartulary/test-results/20260803T205739Z-p2077771`.
- Recovery, Imports, and Network Flow service-backed runs passed all non-browser product units: 18, 17, and 9 respectively, at `.cartulary/test-results/20260803T205907Z-p2079801`, `.cartulary/test-results/20260803T210005Z-p2106998`, and `.cartulary/test-results/20260803T210034Z-p2112398`.
- Final `make generate-drift`, `make generated-artifact-policy-check`, `make json-shape-check`, and `make backend-module-boundary-check` passed at `.cartulary/test-results/20260803T211323Z-p2273196`, `.cartulary/test-results/20260803T211330Z-p2275728`, `.cartulary/test-results/20260803T211331Z-p2276126`, and `.cartulary/test-results/20260803T211334Z-p2276577`.
- `make lint-markdown` passed after the completed checkpoint update at `.cartulary/test-results/20260803T211514Z-p2279907`.
- Final `make test-fast` passed 346 of 346 at `.cartulary/test-results/20260803T210904Z-p2210650`.
- The committed-hash `make migration-drift` input phase validated all 57 files and the current-line history manifest at `.cartulary/test-results/20260803T211358Z-p2277111` before the classified local port conflict below.

Retained failure evidence and disposition:

- The initial Indicator service-backed run at `.cartulary/test-results/20260803T205022Z-p2022098` exposed `support_refs:null` from a nil Go slice and tests reading or writing deleted mirrors. Lifecycle admission now always persists an array, and source-owned fixtures use Records for envelopes. The final owner run passes.
- The first Incident Bundle service-backed run at `.cartulary/test-results/20260803T205457Z-p2050716` exposed a cross-owner fixture inserting mirror columns. It now inserts the source subtype contract only, and the final 15-unit run passes.
- The broad Revisions run at `.cartulary/test-results/20260803T205635Z-p2064617` exposed one source-adapter assertion that still expected an Indicator mirror tombstone and one child event assertion that reported unchanged Timeline text as changed. Both contract assertions were corrected, and their exact focused rows pass. Its seven remaining failures, and the later broad test-slice failures at `.cartulary/test-results/20260803T210752Z-p2200009`, are solely the existing nested-browser `OWNER is required` harness-routing defect.
- Recovery, Imports, and Network Flow broad service-backed runs likewise fail only their one, two, and fifteen nested browser rows because the slice harness omits `OWNER`. No non-browser product row failed.
- The first shape run at `.cartulary/test-results/20260803T210406Z-p2177999` required ownership for the two new Indicator constraint functions. The authored Indicator schema-object ownership pattern now covers them and final shape validation passes.
- Dedicated migration retries at `.cartulary/test-results/20260803T211134Z-p2262774` and `.cartulary/test-results/20260803T211212Z-p2264478` made malformed JSON trigger admission total and changed the test to inspect PostgreSQL's structured constraint name instead of relying on display text. The final Down/Up and hostile-row proof passes.
- `make migration-drift` at `.cartulary/test-results/20260803T211358Z-p2277111` passed migration-history and input validation, then could not start this worktree's Compose PostgreSQL because the unrelated `repo-postgres-1` container from `/home/jochi/code/cartulary-wf01.kD7A0s/repo` owns host port 5432. No external container was stopped or changed. Migration-scratch owner tests independently replayed empty head, version 56 upgrade, Down, and subsequent Up through the repository migration API. SL-14 must rerun the public target when the external port owner is absent or retain this environmental disposition.

SL-13 has no unclassified implementation or data condition. Its content checkpoint is `86ad647f`; production migration application remains gated on operator-confirmed preflight and old-writer drain. This ledger admits SL-14.

### 13.15 SL-14 test retirement, verification, and production handoff

#### Current-contract suite and dead-surface retirement

Indicator identity verification now lives with the pure owner-internal identity package. It covers the complete nine-type registry, all three value-kind positions including the exact IP restrictions, malformed aliases and hash representations, presentation-field exclusion from identity, IPv4/IPv6 canonical exactness, and canonical dedupe convergence. The two root-package characterization wrappers and the duplicate IP wrapper file were deleted. A small root adapter test remains because projecting identity validation fields into the public `CreateCommand` error contract is owner-facade behavior rather than identity-package behavior.

The two PostgreSQL-backed tests formerly named `_Unit` are now honestly named `_Integration`, and the remaining Indicator tests use named imports instead of dot imports. Production child routes have their own top-level integration test instead of executing transitively under the create/query route test. Static analysis at the completion gate also found and removed three newly unreachable helpers: the obsolete multi-row projection loader and the root identity normalization/dedupe wrappers that only the retired tests had consumed.

Indicator test support now owns `SeedRecord` and `SeedSubtype`. Revisions uses the complete record fixture, while Incident Bundles uses the subtype-only fixture because it deliberately controls portable envelope timestamps. Those consumers no longer embed physical `INSERT INTO indicators` statements. The owner fixture canonicalizes identity before insertion, so cross-owner tests depend on a semantic test contract rather than subtype column order or a copied dedupe digest.

The verification contract now contains 19 explicit claims, and the Indicator family manifest contains 23 ASCII-sorted rows. New independently attributable rows cover:

- exported-surface minimization;
- active identity claims following Records state and deterministic recovery rebuild;
- exact lifecycle vocabulary;
- production observation and lifecycle routes;
- UTF-8 source-span admission and frontend provenance exclusion;
- the closed observation transition state machine and transaction rollback;
- migration 57 Down/Up storage contraction;
- retained deterministic Indicator portability.

The active-claim row exposed one stale test query that supplied normalized text where the claim schema requires the canonical dedupe key. It now obtains that key from the Indicator owner fixture. The final broad check exposed four new public Indicator not-found codes that had been adopted in Core 01 but were missing from the OpenTelemetry classification owner and machine registry. All four now map to `not_found`; `make otel-conformance` passes, and no runtime inference or prefix mapping was added.

#### Passing validation evidence

- `make test-slice OWNER=module.indicators` passed 26 of 26 at `.cartulary/test-results/20260803T215118Z-p2742578`.
- `make service-backed-test-slice OWNER=module.indicators` passed 13 of 13 at `.cartulary/test-results/20260803T215134Z-p2749804`.
- Focused Revisions delete/restore and Indicator child-history fixtures passed five of five at `.cartulary/test-results/20260803T212644Z-p2309421`.
- Focused Incident Bundle import/portability fixtures passed four of four at `.cartulary/test-results/20260803T212656Z-p2311284`; the complete service-backed Incident Bundle owner passed at `.cartulary/test-results/20260803T213129Z-p2394807`.
- Focused Workbook admission/projection and Network Flow participant rows passed at `.cartulary/test-results/20260803T212914Z-p2339859` and `.cartulary/test-results/20260803T212917Z-p2341227`.
- Projections passed ten of ten authored rows and ten of ten service-backed units at `.cartulary/test-results/20260803T212924Z-p2346627` and `.cartulary/test-results/20260803T213041Z-p2386210`.
- View Schema and OpenAPI owner slices passed at `.cartulary/test-results/20260803T213028Z-p2385739` and `.cartulary/test-results/20260803T213030Z-p2385936`.
- `make backend-module-boundary-check` and `make frontend-import-boundary-check` passed at `.cartulary/test-results/20260803T212717Z-p2313075` and `.cartulary/test-results/20260803T212719Z-p2313450`.
- `make generate-drift`, `make generated-artifact-policy-check`, and `make json-shape-check` passed at `.cartulary/test-results/20260803T212721Z-p2313768`, `.cartulary/test-results/20260803T212728Z-p2316285`, and `.cartulary/test-results/20260803T212729Z-p2316677`.
- `make frontend-unit` passed 358 of 358 at `.cartulary/test-results/20260803T213222Z-p2416147`; `make frontend-typecheck` passed at `.cartulary/test-results/20260803T213412Z-p2451543`.
- `make browser-e2e-webserver-backed` passed 62 of 62 against the real application at `.cartulary/test-results/20260803T213427Z-p2452089`.
- `make otel-conformance` passed ten of ten after the complete public error mapping at `.cartulary/test-results/20260803T214930Z-p2724409`; `make lint-go` also passed after dead-helper removal.
- Final `make test-fast` passed 347 of 347 at `.cartulary/test-results/20260803T215144Z-p2751286`.
- Final `make check` passed 712 of 712 at `.cartulary/test-results/20260803T215410Z-p2812206`.
- Final `make lint-markdown` and `make agent-finalize` passed at `.cartulary/test-results/20260803T215919Z-p2938373` and `.cartulary/test-results/20260803T215928Z-p2939866`.

Module-author task guidance was consulted for Indicators, Workbook, Projections, Revisions, Network Flow, Incident Bundles, Recovery, View Schemas (`platform.viewschema`), and OpenAPI before selecting their final evidence. Retained-run maintenance was skipped because `RESULTS_DIR` was unset; no older run was presented as refreshed evidence.

#### Classified harness and environment residuals

There is no unclassified Indicator product, contract, migration-data, or test finding.

- Broad Workbook, Network Flow, Revisions, and Recovery owner slices at `.cartulary/test-results/20260803T213044Z-p2387481`, `.cartulary/test-results/20260803T213055Z-p2389666`, `.cartulary/test-results/20260803T213112Z-p2391486`, and `.cartulary/test-results/20260803T213148Z-p2397334` pass their non-browser work but fail nested browser units because `start-web-e2e.sh` receives no `OWNER` from `test-slice` or `service-backed-test-slice`. The independently invoked webserver-backed browser gate passes 62 of 62. This remains Testing Harness owner debt and does not justify weakening owner routing.
- `make migration-drift` at `.cartulary/test-results/20260803T213807Z-p2504228` passes the immutable-history and all-57-file input checks. Its empty and penultimate databases are created through the Compose service, but the migration client resolves `127.0.0.1:5432` to another local PostgreSQL and reports both generated database names absent. No external service was stopped or modified. The migration-scratch Indicator row in Section 13.14 separately proves empty-head, version-56 upgrade, Down reconstruction, hostile constraints, and subsequent Up through the repository migration API. The public target must be rerun in deployment CI or a workspace without the localhost routing collision.
- The first full check at `.cartulary/test-results/20260803T214242Z-p2561392` passed 710 of 712 and correctly found the dead helpers and telemetry registry omissions described above. Both findings were repaired; the final check passes 712 of 712.

These are explicitly owned follow-ups, not hidden acceptance exceptions. Bundle v1 retirement remains governed by the adopted release-age, usage, inventory, and later-revision gates. Reference Pack normalization ownership, frontend raw timestamp inference, and the historically Timeline-named runtime projection catalog remain outside this iteration as already classified in the Iteration 1 handoff.

#### Deployment and rollback handoff

The validated product/content HEAD is `509ee7382a12524bddeaeb184408cc3d465ee7be`. The terminal tracker checkpoint is documentation-only and follows that content commit.

Production deployment remains conditional, not automatic:

1. Rerun the exact SL-09 read-only preflight against the target database. Unknown lifecycle values, envelope disagreements, duplicate active canonical identities, malformed children, or incompatible Indicator idempotency payloads block deployment and require explicit operator disposition.
2. Confirm migration 00056 is applied and `indicator_active_identities_are_valid()` is true. The claim table remains excluded, rebuildable recovery state and must not be added to Incident Bundles or authoritative backups.
3. Drain every binary capable of writing the removed Indicator envelope mirrors. Migration 00057 is a contract migration and must not be applied during a mixed-version rolling window.
4. Apply 00057 and start only compatible binaries. Validate create, identity reuse, delete/restore conflict, observation/lifecycle routes, history, projections, and retained bundle v1/v2 import/export before reopening writers broadly.
5. Prefer forward repair after cutover. To restore an old binary, stop new writers, run migration 00057 Down, verify all seven mirrors were reconstructed from Records, and only then start the old binary.

The module is ready for production rollout once those environment-specific gates pass. Every Iteration 2 finding is completed or assigned to its proper non-Indicator owner; none remains unclassified or silently deferred.
