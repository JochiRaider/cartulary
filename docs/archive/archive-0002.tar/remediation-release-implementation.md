# Remediation and release implementation

Authorized scope: the 2026-11-06 remediation plan, native SAML retained,
fresh-install-only format changes, and targeted Make validation without CI
aggregates. Implementation, qualification and deployment are separate states.

Implementation and automated qualification are complete. The final evidence
closure accepts 58 passing invocations, covering all 40 authored obligations,
136 explicitly selected rows and the required release operations. Human
specification-to-contract fidelity review remains pending; distribution notice
review and formal CMVP applicability remain explicitly unestablished.

Baseline: `0d92130ebb9789037e8682dc5f9f12f3bd1d3d80`. The checkout was clean.
The original IR and Network Flow fixture bytes remain frozen.

| Workstream | Implementation | Qualification |
| --- | --- | --- |
| A1 specification authority | Route inventory, Graph references and domain placement corrected | Markdown lint passed; human fidelity review pending |
| A2 product obligations | 40 explicit capability obligations and 136 selected rows authored | Executable evidence closure passed; human fidelity review pending |
| B1 native SAML replacement | Replacement and structural admission implemented | Targeted policy, vulnerability scan and production-verifier ACS/session/replay integration passed; external IdP journey removed by user |
| B2 authorization/security | Explicit owner matrix and source-role/revocation regression implemented | Authorization, publication, privacy and dependency/security gates passed |
| C1 text interpretation | Workbook parser v2 validates UTF-8 through EOF | Unit and public admission slices passed |
| C2 streamed approval/apply | Transactional sparse CSV staging and sealed iterator implemented; fresh lineage v4; bounded XLSX behavior documented | Source protection, atomicity, retention, responsiveness and recovery checks passed |
| C3 malformed/preservation variants | Independent small generic vectors added | Generic and analytical parser/lifecycle selections passed |
| D1 committed-source investigation | Source drawer, Network Flow link and durable generic record associations implemented | Component, type, rendered browser and public transfer checks passed |
| D2 rendered investigation journeys | Source navigation and focus repair complete; shared aliases and clipboard boundary journeys added | Selected rendered values, ambiguity, clipboard, conflict/retry, restoration, focus and accessibility checks passed |
| E1 mutation/lifecycle integrity | Existing transaction coordinator and owner ports retained; owner failure/replay matrix qualified | Selected authorization, version, revision, audit/publication, rollback and exact-replay checks passed |
| E2 history and transfer fidelity | Existing owner boundaries retained; bundle v7 carries source associations | Joined graph/report/transfer/restore lifecycle and exact-package consumers passed |
| E3 scale and interruption | Stream retention and filesystem write-failure regressions added; explicit operator interruption selected | Parser retention, storage faults, operator interruption and adopted measurements passed |
| F1 recovery ownership | Private keyed locator and read-only resolution implemented | Native runtime and fixture recovery rows passed; historical run explicitly unresolved |
| F2 targeted release closure | Evidence-only command and shared package identity verifier implemented | Positive/negative regressions and final 58-root closure passed against one exact archive |

The executable release predicates have compatible passing evidence. This does
not substitute for the separate human review above or establish unclaimed
capabilities. Historical failures remain retained and are excluded from closure.

## Compatibility

Incompatible persisted state must reject before DDL or authoritative mutation.
There is no automatic reset, downgrade, conversion or historical dual reader.
Old backups/exports remain historical artifacts readable only by their supported
release. Reimporting original raw files creates a new operation and provenance.

## Evidence

Planning baseline: five `remediation-audit-*-20261106-01` invocations, six selected
catalog rows. All passed cleanup and retained-secret checks; one Imports unit
used compatible cache evidence. They do not qualify subsequent source changes.

The final [command ledger](../../.cartulary/remediation-release/qualification-commands.json)
records all 58 exact commands, run roots and native exit codes. The explicit
[root selection](../../.cartulary/remediation-release/final-evidence-roots.json)
and [passing closure](../../.cartulary/test-results/remediation-final-evidence-20261106-02/release-evidence-verify/closure.json)
bind their source, graph, row and package identities. The closure observed 178
distinct rows, including required-operation dependencies. Compatible harness
cache reuse remains identified by the retained runs; a pass does not imply every
underlying row executed afresh.

The closing command was
`make release-evidence-verify EVIDENCE_ROOTS_FILE=.cartulary/remediation-release/final-evidence-roots.json`
under run ID `remediation-final-evidence-20261106-02`. It passed in 59,591 ms,
launched no tests, and passed cleanup and retained-secret checks.
No `make ci`, `make check`, or `make release-check` was executed.

The final documentation-only command is `make lint-markdown`, with run ID
`remediation-final-markdown-20261106-02`. Its
[summary](../../.cartulary/test-results/remediation-final-markdown-20261106-02/adhoc/lint-markdown/tool-run-summary.json)
is retained separately from executable release evidence. Documentation edits do
not alter the frozen executable source or require rebuilding the qualified archive.

### Interim implementation validation

- `remediation-saml-20261106-02`: targeted enterprise cryptographic policy passed.
- `remediation-vulncheck-20261106-01`: `make go-vulncheck` passed.
- `remediation-import-unit-20261106-01`: target-neutral source admission and new interpretation vectors passed.
- `remediation-import-integration-20261106-01`: public source admission, mapping protection, transaction-current apply, and current workflow recovery passed (four selected rows).
- `remediation-source-ui-20261106-01`: committed-source component interaction row passed.

These are development results, excluded from the final candidate's evidence.
Earlier failed generation/type/format runs are retained;
they exposed projection binding updates, missing generated operation admission,
and test typing issues, and do not qualify the release.


## Product obligation matrix

The authored machine-readable selection is
[release qualification](../../contracts/verification/release-qualification.v1.json).
Each obligation names its current normative owner, implementation/test owners,
explicit regression rows and an independent expected invariant. The executable
verifier reads that JSON, never this document. This is a targeted product-wide
portfolio, not an assertion that route inventories or tests prove specification
completeness. All 40 named obligations below have compatible targeted evidence
in the passing final closure. Human specification-to-contract review remains
separate; the disposition is limited to each stated invariant and selection.

| Obligation | Current authority | Boundary and independent expectation | Disposition |
| --- | --- | --- | --- |
| `dependencies.maintenance` — Dependency pruning and runtime engine admission | TestingHarness+Core04 | Managed Go pruning is independent of analysis compilation; nested accessibility engine admission does not require a redundant root dependency | Verified targeted evidence |
| `auth.protocol` — Native SAML and OIDC admission | Core04 | Protocol bytes, singleton/namespace/signature/issuer/audience/correlation/time bounds; no session on rejection | Verified targeted evidence |
| `auth.accounts` — Account and credential administration | Core04 | Current deployment administrator, actor-scoped replay, original committed credential result and revocation | Verified targeted evidence |
| `auth.sessions` — Session lifecycle and enterprise bindings | Core04 | Durable session, current binding authority, exact replay and scope-safe audit | Verified targeted evidence |
| `incident.authority` — Incident lifecycle, membership and isolation | Core02+Core04 | Last-administrator invariant, current membership, close/reopen transition and replay | Verified targeted evidence |
| `timeline.history` — Timeline authoring and historical attribution | Core02+Core03 | Create, patch, review and supersede retain owner history; failed journal/revision contributions roll back | Verified targeted evidence |
| `entities.resolution` — Entities, aliases, mentions and merge | Core02+Core03 | Ambiguous candidates remain explicit; selection, dismissal and resolution history; merge repoints admitted live references | Verified targeted evidence |
| `indicators.lifecycle` — Canonical indicators and observations | Core02 | Explicit identity and lifecycle, concurrent convergence, authorization and revision failure atomicity | Verified targeted evidence |
| `parties.identity` — Parties and portable historical identity | Core02 | Active owner references, exact semantic replay, transferable identities; analyst names do not create Parties | Verified targeted evidence |
| `evidence.attachments` — Evidence, attachment replacement, handles and custody | Core01+Core02+Core04 | Owner/incident checks, atomic attachment change, inaccessible revoked handles and no object-store disclosure | Verified targeted evidence |
| `notes.associations` — Notes, associations and source references | Core02+Core03 | Public owner guards, association history and paging; reference text does not fabricate Evidence | Verified targeted evidence |
| `tasks.decisions` — Tasks and decisions | Core02+Core03 | Owner references and portable invariants are atomic; lifecycle and supersession retries retain exact identities | Verified targeted evidence |
| `relationships.tags` — Links and tags | Core02 | Association mutation updates projections, revisions and publication together; active views retain typed identities | Verified targeted evidence |
| `workbook.query` — Workbook query and coordination surfaces | Core01+Core03 | Sort/filter/group/search/page semantics, live authorization on continuation, typed collections and projection rebuild | Verified targeted evidence |
| `workbook.saved_views` — Saved views and keyboard recovery | Core03 | Independent read contract, restored query/layout/home and focus continuity during replacement or failure | Verified targeted evidence |
| `workbook.editing` — Conflicts, uncertain saves and collaboration | Core03 | Different-field convergence, same-field explicit resolution, same-identity uncertain retry, revocation and no retargeted drafts | Verified targeted evidence |
| `workbook.clipboard` — Clipboard and batch atomicity | Core01+Core03 | 499/500 accepted and 501/1500 rejected with zero partial effects; original multiline/Unicode/empty values retained | Verified targeted evidence |
| `imports.interpretation` — Raw admission and Workbook interpretation | Core01 | Original bytes/digest retained separately; UTF-8 v2 validates through EOF, sparse ordinals and exact text | Verified targeted evidence |
| `imports.atomicity` — Sealed projection and application lifecycle | Core01 | Approval seal and typed iterator; cancellation, journal failure and lost acknowledgement leave zero or one complete unit | Verified targeted evidence |
| `imports.provenance` — Committed source investigation and transfer | Core01+Core03 | Successful application identity distinguishes equal bytes; authorized exact download and immutable attribution survive workflow cleanup/transfer | Verified targeted evidence |
| `flow.interpretation` — Network Flow parsing, orientation and multiplicity | NetworkFlow | 4500 observations, 500 overlaps, 3903637992 bytes, 4412353 packets; null ports and unknown direction; count connection counters once | Verified targeted evidence |
| `flow.history` — Selected graph history and refresh | NetworkFlow+GraphProjection | New tables do not alter saved results; explicit successful refresh changes selection, failed refresh retains prior state | Verified targeted evidence |
| `graph.projection` — Graph engine and publication | GraphProjection | Independent semantic matrix, deterministic restore rebuild and atomic result publication under maximum admitted bounds | Verified targeted evidence |
| `reporting.frozen` — Frozen reporting and graph inputs | Reporting | Persist exact immutable input/result bindings and portable rendered artifact streams | Verified targeted evidence |
| `reporting.authority` — Report publication, recipients and redaction | Reporting+Core04 | Initiating authority rechecked at work/publication; distinct external reviewer; deterministic recipient redaction | Verified targeted evidence |
| `composition.lifecycle` — Composition publication and release tuple | ReportComposition | Current public lifecycle authority and closed release-tuple reason matrix; no optional builder claim | Verified targeted evidence |
| `reference.trust` — Reference packs, trust and activation | ReferencePack | All admitted consumer profiles use canonical persisted state; authorization rederived; failed activation retains prior active pack | Verified targeted evidence |
| `transfer.integrity` — Incident transfer and joined investigation lifecycle | Core01+NetworkFlow+Reporting | Original identity, actor attribution, sources, overlap observations, frozen reports/graphs retained; publication rechecks membership | Verified targeted evidence |
| `recovery.integrity` — Backup, restore and fresh-only cutover | Core01+Core04 | No unclassified authoritative table, no mutation of incompatible state, crypto format identity retained and restored investigation usable | Verified targeted evidence |
| `objects.lifetime` — Staged objects and object storage | Core01 | Owned allocation/publication/cleanup; qualified streaming and managed service binding preserve bytes and cancellation | Verified targeted evidence |
| `jobs.recovery` — Jobs, interruption and publication | Core01+Core04 | Claim/recovery/publication authority, supervised shutdown and failure privacy reconcile all terminal effects | Verified targeted evidence |
| `extensions.admission` — Extension claims, state and jobs | Extensions | Closed claim admission, concurrent owner state, canceled/finalized jobs and inactive reconciliation | Verified targeted evidence |
| `configuration.limits` — Configuration and deployment limits | Core04+Extensions+NetworkFlow | Closed deployment profile, deterministic resource bounds, independent extension and analytical owner admission | Verified targeted evidence |
| `telemetry.privacy` — Telemetry and diagnostic privacy | OpenTelemetry+Core04 | No source text, credentials or private paths; exporter failures preserve product behavior; bounded queues | Verified targeted evidence |
| `resilience.budgets` — Supported-profile scale and cancellation | Core05+Core01+NetworkFlow | Adopted discovery/apply and analytical limits; editing remains responsive during bounded import cancellation | Verified targeted evidence |
| `harness.recovery` — Exact recovery ownership | TestingHarness | Private keyed locator, bounded read-only resolution, independent resource authority, idempotent settlement and immutable failed evidence | Verified targeted evidence |
| `release.closure` — Targeted exact-package evidence closure | TestingHarness+Core04+Core05 | Explicit compatible roots only; no test launch; mandatory rows/policies, privacy/cleanup and one producer/archive identity across consumers | Verified targeted evidence |
| `assessments.lifecycle` — Compromise assessments and assessor attribution | Core01, Core03 | Append-only states, current assessor membership and transaction failure/replay preserve exact owner effects | Verified targeted evidence |
| `artifacts.lifecycle` — Findings, investigative queries, forensic keywords and handoff risks | Core01, Core03 | Typed collection semantics, source mutation/version envelopes and rollback preserve each owner family | Verified targeted evidence |
| `revisions.lifecycle` — Record history, rollback, deletion and restore | Core01, Core03 | Current destructive authority, injected rollback failures, bounded history pagination and portable attribution remain exact | Verified targeted evidence |

The composition builder, encrypted SAML assertions, unsolicited SAML login,
charset guessing, automatic archive/database migration, historical dual readers,
and future-only domain concepts are explicitly unclaimed. Native SAML remains
required. Source-record navigation, fault injection and resource measurements
have their own evidence in the final portfolio; adjacent passing rows do not
establish additional capabilities.

This matrix is the current review baseline. Exact implementation boundaries and
selectors are resolved by the owner IDs and row IDs in the authored policy;
`make task-guide OWNER=<owner>` supplies current execution commands. Changes to
claimed capabilities require normative review and an explicit matrix disposition.


### Scope correction — 2026-11-06

The user has no SAML IdP test environment and explicitly removed the external
IdP interoperability requirement. It is not a release gate and no live-provider
compatibility claim is made. Native SAML remains supported; independently signed
local protocol fixtures, hostile XML/signature cases, ACS/session/replay tests,
vulnerability scanning and cryptographic qualification remain mandatory.

Additional development evidence:

- `remediation-release-evidence-20261106-02`: selected release evidence positive/negative cases passed.
- `remediation-native-recovery-20261106-01`: native session ownership and recovery lookup passed.
- `remediation-fixture-recovery-20261106-01`: native fixture lifecycle and recovery passed.
- `remediation-historical-recovery-status-20261106-01`: read-only resolution completed; `ir-portability-final-ci03` remains explicitly unresolved, with no cleanup attempted.
- `remediation-saml-20261106-05`: expanded assertion-only signature, wrapping, namespace and protocol policy cases passed. Earlier positive-fixture failures exposed canonicalization context in the test signer; the fixture now uses explicit exclusive canonicalization.
- `remediation-source-browser-20261106-01` through `03`: product assertion failures before import exposed a missing admitted menu selector. The selector contract and menu regression were corrected; these failed runs remain retained.
- `remediation-source-browser-20261106-06`: Timeline record and Network Flow source navigation, focus return, exact download and source transfer passed. The transfer scenario also checks editor/reviewer/admin access, viewer denial, removed membership, protected cursor continuation and filter validation.
- `remediation-import-stream-20261106-01`: parser retention checks passed at 10,000 and 100,000 rows; its browser row failed on a removed inspector focus target. The subsequent source-browser run passed after adding the active-surface focus fallback. These memory samples concern live parser/serialization state, not total allocation or server capacity.
- `remediation-saml-acs-20261106-01`: public SP initiation, independently signed XML through the production verifier, session completion, tampering rejection and replay rejection passed.
- `remediation-lineage-20261106-01`: fresh-install preflight rejects both previous v2/v3 lineages without DDL or ledger mutation.
- `remediation-investigation-aliases-20261106-02`: both shared aliases require explicit candidate selection; dismissal is retained in rendered history after reload.
- `remediation-joined-lifecycle-20261106-01`: both selected Network Flow portability and historical lifecycle scenarios passed, including source/graph/report bindings and restore.
- `remediation-release-evidence-20261106-03`: current policy resolution and negative obligation/evidence/package cases passed. Unknown rows, mismatched owners and duplicate obligations fail admission.

- `remediation-investigation-clipboard-20261106-03`: rendered 499/500 acceptance and 501/1,500 rejection passed. Earlier failures exposed ambiguous feedback selectors and a representative anchor outside the loaded query window; the corrected assertions follow the declared query and accessibility semantics.
- `remediation-recovery-faults-20261106-01`: storage exhaustion, short writes and cancellation leave no envelope or private staging bytes; real operator interruption/completion replay passed.
- `remediation-markdown-20261106-02`: Markdown lint passed after repairing glossary table placement.
- Seeded source-list/detail visual review found and repaired a download-link contrast defect. The repeated review reported zero axe violations and no console/request failures; background-grid contrast remained an incomplete automated observation. Both review sessions closed with complete cleanup. This is development UI evidence, not a full accessibility claim.
- `remediation-source-check-20261106-01`: authored/generated source integrity passed. `remediation-lint-20261106-01` found an export routine outside the permitted transfer adapter and unformatted UI changes. The routine was moved into the existing adapter without weakening the boundary policy; final source and standard lint checks subsequently passed in the selected `remediation-qualified5-` portfolio.

The current incident bundle version is 7. Its required record-association stream
retains generic record-to-source navigation across workflow cleanup and transfer.
Older bundles remain historical artifacts for their original readers; this release
does not convert or import them.

## Superseded qualification candidate

`make agent-finalize` passed in `remediation-finalize-20261106-02` with no generated drift.
Retained warm-check maintenance was skipped because no compatible full warm-check
root was supplied; no CI/check invocation was launched to obtain one.

The first frozen executable source identity was
`sha256:b5064c780ab299244bac7b3ff3c86e5b78e0822be89bb468b0881a8c736a67af`.
All 133 selected rows were reconciled with their current Make owner guides.
Final source-integrity and standard lint invocations passed under that identity.
These results remain development evidence. Cryptographic qualification exposed
a missing fixed startup rejection diagnostic; the harness contract exposed
optional-input shell expansion and a diagnostic fixture reusing a recovery identity.
The repairs preserve diagnostic privacy, literal input values and immutable
runtime ownership. They require a new executable source identity for final
qualification. No package was built against the superseded candidate.

The retained failing roots were `remediation-qualified-crypto-20261106-01`
(`make cryptographic-policy-assessment`) and
`remediation-qualified-harness-contract-20261106-01`
(`make harness-contract SUITE=contract`). Their `run-summary.json` files and
referenced unit diagnostics preserve the original outcomes. The combined Imports
selection in `remediation-qualified-imports-20261106-01` also reached the browser
row's test deadline after its nine backend/component rows passed. The isolated
`remediation-qualified-import-browser-20261106-02` subsequently passed without a
deadline change. Concurrency was a hypothesis, not an established failure cause;
final corpus browser qualification is isolated.

## Second qualification candidate — superseded by dependency maintenance

`remediation-qualification-repairs-finalize-20261106-01` passed. That candidate's
frozen source identity was
`sha256:446558135f58643d843b8fef58dfe037f2af1ea7cbfdfa49c124a9b59fa12da2`.
That candidate's obligation selection included 134 rows across 34 owners,
including the fixed startup-diagnostic regression. The attempt used the
`remediation-qualified2-` run prefix and retained each exact command and result.

The isolated CSV measurement run qualified both adopted responsiveness predicates:
212 ms during apply and 218.2 ms during discovery against the 1,000 ms threshold.
These are the contract's single samples, not percentile or general capacity claims.
The prescribed 25-session background load, progress, cancellation and cleanup
checks passed. No unrelated tests ran concurrently with this measurement.

The detailed vulnerability scan passed its reachable-code gate but retained three
module-only findings. The tagged `x/net v0.62.0` update addresses
[GO-2026-6860](https://pkg.go.dev/vuln/GO-2026-6860) and
[GO-2026-6866](https://pkg.go.dev/vuln/GO-2026-6866). The unimported OpenPGP
package remains tracked under [GO-2026-5932](https://pkg.go.dev/vuln/GO-2026-5932):
its removal is untagged as of this qualification, so no development branch is
adopted merely to suppress a module-only finding. Dependency updates use Make's
managed bootstrap/tidy boundary. These changes supersede this candidate; its
passing results remain development evidence and no package was built from it.

## Installation and operational handoff

The current database lineage is `cartulary.prod_ddl_rebaseline.v4`. Provision a fresh database
and object-store namespace through the supported deployment workflow. Existing
v2/v3 databases must fail preflight before DDL; do not clear their ledgers or
rewrite lineage markers. Keep old backups and incident bundles together with the
release capable of reading them. Bundle version 7 is the sole current reader and
writer. Raw CSV/XLSX files may be deliberately reimported as new operations.

Workbook CSV interpretation now records `cartulary.import.workbook.v2` and
`workbook_import_adapter_v2`. Invalid UTF-8 fails interpretation through EOF;
upload still preserves uninterpreted bytes. A leading BOM is an encoding marker,
embedded U+FEFF is text, and no charset guessing or Unicode normalization occurs.
Approval seals sparse rows transactionally; apply verifies the stored count and
digest before committing destination effects. Analytical parsing retains its own
adopted rules. CSV decoding and projection staging stream rows. XLSX retains its
existing bounded materialization under the adopted archive, row, column and cell
limits; this release makes no unbounded XLSX streaming claim.

Editors, reviewers and incident administrators can open **Original import
sources**, follow an imported record's source link, or inspect a Network Flow
table's original source. Viewers do not receive this capability. Source detail
shows historical attribution and the approved interpretation; edited workbook
values remain current values. Downloads are deliberate, authorized reads of the
exact original bytes. Closing a source drawer returns to its attached invoker or,
when it replaced an inspector, the active workbook surface.

For a failed harness invocation, retain the exact run root and first use
`make test-run-recovery-status RESULTS_DIR=<exact-root>`. This is read-only.
`make test-run-recover RESULTS_DIR=<exact-root>` resolves the private keyed
locator and still requires each resource owner's cleanup authority. Recovery
creates separate evidence; it never rewrites the failed run. A settled runtime
is an idempotent no-op. An old run without sufficient authority remains
unresolved; do not infer permission from process names or guessed paths.

SAML provider setup checklist:

- Retain the configured provider key, SP entity ID, derived ACS URL and existing subject bindings.
- Configure the exact IdP issuer, HTTPS SSO URL and current trusted RSA signing certificates through the deployment-local manifest.
- Use SP-initiated login, matching request/RelayState and bearer confirmation; unsolicited login and encrypted assertions are unsupported.
- Sign the admitted Response or single Assertion with the required algorithm policy. Namespace ambiguity, duplicate IDs, missing nodes, expired conditions and malformed signatures reject before session issuance.
- Account for the 1 MiB response, 50,000-token and 64-level XML bounds; oversized attribute sets are rejected rather than silently truncated.
- Native SAML is qualified with local signed-protocol and session tests. No external IdP tenant or vendor compatibility result is claimed.

The retained vulnerability finding motivated removal of `crewjam/saml` in favor
of tagged `gosaml2 v0.12.0`. Its upstream
[release](https://github.com/russellhaering/gosaml2/releases/tag/v0.12.0) and
[allocation advisory](https://github.com/russellhaering/gosaml2/security/advisories/GHSA-66r8-42f7-4q74)
describe the token bound; application security still depends on Cartulary's owner
checks and final dependency/cryptographic qualification.


### Dependency removal

Managed Go pruning removes nine obsolete module requirements, including
`crewjam/saml`, `go-ini/ini`, `dustin/go-humanize`, `klauspost/cpuid/v2`,
`klauspost/crc32`, `philhofer/fwd`, `rs/xid`, `tinylib/msgp`, and
`go.yaml.in/yaml/v3` from the product module. Required transitive dependencies
remain; `x/crypto` provides the test-container SSH implementation. The tagged
`x/net` security update raises its required Go dependency versions through module
resolution. The product does not import OpenPGP.

The redundant root `axe-core` development dependency is removed. Its Playwright
adapter still requires the engine; readiness validates that actual nested engine
against the pin registry. The report renderer dynamically loads
`@slidev/theme-default`, so that package is used and retained. No unused package
is upgraded merely to silence a diagnostic.

`make bootstrap PART=go` prunes both authored Go module graphs and regenerates
checksums before rebuilding analysis tools. Ordinary source inspection and
verification do not edit dependency locks. The initial full-bootstrap attempt
`remediation-dependency-maintenance-20261106-01` failed before analysis compilation
because the updated module lacked managed checksums; the new narrow maintenance
path completed in `remediation-go-pruning-20261106-01`.

## Third qualification candidate — superseded by package qualification repairs

`remediation-pruned-finalize-20261106-01` passed. That candidate's executable source:
`sha256:6959d323d36feeebb074302b3a2e7c464ef7c34e6a6ac671e341f8da57980bf4`.
Its portfolio contained 40 obligations and 136 explicit rows across 35 owners,
plus the separately selected release operations. That attempt used
the `remediation-qualified3-` prefix.

The dependency scan reports one module-only OpenPGP finding, no affected imported
package or reachable symbol, and no blocking finding. Frontend analysis reports
no unused development or optional dependencies. Its remaining theme warning is
a dynamic-load false positive confirmed in `packages/report-renderer/src/slidev.ts`.

All 56 non-package invocations passed. The package invocation
`remediation-qualified3-package-20261106-01` failed three consumers: startup,
reference packs and credential capacity. Archive inspection and operational
recovery passed. The shared consumer script still expected the old server log
message instead of the fixed cryptographic-policy rejection diagnostic. Its
assertion now matches that owner diagnostic. The failed run and archive remain
retained and do not qualify the current candidate.

Inspection also found that a writable-volume capability did not serialize
credential measurement against other package consumers. The new
`credential_capacity_quiet` topology profile uses the existing exclusive
`host_activity` lock for the operation and its cleanup. The package and release
graph regression requires that exclusive mode. Limits and thresholds are
unchanged. Profile registration and schema regeneration failures occurred before
execution during development; `remediation-package-repair-generate-20261106-03`
and `remediation-package-repair-finalize-20261106-03` subsequently passed.

## Fourth qualification candidate — superseded by reporting observation repair

Executable source after finalization:
`sha256:d921d096338ea71114fae12b21ff1919444f13390c65dfaa27f6477748bb876c`.
That attempt used `remediation-qualified4-` roots. The final evidence closure
excludes every superseded source identity and failed package invocation.

`remediation-qualified4-package-20261106-01` ran for 574,614 ms. Archive inspection,
startup, operational recovery and credential capacity passed. The reference-pack
journey completed transfer but failed its SQL observation at the removed
`reporting_imported_artifact_files.content` column. The fixture now reconstructs
ordered `reporting_imported_artifact_chunks`, verifies retained size/SHA-256, and
compares the transferred PDF with the independently retained original digest and
size. This repairs test observation without altering Reporting storage or transfer.
This failed invocation cannot establish release closure.

## Current frozen candidate

`remediation-portable-observation-finalize-20261106-01` passed. The current
executable source is
`sha256:a5aa492699ae4dd170f458ab5fa40cbcd6f02881086f0fcad1efb475fe20dbf4`.
Current qualification uses the `remediation-qualified5-` run prefix. Its explicit
58-root selection is retained at
`.cartulary/remediation-release/final-evidence-roots.json`; inclusion in that
selection does not itself establish that a run has passed.

`remediation-qualified5-package-20261106-01` passed in 624,929 ms: all 19 graph
units, 28 cleanup outcomes and the retained-secret scan passed. Archive inspection,
startup, reference-pack reporting/transfer/source-loss restore, operational
recovery and credential capacity consumed one exact archive. Its identities are:

- Manifest: `6ee0d5d9d9fc32a363c7847d64159864f57e11dc0b2eb8f78199a1453821edcb`.
- Archive SHA-256: `872ef1278efc7afdd8ac5461c5571694590f37de33c0293637958770cc198cb3`.
- Archive: [qualified release archive](../../.cartulary/release-artifacts/packages/6ee0d5d9d9fc32a363c7847d64159864f57e11dc0b2eb8f78199a1453821edcb.tar).
- Producer receipt and inventories: the run's `package-release/artifacts/package.json`
  and the archive's `release/inventories/` members.

The qualified reference host was Windows 11 Pro build 26200.9711, WSL 2.7.3.0,
Ubuntu 26.04, kernel 6.6.114.1, Docker Desktop 4.97.0.244584 / engine 29.9.2 and
Compose 5.6.1. Credential qualification enforced CPU set `0,1`, a two-CPU quota,
2 GiB application RAM and zero additional swap. Its 200-request p95 was
341.390106 ms against 2,000 ms; overload rejection, cancellation and capacity
recovery passed. These are allocated logical CPUs, not dedicated physical cores.

The isolated CSV responsiveness measurements qualified at 214.8 ms during apply
and 219.1 ms during discovery, against 1,000 ms. Each predicate has one prescribed
sample, with 25 sessions, 4.8 background updates per second and a 20,000-row CSV;
these are not percentile or general throughput claims. Progress, cancellation
and cleanup passed, with zero scheduler overlap.

The first evidence closure, `remediation-final-evidence-20261106-01`, correctly
failed because the selected roots lacked `harness.test_catalog_check`.
`make source-check CHECK=catalog` passed separately in
`remediation-qualified5-catalog-20261106-01`; that explicit receipt was added to
the selection. The existing `CHECK=all` invocation did not supply it. No source
change or package rebuild was needed, and the failed closure remains retained.

## Phase exits and handoff state

| Phase | Dependencies and completed exit evidence | Remaining boundary |
| --- | --- | --- |
| 0 — Establish authority | Current owners, amendments, 40-obligation matrix and fresh-only parser/storage decisions are recorded | Human review must confirm specification-to-contract fidelity; executable checks cannot establish it |
| 1 — Remove blockers | Native SAML, authorization, exact recovery ownership and targeted evidence closure passed their selected regressions | External IdP testing was removed by the user; the historical run without recoverable authority remains unresolved |
| 2 — Import foundations | UTF-8 v2, exact raw retention, sealed sparse CSV projection, malformed vectors and atomic application passed | XLSX remains subject to its adopted bounded materialization limits |
| 3 — Investigation behavior | Source/provenance contracts, rendered journeys, owner mutations and joined graph/report/transfer history passed | Claims are limited to the stated obligations, with no optional composition-builder claim |
| 4 — Resilience | Resource measurements, concurrency/recovery selections, storage fault injection and operator interruption passed | Measurements establish the adopted reference-profile predicates, not arbitrary deployment capacity |
| 5 — Freeze and hand off | Finalization, one immutable archive, 58 compatible runs, evidence closure, inventories and operator guidance are retained | Human fidelity and notice review remain outstanding; no deployment or publication was performed |

The handoff contains the specification changes, obligation matrix, exact command
ledger and evidence roots, package identities and inventories, dependency
dispositions, reference deployment profile, installation/recovery guidance and
explicit unsupported capabilities. Preserve the selected evidence and archive
together. Any executable change requires a new source qualification decision;
do not reuse this closure to qualify a modified package. Human review outcomes
must be recorded separately without rewriting retained test results.

## Review and release boundaries

The executable obligation matrix establishes only the selected behaviors and
adopted deployment profile. It does not prove specification completeness or
replace human specification-to-contract review. Review the current Core 00/01/03/04
amendments, Imports and Network Flow ownership, source access and provenance,
fresh-only database/bundle cutover, and the authored qualification policy together.
The source fixtures and independent expected values remain review inputs.

Distribution inventories bind the exact packaged images. Their recorded notice
review remains `content_complete_review_unestablished` until the responsible
human review is completed; passing content checks are not legal approval. Formal
CMVP applicability also remains unestablished, with no certification claim.

Measurements establish their named predicates only: parser live-memory retention,
CSV editing responsiveness under the prescribed load, and package credential
capacity on the fixed reference profile. Injected ENOSPC, short-write and
cancellation cases establish failure handling; they do not establish behavior
under every host-wide storage or infrastructure failure.

No automatic dependency update, compatibility conversion, SAML vendor
interoperability, optional composition builder, or broader performance claim is
carried into the release merely because adjacent tests pass.
